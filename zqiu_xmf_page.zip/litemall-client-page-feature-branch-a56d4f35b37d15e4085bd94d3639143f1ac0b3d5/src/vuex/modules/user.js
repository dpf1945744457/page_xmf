import { userLogin,userRegisterByMobile, userLoginByMobile, bindMobile, userRegister, userExit, getmallUserInfo, userInfoUpdata ,weixinLogin,weixinLoginByFlush,weixinLoginByRouter } from '@src/apis/user.js'
import { getToken, setToken, removeToken } from '@src/utils/auth.js'
import router from '@src/router'
import Toast from '@src/components/base/vue-toast-mobile'
const types = {
    SET_TOKEN: "SET_TOKEN",//设置token
    SET_USERINFO: "SET_USERINFO",//设置用户信息
    SET_BANK: "SET_BANK",//设置银行卡用户
}

export default {
    state: {
        // 用户token
        token: getToken(),
        // token过期时间
        tokenExpire: "",
        //用户信息
        userInfo: JSON.parse(localStorage.getItem("userInfo")) || { headImg: "", agentNo: "", gender: "", nickName: "", birthDay: "" },
        //是否银行卡用户
        bankUser: '',
    },
    getters: {
        isLogin: state => {
            if (state.token) {
                return true;
            } else {
                return false
            }
        }
    },
    mutations: {
        [types.SET_TOKEN](state, token) {
            state.token = token;
        },
        [types.SET_USERINFO](state, userInfo) {
            state.userInfo = userInfo;
            localStorage.setItem("userInfo", JSON.stringify(userInfo));
        },
        [types.SET_BANK](state, bankType){
            state.bankUser = bankType;
            localStorage.setItem("bankUser", JSON.stringify(bankType));
        }
    },

    actions: {
        // 用户注册 + 登录
        async userRegister({ commit, dispatch }, userInfo) {
            let data = await userRegister(userInfo);
            return dispatch("login", data);
        },

        // 使用用户名密码登录
        async loginByUsername({ commit, dispatch }, userInfo) {
            let data = await userLogin({ username: userInfo.username, password: userInfo.password });
            return dispatch("login", data);
        },

        // 使用手机号验证码登录
        async userLoginByMobile({ commit, dispatch }, userInfo) {
            let data = await userLoginByMobile({ ...userInfo });
            return dispatch("login", data);
        },

        // 使用手机号注册
        async userRegisterByMobile({ commit, dispatch }, userInfo) {
            let data = await userRegisterByMobile({ ...userInfo });
            return dispatch("login", data);
        },

        // 微信用户绑定手机号
        async bindMobile({ commit, dispatch }, userInfo) {
            let data = await bindMobile({ phone: userInfo.phone, code: userInfo.code,areaCode:userInfo.areaCode });
            return dispatch("login", data);
        },

        //使用微信登录
       	async loginByWx({ commit , dispatch}, userInfo) {
            let data = await weixinLogin({ ...userInfo });
            
        	if(data.errno === 0){
           		return dispatch("login", data);
        	}else{
        		return data;
        	}
        },

        async loginByWxFlush({ commit , dispatch}, userInfo) {
            let data = await weixinLoginByFlush({ ...userInfo });
            
        	if(data.errno === 0){
           		return dispatch("login", data);
        	}else{
        		return data;
        	}
        },

        async loginByWxRouter({ commit , dispatch}, userInfo) {
            let data = await weixinLoginByRouter({ ...userInfo });
        	if(data.errno === 0){
           		return dispatch("login", data);
        	} else {
        		return data;
        	}
        },


        // 登入
        async login({ commit, dispatch }, data) {
            if(data.errno != undefined){
            	if(data.errno === 403){
            	  Toast(data.errmsg);
            	  return false;
            	}
            }
            
            commit(types.SET_TOKEN, data.token);
            setToken(data.token, { expires: new Date(data.tokenExpire) });
            // 登录成功获取购物车数量
            dispatch("getCartGoodscount");
            // 获取用户信息
            dispatch("getmallUserInfo");
            if (getToken()) {
                return true;
            } else {
                return false;
            }
        },

        // 修改用户信息
        async userInfoUpdata({ commit, dispatch }, userInfo) {
            let data = await userInfoUpdata(userInfo);
            commit(types.SET_USERINFO, userInfo);
        },

        // 获取用户信息
        async getmallUserInfo({ commit, dispatch }) {
            let userInfo = await getmallUserInfo();
            commit(types.SET_USERINFO, userInfo);
        },

        // 登出
        async fedLogOut({ commit, dispatch }) {
            userExit({'X-Litemall-Token': getToken()});
            removeToken();
            window.location.reload();
        },

        // 登录过期 重新登录
        async reLogin({ commit, dispatch }) {
            commit(types.SET_TOKEN, "");
            removeToken();
            router.push({ path: "/phoneLogin", query: { redirect: router.currentRoute.fullPath } });
        },

    },
}
