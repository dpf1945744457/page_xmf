<template>
    <div class="order-address-bar side-distance">
        <div class="order-address-box">
            <!-- <div class="icon-box">
                <icon scale="2" name="gpr"></icon>
            </div> -->
            <div class="content-box">
                <p class="user-box">
                    <span>收货人：{{address.name}}</span>
                    <span>{{address.mobile}}</span>
                </p>
                <p class="address-box">
                    <span v-if="address.isDefault" class="tip">默认</span>
                    收货地址：{{address.address}}
                </p>
            </div>
            <div class="icon-box">
                <icon scale="2" name="linkright"></icon>
            </div>
        </div>
    </div>
</template>
<script>
import "@src/assets/less/butcommon.less"
export default {
    props: ["address"],
    components: {},
    head() { return {} },
    asyncData(context) { },
    methods: {
    },
    data() { return {} },
    fetch() { },
    methods: {}
}
</script>
<style lang='less' scoped>
.order-address-bar {
  background: #fff;
  .order-address-box {
    padding: 12px 0 12px;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    .content-box {
      flex: 1;
      display: flex;
      flex-direction: column;
      .user-box {
        font-size: 16px;
        // font-weight: 600;
        flex: 1;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        color: #222;
      }
      .address-box {
        padding-top: 8px;
        .tip {
          display: inline-block;
          background: #f23030;
          font-size: 10px !important;
          color: #fff;
          border-radius: 8px;
          box-sizing: border-box;
          padding: 0px 10px;
          font-size: 12px;
          display: inline-block;
          transform: translateY(-2px);
          vertical-align: middle;
        }
      }
    }
    .icon-box {
      flex: 0 0 20px;
      display: flex;
      justify-content: flex-end;
      align-items: center;
      text-align: right;
      svg {
        transform: translateX(8px);
        font-weight: bold;
      }
      &:first-child {
        justify-content: start;
      }
      &:last-child {
        justify-content: end;
      }
    }
  }
}
</style>
