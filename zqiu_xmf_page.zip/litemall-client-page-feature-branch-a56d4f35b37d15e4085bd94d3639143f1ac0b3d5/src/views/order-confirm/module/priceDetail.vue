<template>
    <div class="priceDetail com-top-1px com-bottom-1px">
        <Ucell class="u-cell" title="商品总额">
            <span class="red" slot="desc">HK${{allData.goodsTotalPrice | filterPrice}}</span>
        </Ucell>
        <Ucell class="u-cell" title="运费">
            <span class="red" slot="desc">HK${{allData.freightPrice | filterPrice}}</span>
        </Ucell>
        <Ucell class="u-cell" title="税费">
            <span class="red" slot="desc">HK${{allData.tariffPrice | filterPrice}}</span>
        </Ucell>
        <!-- <Ucell class="u-cell" title="优惠金额">
            <span class="red" slot="desc">HK${{allData.couponPrice | filterPrice}}</span>
        </Ucell> -->
        <Ucell class="u-cell" title="订单合计">
            <span class="red" slot="desc">HK${{allData.orderTotalPrice | filterPrice}}</span>
        </Ucell>
    </div>
</template>
<script>
import Ucell from "@src/components/base/u-cell"
export default {
    props: ["allData"],
    filters: {
		filterPrice: function(num) {
			return Number(num).toFixed(2);
		}
	},
    components: {
        Ucell
    }
}
</script>
<style lang='less' scoped>
.priceDetail {
  padding: 10px 0;
  background: #fff;
  color: #222;
  .red {
    color: #e64340;
  }
  .u-cell {
    padding: 7px 10px;
  }
}
</style>