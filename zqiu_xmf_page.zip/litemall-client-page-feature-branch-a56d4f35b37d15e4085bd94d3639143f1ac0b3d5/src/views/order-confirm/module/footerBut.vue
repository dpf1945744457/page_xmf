<template>
    <div class="footerbut-box border-top-1px">
        <div class="flex-box text-right">
            <span class="price-text">
                {{label}}
                <span class="red-text bold-text">
                    HK${{price | filterPrice}}
                </span>
            </span>
        </div>
        <Xbutton class="red" :show-loading="btnLoading" :disabled="btnLoading" @click.native="submitHandle" type="warn" style="border-radius:0;">{{buttext}}</Xbutton>
    </div>
</template>

<script>
import Xheader from "@src/components/base/x-header"
import Uinput from "@src/components/base/u-input"
import Xbutton from "@src/components/base/x-button"
import "@src/assets/less/butcommon.less"
export default {

    components: { Xheader, Uinput, Xbutton },
    props: {
        label: {
            type: String
        },
        price: {
            type: String
        },
        buttext: {
            type: String
        },
        btnLoading: {
            type: Boolean
        }
    },
    filters: {
		filterPrice: function(num) {
			return Number(num).toFixed(2);
		}
	},
    methods: {
        submitHandle() {
            this.$emit("submitHandle")
        }
    }
}
</script>

<style lang="less" scoped>
.price-text {
  display: flex;
  white-space: nowrap;
  & > span {
    font-size: 20px;
    display: inline-block;
    white-space: nowrap;
  }
}
</style>
