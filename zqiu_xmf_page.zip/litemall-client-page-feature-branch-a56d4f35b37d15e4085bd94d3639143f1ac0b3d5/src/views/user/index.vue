<template>
    <TabbarLayout>
        <!-- 用户信息 -->
        <UserHeader></UserHeader>
        <!-- 用户订单模块 -->
        <!-- <UserOrder></UserOrder> -->
        <!-- 用户工具箱 -->
        <!-- <UserTool class="m-t-10"></UserTool>
        <Xbutton class="m-t-10 logout-btn" v-if="isLogin" @click.native="loginOut">退出登录</Xbutton>-->
        <UserList></UserList>
        
        <!-- 底部footer -->
        <!-- <UserFooter class="m-t-10"></UserFooter> -->
    </TabbarLayout>
</template>

<script>
	import TabbarLayout from "@src/layouts/tabbar.vue"
	import UserHeader from "./module/user-header.vue"
	import UserOrder from "./module/user-order.vue"
	import UserTool from "./module/user-tool.vue"
	import UserFooter from "./module/user-footer.vue"
	import UserList from "./module/user-list.vue"
	import Xbutton from '@src/components/base/x-button'
	import { mapState, mapActions, mapGetters } from "vuex"
	import { getToken, setToken, removeToken } from '@src/utils/auth.js'
	export default {
	    components: { TabbarLayout, UserHeader, UserOrder, UserTool, UserFooter, Xbutton, UserList},
	    computed: {
	        ...mapGetters(["isLogin"])
	    },
	    methods: {
	        ...mapActions(["fedLogOut"]),
	        loginOut() {
	            this.$iosConfirm({
	                text: "确定要退出吗？",
	                appendChildClass: "#page",
	            }).then(this.fedLogOut,sessionStorage.removeItem('lgins'))
	        }
	    }
	}
</script>

<style lang="less" scoped>
/deep/ .weui-tabbar{
    height: 50px;
}
.logout-btn {
  background: #fff;
  font-size: 16px;
  color: #464646;
  &::after {
    border-radius: inherit;
    border: none;
  }
}
</style>
