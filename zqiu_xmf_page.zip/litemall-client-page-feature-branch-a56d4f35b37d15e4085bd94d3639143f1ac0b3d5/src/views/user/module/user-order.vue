<template>
    <div class="user-order-box">
        <Ucell title="我的订单" :borderLine="true" :isLink="true" @click.native="$router.push('/order')">
            <span slot="desc">查看全部订单</span>
        </Ucell>

        <grid :no-border="true" :cols="4">
            <grid-item label="待付款" @click.native="$router.push('/order?showType=1')" :badge="orderBadge[101]">
                <icon class="order-icon" slot="icon" name="order-1" scale="3"></icon>
            </grid-item>
            <grid-item label="待发货" @click.native="$router.push('/order?showType=2')" :badge="orderBadge[201]">
                <icon class="order-icon" slot="icon" name="order-2" scale="3"></icon>
            </grid-item>
            <grid-item label="待收货" @click.native="$router.push('/order?showType=3')" :badge="orderBadge[301]">
                <icon class="order-icon" slot="icon" name="order-3" scale="3"></icon>
            </grid-item>
            <grid-item label="待评价" @click.native="$router.push('/order?showType=4')" :badge="orderBadge[409]">
                <icon class="order-icon" slot="icon" name="order-4" scale="3"></icon>
            </grid-item>
        </grid>

    </div>
</template>

<script>

import Ucell from '@src/components/base/u-cell'
import { Grid, GridItem } from "@src/components/base/grid"
import { getUserCenterData } from '@src/apis/user.js'
import { mapState, mapActions, mapGetters } from "vuex";
export default {
    components: { Ucell, Grid, GridItem },
    data() {
        return {
            orderBadge: {}
        }
    },
    computed: {
        ...mapGetters(["isLogin"])
    },
    async activated() {
        if (this.isLogin) {
            let data = await getUserCenterData();
            this.setData(data);
        }
    },
    methods: {
        setData(data) {
        	
//			return
            let orderBadge = {};
            let orderBadges = data.orderBadges || [];
            for (var i = 0; i < orderBadges.length; i++) {
                orderBadge[orderBadges[i]['orderStatus']] = orderBadges[i]['badgeNum'] || 0;
            }
            this.orderBadge = orderBadge
        }
    }
}
</script>

<style lang="less" scoped>
.user-order-box {
  background-color: #fff;
  font-size: 14px;
  a {
    color: #666;
  }
  // 图标控制
  .order-icon {
    display: block;
    margin: 0px auto;
  }
}
</style>
