<template>
    <div class="user-tool com-bottom-1px">

        <Ucell title="我的工具箱" :borderLine="true" :isLink="false">
            <span slot="desc"></span>
        </Ucell>

        <grid :no-border="true" :cols="4">
            <grid-item label="收货地址" @click.native="$router.push('/address')">
                <icon class="tool-icon" slot="icon" name="addres" style="color:red;" scale="3"></icon>
            </grid-item>
            <grid-item label="我的足迹" @click.native="$router.push('/user/browseHistory')">
                <icon class="tool-icon" slot="icon" name="tool-2" scale="3"></icon>
            </grid-item>
            <grid-item label="我的收藏" @click.native="$router.push('/user/collect')">
                <icon class="tool-icon" slot="icon" name="tool-3" scale="3"></icon>
            </grid-item>
            <grid-item label="我的钱包" @click.native="$router.push('/bank')">
                <icon class="tool-icon" slot="icon" name="tool-4" scale="3"></icon>
            </grid-item>
        </grid>

    </div>
</template>

<script>

import Ucell from '@src/components/base/u-cell'
import { Grid, GridItem } from "@src/components/base/grid";
export default {
    components: { Ucell, Grid, GridItem },
    data() {
        return {

        }
    }
}
</script>

<style lang="less" scoped>
.one-1px-90 {
  width: 90%;
  margin: 0 auto;
}

.user-tool {
  background-color: #fff;
  padding-bottom: 10px;
    font-size: 14px;
  a {
    color: #666;
  }

  // 图标控制
  .tool-icon {
    display: block;
    margin: 0px auto;
  }
}
</style>
