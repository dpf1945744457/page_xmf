<template>
  <div class="userList">
    <ul>
      <li class="order" @click="$router.push('/order')">
        <div class="icon"></div>
        <div class="content">
          <div class="text">订单中心</div>
        </div>
      </li>
      <li class="address" @click="$router.push('/address')">
        <div class="icon"></div>
        <div class="content">
          <div class="text">收货地址</div>
        </div>
      </li>
      <li class="foot" @click="$router.push('/user/browseHistory')">
        <div class="icon"></div>
        <div class="content">
          <div class="text">我的足迹</div>
        </div>
      </li>
      <li class="collection" @click="$router.push('/user/collect')">
        <div class="icon"></div>
        <div class="content">
          <div class="text">我的收藏</div>
        </div>
      </li>
      <!--<li class="wallet" @click="$router.push('/bank')">-->
      <li class="wallet" @click="myBank">
        <div class="icon"></div>
        <div class="content">
          <div class="text">我的钱包</div>
        </div>
      </li>
      <li class="contact">
        <div class="icon"></div>
        <div class="content">
          <div class="text" @click="contact">联系客服</div>
        </div>
      </li>
      <li class="set" @click="$router.push('/user/setting')">
        <div class="icon"></div>
        <div class="content">
          <div class="text">系统设置</div>
        </div>
      </li>
      <li class="contact1" @click="$router.push('/Aboutus')">
        <div class="icon"></div>
        <div class="content">
          <div class="text">关于我们</div>
        </div>
      </li>
      <!-- <li class="contact1" @click="$router.push('/Aboutus')">
        <div class="icon"></div>
        <div class="content">
          <div class="text">下载app</div>
        </div>
      </li> -->

      <li class="layout" @click="loginOut" v-if="isLogin">
        <div class="icon"></div>
        <div class="content">
          <div class="text">退出登录</div>
        </div>
      </li>
    </ul>
  </div>
</template>

<script>
import { mapState, mapActions, mapGetters } from "vuex";
import { getToken, setToken, removeToken } from "@src/utils/auth.js";
import { getBankURL } from "@src/apis/bank.js";
export default {
  computed: {
    ...mapGetters(["isLogin"])
  },
  methods: {
    ...mapActions(["fedLogOut"]),
    loginOut() {
      this.$iosConfirm({
        text: "确定要退出吗？",
        appendChildClass: "#page"
      }).then(this.fedLogOut, sessionStorage.removeItem("lgins"));
    },
    contact() {
      window.location.href =
        "https://im.7x24cc.com/phone_webChat.html?accountId=N000000013029&chatId=6aded8fa-f405-4371-8aba-c982f8fb7f8d";
    },
    myBank() {
      getBankURL({
        urlPath: window.location.href
      }).then(result => {
        window.location.href = result.url;
      });
    }
  }
};
</script>

<style lang="less" scoped>
.userList {
  margin-top: 10px;
  background: #ffffff;
  border-radius: 5px 5px 0 0;
  li {
    display: flex;
    height: 48px;
    line-height: 48px;
    font-family: PingFangSC-Regular;
    font-size: 16px;
    color: #333333;
    .icon {
      flex: 1;
    }
    .content {
      flex: 6;
      border-bottom: 1px solid #dcdcdc;
    }
    .text {
      margin-right: 15px;
      background: url(../../../assets/img/personalCenter/arrow_right@2x.png)
        no-repeat right center;
      background-size: 7px 12px;
    }
  }
  .order {
    .icon {
      background: url(../../../assets/img/personalCenter/icon__order@2x.png)
        no-repeat center center;
      background-size: 24px;
    }
  }
  .address {
    .icon {
      background: url(../../../assets/img/personalCenter/icon__address@2x.png)
        no-repeat center center;
      background-size: 24px;
    }
  }
  .foot {
    .icon {
      background: url(../../../assets/img/personalCenter/icon__footprint@2x.png)
        no-repeat center center;
      background-size: 24px;
    }
  }
  .collection {
    .icon {
      background: url(../../../assets/img/personalCenter/collect_active@2x.png)
        no-repeat center center;
      background-size: 24px;
    }
  }
  .wallet {
    .icon {
      background: url(../../../assets/img/personalCenter/icon_wallet@2x.png)
        no-repeat center center;
      background-size: 24px;
    }
  }
  .contact {
    .icon {
      background: url(../../../assets/img/personalCenter/contact_active@2x.png)
        no-repeat center center;
      background-size: 24px;
    }
  }
  .contact1 {
    .icon {
      background: url(../../../assets/img/icon_mine_aboutus@3x.png) no-repeat
        center center;
      background-size: 24px;
    }
  }
  .set {
    .icon {
      background: url(../../../assets/img/personalCenter/icon_set@2x.png)
        no-repeat center center;
      background-size: 24px;
    }
  }
  .layout {
    .icon {
      background: url(../../../assets/img/personalCenter/icon__signout@2x.png)
        no-repeat center center;
      background-size: 24px;
    }
    .content {
      border: none;
    }
  }
}
</style>