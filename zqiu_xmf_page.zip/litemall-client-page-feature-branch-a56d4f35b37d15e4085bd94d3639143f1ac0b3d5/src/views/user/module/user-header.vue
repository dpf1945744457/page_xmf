<template>
    <lazyBackgroundImages image-class="member-header-box" :image-source="require('@src/assets/img/personalCenter/member-top-bg.png')">
        <div class="backIcon" @click="onClickBack"></div>
        <div class="member-header-hd">
            <div class="avatar-img">
                <img v-if="isLogin" @click="$router.push('/user/setting')" :src="userInfo.avatarUrl || userInfo.headImg || require('@src/assets/img/user/default_user_header.png')" alt="">
                <img v-else :src="require('@src/assets/img/user/default_user_header.png')">
            </div>
            <div class="member-msg" v-if="isLogin">
                <div class="member-name">{{userInfo.nickName}}</div>
            </div>
            <div class="member-msg" v-else @click="clickLogins">
                <div class="member-name">立即登录</div>
            </div>
        </div>
        <!--<div class="member-header-right">-->
            <!-- <a href="javascript:void(0);" class="member-set"></a> -->
            <!--<router-link to="/user/setting" class="member-set"></router-link>-->
            <!-- <a href="javascript:void(0);" class="member-message"></a> -->
        <!--</div>-->
    </lazyBackgroundImages>
</template>

<script>
import lazyBackgroundImages from '@src/components/base/lazy-background-images'
import { mapState, mapActions, mapGetters } from "vuex";
import Cookies from 'js-cookie'
export default {
    components: { lazyBackgroundImages },
    computed: {
        ...mapGetters(["isLogin"]),
        ...mapState({
            userInfo: state => state.user.userInfo
        }),
    },
    methods: {
        ...mapActions(["getmallUserInfo"]),
        clickLogins(){
            sessionStorage.setItem('lgins', true)
            this.$router.push('/phoneLogin')
        },
        onClickBack() {
//			this.$nextTick(() => {
//				this.$router ? this.$router.back() : window.history.back();
//			})
			this.$router.push('/')
		}
        
    },

    async created() {
        if (this.isLogin) {
            this.getmallUserInfo();
        }
    },
    
}
</script>

<style lang="less" scoped>
.member-header-box {
  //   background: url(../../assets/img/user/member-top-bg.png) no-repeat;
  background-position: center bottom;
  background-repeat: no-repeat;
  //   background-size: cover;
  height: 150px;
  position: relative;
	.backIcon{
		margin-left: 16px;
		width: 40px;
		height: 40px;
		background: url(../../../svg/icon_return@2x.png) no-repeat left center;
		background-size: 20px;
	}
  .member-header-hd {
    position: absolute;
    top: 50%;
    width: 100%;
    transform: translateY(-50%);
    color: #fff;
    min-height: 56px;
    z-index: 1;
    display: flex;
    align-items: center;

    .avatar-img {
      margin-left: 15px;
      height: 58px;
      width: 58px;
      box-sizing: border-box;
      border-radius: 100%;
      overflow: hidden;
      border: 2px solid rgba(255, 255, 255, 0.4);
    }

    .member-grade span {
      position: relative;
      display: inline-block;
      margin-right: 3px;
      padding: 0 10px;
      height: 15px;
      line-height: 13px;
      vertical-align: middle;
      border-radius: 15px;
      font-size: 10px;
      color: #fff;
      background-color: rgba(180, 50, 27, 0.3);
      max-width: 100%;
      box-sizing: border-box;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      border: 1px solid #fff;
      margin-top: 0.3rem;
    }

    .member-name {
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
      color: #000;
      //   margin: 0.3rem auto 0;
      font-size: 0.8rem;
      line-height: 1rem;
    }

    .avatar-img img {
      display: block;
      height: 54px;
      width: 54px;
    }

    .member-msg {
      margin-left: 0.5rem;
    }
  }

  .member-header-right {
    position: absolute;
    top: 10px;
    right: 15px;

    .member-set {
      display: inline-block;
      height: 20px;
      width: 20px;
      background: url(../../../assets/img/user/member_set_icon.png);
      background-size: 20px;
    }
    .member-message {
      display: inline-block;
      height: 22px;
      width: 22px;
      background: url(../../../assets/img/user/message_icon.png);
      background-size: 22px;
      margin-left: 0.7rem;
    }
  }
}
</style>
