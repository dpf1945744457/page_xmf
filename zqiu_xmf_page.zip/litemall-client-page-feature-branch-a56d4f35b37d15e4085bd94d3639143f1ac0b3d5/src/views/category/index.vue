<template>
    <div>
        
        <TabbarLayout class="category-page">
            <!-- <Xheader>商品类目</Xheader> -->
            <indexHeader></indexHeader>
            <!-- 分类模块 -->
            <category
                :categoryId="categoryId"
                @change="change"
                :categoryList="categoryList"
                :currentCategory="currentCategory"
                :currentSubCategory="currentSubCategory"
                :currentSubCategoryss="currentSubCategorys"
                class="category"
            ></category>
        </TabbarLayout>
    </div>
</template>

<script>
import indexHeader from '../home/module/header';
import TabbarLayout from '@src/layouts/tabbar.vue';
import Xheader from '@src/components/base/x-header';
import Category from './module/category.vue';
import { getCategoryData, getCurrentCategoryData, postCollect123, getListLftData, getListAllData, getProductList, getClassifyTabs } from '@src/apis/product.js';
import historyReplaceState from '@src/utils/history-replace-state.js';
export default {
    components: { TabbarLayout, Xheader, Category, indexHeader },

    data() {
        return {
            categoryId: this.$route.query['categoryId'],
            //左侧分类
            categoryList: [],
            //当前分类
            currentCategory: {},
            //当前分类子分类
            currentSubCategory: [],
            currentSubCategorys: []
        };
    },
    async activated() {
        if (this.categoryList.length === 0) {
            let tempData = await getListAllData();
            this.categoryList = tempData.items;
            let data = await getListLftData();
            this.currentCategory = data.hotList;
            this.currentSubCategorys = data.comList;
            //处理字符串参数中过来的categoryId
            if (this.categoryId && this.categoryId != this.categoryList[0].id) {
                this.change({ id: this.categoryId });
            }
        }
    },
    methods: {
        //左侧菜单点击的时 触发请求
        async change(item) {
            if (item) {
                if (item.id == this.currentCategory.id) return;
                let data = await getProductList({
                    categoryId:'',	
                    page:1,
                    size:6,
                    classifyId: item.id,
                    goodsName:'',
                });
                this.currentCategory = data.cuurClassify || {};
                this.currentSubCategory = data.goodsList;
                historyReplaceState({ categoryId: item.id });
            } else {
                let data = await getListLftData();
                
                this.currentCategory = data.hotList;
                this.currentSubCategorys = data.comList;
            }
        }
    }
};
</script>

<style lang="less" scoped>
/deep/ .weui-tabbar{
    height: 50px;
}
.category-page {
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    margin: auto;

    display: flex;
    flex-direction: column;
/deep/ .com-bottom-1px::after{
        height: 0;
    }
    .category {
        flex: 1;
    }
}
</style>
