
// 按销量排序
// 按价格高低排序 或 0-99 100-499 500以上




export default [
    {
        name: '分类',
        icon: '',
        value: 'food',
        showTabHeader: false,
        defaultIcon: '',
        selectIcon: '',
        selectIndex: 0,
        tabs: [
            {
                icon: '',
                name: '',
                selectIndex: 0,
                detailList: [
                    {
                        name: '全部',
                        icon: '',
                        value: '全部',
                        selectIndex: 0,
                        list: [{
                            name: "全部",
                            value: 'all'
                        }]
                    },
                    {
                        name: '一级1',
                        icon: '',
                        value: '一级1',
                        selectIndex: 1,
                        list: [{
                            name: '全部',
                            value: 'all'
                        }, {
                            name: '二级1',
                            value: 'hot pot'
                        }, {
                            name: '二级1',
                            value: 'Sichuan cuisine'
                        }]
                    },
                    {
                        name: '一级2',
                        icon: '',
                        value: '一级2',
                        selectIndex: 2,
                        list: [{
                            name: '全部',
                            value: 'all'
                        }, {
                            name: '二级2',
                            value: 'pizza'
                        }, {
                            name: '二级2',
                            value: 'steak'
                        }]
                    }]
            },
        ]
    },

    {
        name: '综合',
        icon: '',
        value: 'food',
        showTabHeader: false,
        defaultIcon: 'icon-close',
        selectIcon: 'icon-success_black',
        selectIndex: 0,
        tabs: [
            {
                icon: '',
                name: '请选择',
                selectIndex: 0,
                detailList: [
                    {
                        name: '综合',
                        icon: 'icon-success_black',
                        value: '一级1',
                        selectIndex: 1,
                    }, {
                        name: '最新上架',
                        icon: 'icon-success_black',
                        value: '一级1',
                        selectIndex: 1,
                    }, {
                        name: '价格最低',
                        icon: 'icon-success_black',
                        value: '一级1',
                        selectIndex: 1,
                    }, {
                        name: '价格最高',
                        icon: 'icon-success_black',
                        value: '一级1',
                        selectIndex: 1,
                    }, {
                        name: '评价最多',
                        icon: 'icon-success_black',
                        value: '一级1',
                        selectIndex: 1,
                    }
                ]
            },
        ]
    },

    {
        name: '服务',
        icon: '',
        value: 'food',
        showTabHeader: false,
        defaultIcon: 'icon-close',
        selectIcon: 'icon-success_black',
        selectIndex: 0,
        type: "filter",
        tabs: [
            {
                icon: '',
                name: '请选择',
                selectIndex: 0,
                detailList: [
                    {
                        name: '一级1',
                        icon: '',
                        value: '一级1',
                        selectIndex: 1,
                    }, {
                        name: '一级1',
                        icon: '',
                        value: '一级1',
                        selectIndex: 1,
                    }, {
                        name: '一级1',
                        icon: '',
                        value: '一级1',
                        selectIndex: 1,
                    }
                ]
            },
            {
                icon: '',
                name: '请选择',
                selectIndex: 0,
                detailList: [
                    {
                        name: '一级1',
                        icon: '',
                        value: '一级1',
                        selectIndex: 1,
                    }, {
                        name: '一级1',
                        icon: '',
                        value: '一级1',
                        selectIndex: 1,
                    }, {
                        name: '一级1',
                        icon: '',
                        value: '一级1',
                        selectIndex: 1,
                    }
                ]
            },
        ]
    },

    // {
    //     name: '筛选',
    //     icon: '',
    //     value: 'food',
    //     showTabHeader: false,
    //     defaultIcon: '',
    //     selectIcon: '',
    //     selectIndex: 0,
    //     type: "filter",
    // }
]