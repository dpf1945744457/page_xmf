<!--  -->
<template>
    <HeaderLayout class='product-list-page'>
        <!-- 商品搜索 -->
        <!-- <HeaderSearch ref="HeaderSearch" @on-show-change="show=>isSearchStatus = show">
        </HeaderSearch> -->

        <div v-show="!isSearchStatus">
            <ProductListFilter></ProductListFilter>

            <!-- 商品列表 -->
            <!-- <ProductList :list="goodsList" @clickCartBtn="clickCartBtn"></ProductList> -->

            <!-- 商品为空 -->
            <Nodata v-if="noData" :imgurl="require('@src/assets/img/bg_empty_data.png')" content='暂无相关记录'></Nodata>

            <!-- Sku模块 -->
            <SkuModule ref="SkuModule"></SkuModule>

            <ViewFixedTool :showCartBar="true" :goodscount="goodscount"></ViewFixedTool>
        </div>
    </HeaderLayout>
</template>

<script>
import HeaderLayout from "@src/layouts/headerLayout.vue"
import HeaderSearch from '@src/components/public/header-search.vue'
import ViewFixedTool from '@src/components/base/view-fixed-tool'
import Nodata from "@src/components/base/no-data"
import ProductListFilter from './module/product-list-filter.vue'
import ProductList from './module/product-list.vue'
import { getCategoryTabs, getProductList } from '@src/apis/product.js'
import routeLeaveByisRoutePush from '@src/mixins/routeLeaveByisRoutePush.js'
import historyReplaceState from '@src/utils/history-replace-state.js'
import SkuModule from '@src/views/product-detail/module/skuModule/index.vue'
import { mapState, mapActions, mapGetters } from "vuex";
export default {
    components: { HeaderLayout, HeaderSearch, ProductListFilter, ViewFixedTool, ProductList, Nodata, SkuModule },
    mixins: [routeLeaveByisRoutePush],
    async beforeRouteEnter(to, from, next) {
        if (['product-detail', 'cart', 'user-login'].indexOf(from.name) !== -1 && from.meta.isRouterPush) {
            next();
        } else {
            let categoryId = to.query["categoryId"];
            let data = await getCategoryTabs({ id: categoryId });
            next(vm => { vm.setData(data) });
        }
    },
    beforeRouteLeave(to, from, next) {
        this.isOpenSkuModule({
            open: false
        });
        next();
    },
    computed: {
        ...mapState({
            goodscount: state => state.productDetail.goodscount
        }),
    },
    data() {
        return {
            categoryId: "",
            //当前父级总类
            parentCategory: {},
            //所有分类
            brotherCategory: [],
            //当前选中分类
            currentCategory: {},
            goodsList: [],
            noData: false,
            isSearchStatus: false,
        }
    },
    mounted() {
        // 获取购物车数量
        // this.getCartGoodscount();
    },
    methods: {
        // 初始化数据
        setData(data) {
            this.parentCategory = data.parentCategory;
            this.brotherCategory = data.brotherCategory;
            this.goodsList = [];
            this.noData = false;
            // 处理tab-item默认不选中的问题
            setTimeout(() => {
                this.currentCategory = data.currentCategory;
                this.loadData(this.currentCategory.id);
            }, 100)
        },

        // 根据id加载商品列表
        async loadData(categoryId) {
            this.categoryId = categoryId;
            let data = await getProductList({ categoryId: categoryId });
            this.goodsList = data.goodsList;
            this.noData = this.goodsList.length === 0;
            historyReplaceState({ categoryId: categoryId });
        },

        // 列表中点击购物车按钮
        ...mapActions(["getProductDetailById", "isOpenSkuModule", "addCart", "getCartGoodscount"]),
        async clickCartBtn(goods) {
            await this.getProductDetailById(goods.id);
            this.isOpenSkuModule({
                open: true,
                skuBtnType: "confirm"
            });
        }
    }
}
</script>
<style lang='less' scoped>
//@import url(); 引入公共css类
.product-list-page {
  //   margin-top: 47px;
}
</style>
