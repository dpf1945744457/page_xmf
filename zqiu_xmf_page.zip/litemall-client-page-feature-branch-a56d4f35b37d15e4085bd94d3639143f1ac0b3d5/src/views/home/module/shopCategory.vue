<template>
    <div class="ctaegory">
        <div class="box">
            <!-- <van-tabs @click="onClick"><van-tab v-for="(item, index) in classifyList" :key="index" :title="item.name"></van-tab></van-tabs> -->
            <div class="shop_box" ref="shopScroll" v-for="(item, index) in classifyGroupList" :key="index" v-show="item.goodsList.length">
                <div class="shop_header"><van-image lazy-load :src="item.classifyPics" /></div>
                <div class="swiperBox">
                    <div class="title_box" @click="$router.push({ path: '/product', query: { classifyId: item.classifyId } })">
                        查看全部
                        <van-icon name="arrow" />
                    </div>
                    <swiper :options="swiperOption">
                        <swiper-slide v-for="(i, index) in item.goodsList" :key="index">
                            <div class="shop" @click="$router.push({ path: '/product/' + i.id })">
                                <van-image lazy-load class="imgs" :src="i.picUrl" />
                                <p>{{ i.name }}</p>
                                <p>HK${{ i.retailPrice | filterPrice}}</p>
                            </div>
                        </swiper-slide>
                    </swiper>
                </div>
            </div>
        </div>
        <div class="fix_bottom"></div>
    </div>
</template>

<script>
import { mapState, mapActions, mapGetters } from 'vuex';
import { Tab, Tabs, Swipe, SwipeItem, Icon } from 'vant';
import 'swiper/dist/css/swiper.css';
import { swiper, swiperSlide } from 'vue-awesome-swiper';
// import BScroll from 'better-scroll';
export default {
    data() {
        return {
            active: 0,
            scroll: '',
            swiperOption: {
                slidesPerView: 3,
                spaceBetween: 30,
                freeMode: true,
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true
                }
            }
        };
    },
    filters: {
		filterPrice: function(num) {
			return Number(num).toFixed(2);
		}
	},
    components: {
        Tab,
        Tabs,
        Icon,
        swiper,
        swiperSlide
    },
    computed: {
        ...mapState({
            classifyList: state => state.home.classifyList
        }),
        ...mapState({
            classifyGroupList: state => state.home.classifyGroupList
        })
    },
    mounted() {
    	
    },

    methods: {
        onClick(index) {
            this.$emit('getIndex', index);
        },
        handleScroll() {}
    }
};
</script>

<style lang="less" scoped>
.ctaegory {
    .box {
        .tab {
        }
        .shop_box {
            /deep/ .swiper-container {
                height: 106px;
                padding-left: 14px;
            }
            /deep/ .swiper-slide {
                width: 56px !important;
                margin-right: 34px !important;
                .shop {
                    width: 56px;
                    display: inline-block;
                    .imgs {
                        width: 56px;
                        height: 56px;
                    }
                    p {
                        font-size: 12px;
                        text-align: center;
                        line-height: 20px;
                        color: #666666;
                        width: 100%;
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                    }
                    p:nth-of-type(2) {
                        text-align: center;
                        line-height: 20px;
                        color: #e30a17;
                    }
                }
            }
        }
    }
    .shop_header {
        height: 120px;
        display: flex;
        align-content: center;
        justify-content: center;
        img {
            width: 100%;
        }
    }
    .swiperBox {
        width: 94%;
        margin: 0 auto;
        margin-top: -30px;
        position: relative;
        border-radius: 7px;
        background-color: #fff;
        margin-bottom: 13px;
    }
    .title_box {
        text-align: right;
        height: 34px;
        line-height: 34px;
        padding-right: 30px;
        color: #999999;
        background: #fff;
        position: relative;
        border-radius: 7px;
        /deep/ .van-icon {
            position: absolute;
            top: 0;
            bottom: 0;
            right: 15px;
            margin: auto;
            display: flex;
            justify-content: center;
            align-items: center;
        }
    }
    .scroll_box {
        width: 100%;
        height: 133px;
        overflow-x: scroll;
        .scrolls {
            width: 1000px;
            height: 100%;
        }
    }
    
}
</style>
