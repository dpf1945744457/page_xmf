<template>
    <div class="shop">
        <div class="img_box" v-for="(item,index) in classifyList" :key='index'   @click="$router.push({ path: '/product', query: { classifyId: item.id } })">
            <!-- <van-image lazy-load :src="item.icon" /> -->
            <img class="img" :src="item.icon"  v-lazy="item.icon">
            <p>{{item.name}}</p>
        </div>
    </div>
</template>

<script>
import { mapState, mapActions, mapGetters } from 'vuex';
export default {
    components: {
    },
    computed: {
        ...mapState({
            classifyList: state => state.home.classifyList
        }),
    },
    data() {
        return {
        };
    },
    mounted() {},
    methods: {}
};
</script>

<style lang="less" scoped>


.shop {
    position: relative;
    background: #ffffff;
    border-radius: 7px;
    // width: 342px;
    // height: 182px;
    padding: 13px 10px;
    box-sizing: border-box;
    margin: 13px 10px;
    // margin-top: -20px;
    display: flex;
    flex-wrap: wrap;
    .img_box{
        display: inline-block;
        padding: 0 10px;
        width: 17vw;
        margin-bottom: 10px;
        /deep/ .van-image__img{
            width: 50px;
            margin: 0 auto;
        }
        /deep/ .van-image{
            display: block;
        }
        .img{
           width: 70px;
           margin: 0 auto;
        }
        p{
            font-size: 12px;
            text-align: center;
        }
    }
}

@media screen and (max-width : 374px) {
    .shop {
        position: relative;
        background: #ffffff;
        border-radius: 7px;
        // width: 342px;
        // height: 182px;
        padding: 13px 10px;
        box-sizing: border-box;
        margin: 13px 10px;
        // margin-top: -20px;
        display: flex;
        flex-wrap: wrap;
        .img_box{
            display: inline-block;
            padding: 0 10px;
            width: 15vw;
            margin-bottom: 10px;
            /deep/ .van-image__img{
                width: 50px;
                margin: 0 auto;
            }
            /deep/ .van-image{
                display: block;
            }
            .img{
                width: 60px;
                margin: 0 auto;
            }
            p{
                font-size: 12px;
                text-align: center;
            }
        }
    }
}
</style>
