<!-- 品牌制造商直供 -->
<template>
    <div>
        <Title>品牌制造商直供</Title>
        <div class='brandList clearfix'>
            <a href="javascript:void(0);" v-for="(item,index) in brandList" :key="index" :style="{backgroundImage:`url(${item.picUrl})`}">
                <p>{{item.name}}</p>
                <small>{{item.floorPrice}}元起</small>
            </a>
        </div>
    </div>
</template>

<script>
import Title from './title.vue'
import { mapState, mapActions, mapGetters } from "vuex";
export default {
    components: { Title },
    computed: {
        ...mapState({ brandList: state => state.home.brandList }),
    },
}
</script>
<style lang='less' scoped>
.brandList {
  min-height: 240px;
  a {
    display: block;
    float: left;
    width: 50%;
    height: 120px;
    padding: 10px;
    box-sizing: border-box;
    color: #fff;
    background-repeat: no-repeat;
    background-size: cover;
    border: 1px solid #fff;
  }
}
</style>