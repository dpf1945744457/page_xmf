<template>
    <div class="recommend">
        <div class="recomBox">
            <!-- <div class="left">
                <div class="title">
                    <span>限时秒杀</span>
                    <van-count-down :time="time"></van-count-down>
                </div>
                <div class="time_shop">
                    <img src="https://img.yzcdn.cn/vant/cat.jpeg">
                    <p><span>HK$78</span><del>HK$108</del></p>
                </div>
                <div class="time_shop">
                    <img src="https://img.yzcdn.cn/vant/cat.jpeg">
                    <p><span>HK$78</span><del>HK$108</del></p>
                </div>
            </div> -->
            <div class="right left" style="border-left: 0">
                <div class="title">
                    <span>评价最好的商品</span>
                </div>
                <div class="time_shop" v-for="(item, index) in extendList.favList" :key="index" @click="hrefFunc(item)">
                    <img :src="item.picUrl">
                    <p>{{item.name}}</p>
                </div>
            </div>
            <div class="right left" >
                <div class="title">
                    <span>最新商品</span>
                </div>
                <div class="time_shop" v-for="(item, index) in extendList.newList" :key="index" @click="hrefFunc(item)">
                    <img :src="item.picUrl">
                    <p>{{item.name}}</p>
                </div>
            </div>
        </div>
        <div class="type">
            <div class="type_box">
                <p>最热门商品</p>
                <img :src="item.picUrl" v-for="(item, index) in extendList.hotList" :key="index" @click="hrefFunc(item)">
            </div>
            <div class="type_box">
                <p>最优惠商品</p>
                <img :src="item.picUrl" v-for="(item, index) in extendList.lowList" :key="index" @click="hrefFunc(item)">
            </div>
            <div class="type_box">
                <p>严选商品</p>
                <img :src="item.picUrl" v-for="(item, index) in extendList.higList" :key="index" @click="hrefFunc(item)">
            </div>
        </div>
    </div>
</template>

<script>
import { CountDown } from 'vant';
import { mapState, mapActions, mapGetters } from 'vuex';
export default {
    components: {
        CountDown
    },
    props:['extendList'],
    computed: {
        ...mapState({ banner: state => state.home.banner })
    },
    data() {
        return {
            time: 3 * 60 * 60 * 1000,
        };
    },
    mounted() {
    },
    methods: {
        hrefFunc(item){
            this.$router.push({ path: '/product/'+item.id })
        },
    }
};
</script>

<style lang="less" scoped>
.recommend {
    // width: 355px;
    height: 240px;
    margin: 0 auto;
    margin: 13px 10px;
    padding: 10px 0px 10px 0px;
    box-sizing: border-box;
    margin-bottom: 17px;
    background-color: #fff;
    border-radius: 8px;
    .recomBox {
        height: 120px;
        border-bottom: 1px solid #ededed;
        box-sizing: border-box;
        display: flex;
        .left {
            flex: 1;
            .title {
                span {
                    font-weight: 600;
                    font-size: 16px;
                    color: #666666;
                    text-align: center;
                    line-height: 16px;
                    float: left;
                }
                /deep/ .van-count-down,
                .van-divider {
                    color: #ff4a10;
                }
            }
            .time_shop{
                width: 49%;
                height: 80%;
                display: inline-block;
                float: left;
                padding-top: 10px;
                box-sizing: border-box;
                img{
                    display: block;
                    width: 56px;
                    height: 56px;
                    margin: 0 auto;
                }
                p{
                    text-align: center;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    font-size: 12px;
                        margin-top: 8px;
                    span{
                        color: #FF4A10;
                    }
                    del{
                        font-size: 10px;
                    }
                }

            }
        }
        .right {
            flex: 1;
            border-left: 1px solid #ededed;
            width: 44vw;
            .title {
                width: 100%;
                height: 20px;
                padding-left: 10px;
                span {
                    display: block;
                }
                p{
                    font-size: 12px;
                    color: #999999;
                    text-align: center;
                    line-height: 10px;
                }
            }
        }
    }
    .type{
        height: 120px;
        display: flex;
        .type_box:nth-last-of-type(1){
            border: none;
        }
        .type_box{
            flex: 1;
            font-size: 16px;
            color: #666666;
            line-height: 36px;
            text-align: center;
            border-right: 1px solid #EDEDED;
            p{
                font-family: PingFang-SC-Heavy;
                font-weight: 600;
            }
            img{
                display: block;
                margin: 0 auto;
                width: 64px;
                height: 64px;
            }
        }
    }

}
</style>
