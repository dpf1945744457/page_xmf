<template>
    <Swiper :list="banner" :loop="true" :auto="true" :show-desc-mask="descMask" height="210px" @on-click-list-item="clickListItem"></Swiper>
</template>

<script>
import { Swiper } from '@src/components/base/swiper'
import { mapState, mapActions, mapGetters } from "vuex";
export default {
    components: { Swiper },
    computed: {
        ...mapState({ banner: state => state.home.banner }),
    },
    data() {
        return {
            descMask: false
        }
    },
    mounted() {
        this.banner.map(item => {
            if (item.title.replace(/\s/, "")) {
                this.descMask = true;
            }
        })
    },
    methods: {
        clickListItem(item) {
            // 情况一 ：http://test19.qtopay.cn/client#/product/1181018
            let path = item.url.split("#")[1];

            console.info(item)

            if (path) {
                this.$router.push(path);
            }
            // 情况二 ： http://www.baidu.com
            else if (item.url) {
              // // window.location.href = item.url;
              this.$router.push({path:item.url});
            }
        }
    }
}
</script>

<style lang="less" scoped="scoped">
    /deep/ .vux-indicator-right{
        position: absolute !important;
        bottom: 30px !important;
    }
</style>
