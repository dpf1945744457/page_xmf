<template>
	<div class="header">
		<Xheader class="header-fix headerIndex" :leftOptions="{ showBack: false }">
			<!-- <a slot="left" @click="$router.push('/cart')"><img src="../../../svg/cart-2.svg" /></a> -->
			<!--<a slot="left" @click="show = !show"><img src="../../../assets/img/classify_icon @2x.png" /></a>-->
			<a slot="left" @click="onScanCode" ><img src="../../../assets/img/icon__saomiao@2x.png" /></a>
			<van-search placeholder="请输入搜索关键词" @click="$router.push('/search')" disabled v-model="value" />
			<a slot="right" @click="$router.push('/user')"><img src="../../../assets/img/log in_icon@2x.png" /></a>
		</Xheader>
		<div class="fix_header"></div>
		<van-popup v-model="show">
			<!-- <div class="test"></div> -->
			<ul>
				<span class="arrow-top"></span>
				<li class="list" v-for="(item, index) in categoryList" :key="index" @click="$router.push({path:'/product',query:{categoryId:item.id}})">
					<div class="item-list" @click="toMenuDetails(item.link)">
						<img class="item-list-img" :src="item.iconUrl" />
						<img src="" />
						<span>{{ item.name }}</span>
					</div>
				</li>
			</ul>
		</van-popup>
	</div>
</template>

<script>
	import Xheader from '@src/components/base/x-header';
	import { Popup, Search } from 'vant';
	import { mapState, mapActions, mapGetters } from 'vuex';
	import { scanCode, scanCodeResult } from '@src/utils/scanCode.js'
	import { isAPPOrOther } from '@src/utils/wx.js'
	export default {
		data() {
			return {
				show: false,
				menus: [],
				value: '',
			};
		},
		computed: {
			...mapState({
				categoryList: state => state.home.categoryList
            }),
            currentSourceIsApp() {
                return this.$store.state.home.getCurrentSourceIsApp
            }
		},
		components: {
			Xheader,
			Popup,
			Search
		},
		mounted() {},

		methods: {
			toMenuDetails() {},
			onScanCode() {
				if(this.currentSourceIsApp){
					scanCode()
				} else {
                    this.$toast('网页版暂不支持扫一扫')
                }
			},
			isWeixin() {
			    var ua = window.navigator.userAgent.toLowerCase();
			    if (ua.match(/MicroMessenger/i) == 'micromessenger') {
			        return true;
			    } else {
			        return false;
			    }
			}
		}
	};
</script>

<style lang="less" scoped="scoped">
	.header {
		/deep/ .vux-header-title {
			margin: 0 55px;
		}
		.headerIndex {
			background: url('../../../assets/img/navigationbar@2x.png') no-repeat !important;
			background-size: cover;
			border: none;
		}
		.fix_header {
			height: 44px;
		}
		/deep/ .van-search {
			margin-top: 2px;
			padding: 0;
			border-radius: 30px;
			overflow: hidden;
			
		}
		/deep/ .van-field__control {
			line-height: 24px;
		}
		/deep/ .van-popup {
			position: fixed;
			left: 85px;
			top: 180px;
			border-radius: 5px;
			min-height: 250px;
			padding: 10px 15px 10px;
			box-sizing: border-box;
			overflow-y: initial;
			ul {
				position: relative;
				.arrow-top {
					position: absolute;
					top: -16px;
					width: 0;
					height: 0;
					border-left: 6px solid transparent;
					border-right: 6px solid transparent;
					border-bottom: 6px solid #fff;
					font-size: 0;
					line-height: 0;
				}
				.list {
					width: 125px;
					height: 44px;
					.item-list {
						height: 44px;
						line-height: 44px;
						border-bottom: 1px solid #eeeeee;
						.item-list-img {
							width: 30px;
							display: inline-block;
							position: relative;
						}
						span {
							margin-left: 6px;
							font-size: 14px;
							color: #333333;
						}
					}
				}
			}
		}
		.test {
			width: 300px;
			height: 300px;
			background: #fff;
			position: absolute;
			left: 0;
		}
	}
</style>