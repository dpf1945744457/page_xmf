<template>
  <div class="headerNav" :class="{'fixStyle' : true}">
    <ul>
      <li @click="getTabList('')" :class="{'active' : (activeId == null||activeId=='')}">
        <div class="title">全部</div>
        <div class="line" v-if="(activeId == null||activeId=='')"></div>
      </li>
      <li
        v-for="(item,index) in tabLists"
        @click="getTabList(item)"
        :class="{'active' : activeId == item.id}"
        :key="index"
      >
        <div class="title">{{item.name}}</div>
        <div class="line" v-if="activeId == item.id"></div>
      </li>
    </ul>
  </div>
</template>
<script>
import { getAllListData } from "@src/apis/home.js";
import Bus from "@src/apis/Bus.js";

export default {
  props: {
    styleText: {
      type: Boolean
    }
  },
  data() {
    return {
      tabLists: [],
      activeId: "",
      show: false
    };
  },
  async created() {
    if (this.tabLists.length === 0) {
      let tempData = await getAllListData();
      console.log(tempData);

      this.tabLists = tempData.items;
    }
  },

  methods: {
    getTabList(tabId) {
      this.activeId = tabId.id;
      Bus.$emit("classifyId", tabId);
    },
    
  }
};
</script>

<style lang="less" scoped="scoped">
.divcont {
  background: url("./pop_bg.png");
  background-size: 100% 100%;
  padding: 50px 30px;
}
.fixStyle {
  top: 0 !important;
  opacity: 1 !important;
}
.headerNav {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 44px;
  background: #f7cf20;
  font-family: PingFang-SC-Medium;
  font-size: 17px;
  color: #ffffff;
  overflow: hidden;
  z-index: 888;
  opacity: 0;
  ul {
    /*兼容性*/
    display: -webkit-box;
    /* Chrome 4+, Safari 3.1, iOS Safari 3.2+ */
    display: -moz-box;
    /* Firefox 17- */
    display: -webkit-flex;
    /* Chrome 21+, Safari 6.1+, iOS Safari 7+, Opera 15/16 */
    display: -moz-flex;
    /* Firefox 18+ */
    display: -ms-flexbox;
    /* IE 10 */
    display: flex;
    /* Chrome 29+, Firefox 22+, IE 11+, Opera 12.1/17/18, Android 4.4+ */

    -webkit-box-align: middle;
    -ms-flex-align: middle;
    align-items: middle;
    /*overflow: auto;*/
    overflow-x: scroll;
    -webkit-overflow-scrolling: touch;
    li {
      float: left;

      -webkit-box-flex: 0 0 22%;
      -webkit-flex: 10 0 22%;
      -ms-flex: 0 0 22%;
      flex: 0 0 22%;

      text-align: center;
      -ms-flex-negative: 0;
      flex-shrink: 0;
      .title {
        margin: 14px 0 4px;
      }
      .line {
        margin: 0 auto;
        width: 16px;
        height: 2px;
        background: #ff4a10;
        border-radius: 1px;
      }
    }
    .active {
      font-family: PingFang-SC-Bold;
      color: #ff4a10;
    }
  }
  ul::-webkit-scrollbar {
    display: none;
  }
}
</style>