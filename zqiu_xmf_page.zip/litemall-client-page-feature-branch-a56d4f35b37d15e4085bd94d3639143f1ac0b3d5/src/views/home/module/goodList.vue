<template>
    <div class="goods-list m-t-10 clearfix">
        <Title>
            <slot></slot>
        </Title>
        <GoodsItem v-for="(item,index) in list.slice(0,10)" :key="index" :item="item" @click.native="$router.push({path:`/product/${item.id}`})"></GoodsItem>
    </div>
</template>

<script>
import GoodsItem from '@src/components/base/goodsItem/index.vue'
import Title from './title.vue'
export default {
    props: ["list"],
    components: { GoodsItem, Title },

}
</script>

<style lang="less" scoped>
.goods-list {
  min-height: 150px;
}
</style>
