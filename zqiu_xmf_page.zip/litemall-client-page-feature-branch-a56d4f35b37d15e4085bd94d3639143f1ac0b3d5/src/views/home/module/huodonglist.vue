<template>
  <div style="background: #3d1667;">
    <div class="top">
      <!-- <img src="./pic_top.png" alt="" /> -->
    </div>
    <div class="center">
      <div
        style="
          background: #fff;
          padding: 5px;
          height: 120px;
          border-radius: 5px;
          margin-bottom: 10px;
        "
        v-for="(item, index) in list"
        :key="index"
        @click="toUrl(item.id)"
      >
        <van-row>
          <van-col span="12">
            <div style="padding: 5px">
              <img
                :src="item.picUrl"
                alt=""
                style="width: 140px; height: 105px"
              />
            </div>
          </van-col>
          <van-col span="12">
            <van-col span="24">
              <span
                style="
                  color: #333;
                  font-size: 16px;
                  font-family: PingFangSC-Medium;
                  font-weight: bold;
                  text-overflow: -o-ellipsis-lastline;
                  overflow: hidden;
                  text-overflow: ellipsis;
                  display: -webkit-box;
                  -webkit-line-clamp: 2;
                  line-clamp: 2;
                  -webkit-box-orient: vertical;
                  height: 42px;
                "
                >{{ item.name }}</span
              >
            </van-col>
            <van-col span="12" style="margin-top: 5px">
              <van-tag
                round
                color="#feedec"
                v-if="item.freeShipping == 1"
                text-color="#FB4D44"
                type="primary"
                >包邮</van-tag
              >
              <van-tag
                text-color="#FB4D44"
                v-if="item.taxFlag == 1"
                color="#feedec"
                round
                type="primary"
                >包税</van-tag
              >
            </van-col>
            <van-col span="12" style="text-align: right; margin-top: 5px">
              <span style="font-size: 12px; color: #999999"
                >销量 <span>{{ item.salesNum }}</span></span
              >
            </van-col>
            <van-col span="24" style="margin-top: 5px">
              <span
                style="
                  font-size: 12px;
                  color: #999999;
                  text-decoration: line-through;
                "
                >HK$<span>{{ item.counterPrice }}</span></span
              >
            </van-col>
            <van-col span="24" style="margin-top: 5px; position: relative">
              <span style="font-size: 16px; color: #fb4d44"
                >HK$<span style="font-size: 20px">{{
                  item.counterPrice
                }}</span></span
              >
              <!-- <img
                :src="carred"
                alt=""
                width="30px"
                style="width: 30px; position: absolute; right: 0px; bottom: 0px"
              /> -->
              <van-button round type="info" color="red"  style="width:70px; position: absolute; right: 0px; bottom: 0px" size="mini">立即购买</van-button>
            </van-col>
          </van-col>
        </van-row>
      </div>
      <div style="height:40px"></div>
    </div>
  </div>
</template>

<script>
import { goodsevent } from "@src/apis/home.js";
import carred from "./icon_sy_carred.png";
export default {
  name: "",
  data() {
    return {
      list: [],
      carred: carred,
    };
  },
  components: {},
  created() {
    let data = { eventName: "mid_autumn" };
    goodsevent(data).then((result) => {
      this.list = result;
      console.log(result);
    });
  },
  mounted() {},
  methods: {
    toUrl(id) {
      this.$router.push({
        path: `/product/${id}`,
      });
    },
  },
};
</script>
<style  scoped>
.top{background: url("./pic_top.png");height: 400px; background-size: 100% 100%;}
.top img {
  display: block;
  width: 100%;
}
.center {
  width: 94%;
  margin: 0px auto;
  margin-top: -90px;
 
}
</style>
