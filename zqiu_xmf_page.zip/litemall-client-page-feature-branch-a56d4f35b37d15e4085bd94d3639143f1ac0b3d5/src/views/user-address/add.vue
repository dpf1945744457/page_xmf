<!--  -->
<template>
  <HeaderLayout>
    <Xheader class="header-fix" :title="$route.meta.title" @isBack="onBack">
      <span v-if="type == 'EDIT'" @click="deleteAddress" slot="right" class="delete-but-mini">删除</span>
    </Xheader>

    <div class="find-password" v-if="defaultVisible">
      <p style="color:red;padding-left: 10px;">*请填写真实姓名及身份证号，否则影响商品清关</p>
      <UinputSlot
        v-model="address.name"
        label="姓名"
        placeholder="请输入收货人姓名"
        :topLine="true"
        maxlength="20"
      ></UinputSlot>
      <UinputSlot
        v-model="address.mobile"
        label="手机号"
        placeholder="请输入收货人手机号"
        :topLine="true"
        maxlength="12"
      ></UinputSlot>
      <UinputSlot
        :disabled="true"
        @click.native="$refs['citys-picker'].open()"
        v-model="addressStr"
        label="地区"
        placeholder="请选择地区"
        :topLine="true"
        maxlength="200"
      >
        <icon slot="right-icon" scale="2" name="linkright"></icon>
      </UinputSlot>
      <Utextarea
        v-model="fillAddress || address.address"
        label="详细地址"
        placeholder="请输入收货人详细地址"
        :topLine="true"
        maxlength="50"
      ></Utextarea>
      <UinputSlot
        v-model="address.postalCode"
        label="邮政编码"
        placeholder="请输入邮政编码"
        :topLine="true"
        maxlength="6"
      ></UinputSlot>
      <UinputSlot
        v-model="address.personCard"
        label="身份证号"
        placeholder="请输入身份证号"
        :topLine="true"
        maxlength="19"
      ></UinputSlot>
      <div class="default-checked top-10">
        <CheckIcon :value.sync="address.isDefault"></CheckIcon>设置为默认
      </div>
      <Xbutton
        type="my"
        style="background: #e0443b;"
        class="submit-btn top-50"
        @click.native="saveAddress"
        :disabled="$store.state.showLoading"
        recta
      >确 定</Xbutton>
      <Xbutton
        v-if="APP.isWeixin"
        type="primary"
        class="submit-btn top-10 hiddenWeixin"
        @click.native="$refs.WxJssdk.getConfig()"
        :disabled="btnLoading"
        :show-loading="btnLoading"
      >一键获取微信地址</Xbutton>
      <citys-picker
        :city="cityData"
        :init-value="defaultCityVal"
        @confirm="confirm"
        ref="citys-picker"
      ></citys-picker>
    </div>

    <WxJssdk
      v-if="APP.isWeixin"
      ref="WxJssdk"
      :autoReady="false"
      @on-ready="openAddress"
      @on-loading="v=>btnLoading=v"
    ></WxJssdk>
  </HeaderLayout>
</template>

<script>
import HeaderLayout from "@src/layouts/headerLayout.vue";
import Xheader from "@src/components/base/x-header";
import UinputSlot from "@src/components/base/u-input-slot";
import CheckIcon from "@src/components/base/check-icon";
import linkbutton from "@src/components/base/linkbutton";
import Xbutton from "@src/components/base/x-button";
import Utextarea from "@src/components/base/u-textarea";
require("@src/components/base/vue-city-bspicker/vue-citys-picker.css");
import CitysPicker from "@src/components/base/vue-city-bspicker";
import { cityCode } from "@src/utils/cityCode.js";
import regExp from "@src/utils/regExp.js";
import {
  getAddressDetail,
  postAddressSave,
  postAddressDelete,
  getAddressData
} from "@src/apis/address.js";
export default {
  layout: "tabbar",
  components: {
    HeaderLayout,
    UinputSlot,
    Xheader,
    CheckIcon,
    CitysPicker,
    linkbutton,
    Xbutton,
    Utextarea,
    WxJssdk: () =>
      import(
        /* webpackChunkName: "wx-jssdk" */ "@src/components/public/wx-jssdk.vue"
      )
  },
  data() {
    return {
      btnLoading: false,
      cityData: [],
      defaultVisible: false,
      id: this.$route.query["id"],
      // pageType: this.$route.query["pageType"],
      type: this.$route.query["type"],
      addressStr: "",
      address: {
        // id: 0,
        isDefault: true,
        address: "",
        mobile: "",
        postalCode: "",
        personCard: "",
        name: "",
        provinceId: "",
        areaId: "",
        cityId: "",
        provinceName: "",
        cityName: "",
        countyName: ""
      },
      defaultCityVal: [
        {
          name: "北京",
          value: "110000"
        },
        {
          name: "北京市",
          value: "110100"
        },
        {
          name: "昌平区",
          value: "110114"
        }
      ],
      fillAddress: "",
      isFalse: false
    };
  },

  async beforeRouteEnter(to, from, next) {
    let type = to.query["type"];
    let data = "";
    if (type == "EDIT") {
      data = await getAddressDetail({ id: to.query["id"] });
    }
    next(vm => {
      getAddressData().then(cityData => {
        vm.cityData = cityData;
        if (type == "EDIT") {
          vm.setData(data);
        }
        if (type == "ADD") {
          vm.addView();
        }
      });
    });
  },

  methods: {
    // 返回上一页
    onBack() {
      this.$router.go(-1);
    },

    deleteAddress() {
      this.$iosConfirm({
        title: "地址删除",
        text: "确定要删除这条地址信息吗？",
        appendChildClass: "#page"
      }).then(async () => {
        await postAddressDelete({ id: this.id });
        this.$router.go(-1);
      });
    },
    addView() {
      this.defaultVisible = true;
    },
    setData(data) {
      let cityData = this.cityData;
      let provinceName = cityCode(cityData, data.provinceId);
      let cityName = cityCode(cityData, data.cityId);
      let areaName = cityCode(cityData, data.districtId);
      let detailAddress = provinceName + cityName + areaName;
      this.$set(this.$data, "defaultCityVal", [
        {
          name: provinceName,
          value: data.provinceId + ""
        },
        {
          name: cityName,
          value: data.cityId + ""
        },
        {
          name: areaName,
          value: data.districtId + ""
        }
      ]);

      this.addressStr = provinceName + "-" + cityName + "-" + areaName;
      this.$set(this.address, "id", data.id);
      this.$set(this.address, "isDefault", data.isDefault);
      this.$set(this.address, "mobile", data.mobile);
      this.$set(this.address, "name", data.name);
      this.$set(this.address, "provinceId", data.provinceId);
      this.$set(this.address, "areaId", data.areaId);
      this.$set(this.address, "cityId", data.cityId);
      this.$set(this.address, "address", data.address);
      this.$set(this.address, "postalCode", data.postalCode);
      this.$set(this.address, "personCard", data.personCard);
      this.$set(this.address, "provinceName", provinceName);
      this.$set(this.address, "cityName", cityName);
      this.$set(this.address, "countyName", areaName);
      this.$set(this.address, "detailAddress", detailAddress);
      this.defaultVisible = true;
    },
    saveAddress() {
      if (this.isFalse) return;
      let address = this.address;
      this.$set(
        this.address,
        "detailAddress",
        address.detailAddress + address.address
      );
      // if (!regExp.name.reg.test(address.name)) {
      //     this.$toast(regExp.name.errMsg)
      //     return false
      // }

      if (!regExp.name.reg.test(address.name)) {
        this.$toast("收货人姓名只能包含英文或中文");
        return false;
      }
      if (
        !regExp.mobile.reg.test(address.mobile) &&
        !regExp.HKmobile.reg.test(address.mobile)
      ) {
        this.$toast(regExp.mobile.errMsg);
        return false;
      }
      if (address.provinceName == "") {
        this.$toast("请选择收货地区");
        return false;
      }
      if (address.address == "") {
        this.$toast("请输入正确的收货地址");
        return false;
      }
      if (address.postalCode == "" || address.postalCode == undefined) {
        this.$toast("请输入邮政编码");
        return false;
      }
      if (address.personCard != "") {
        if (regExp.personId.testid(address.personCard).status == 0) {
          this.$toast(regExp.personId.testid(address.personCard).msg);
          return false;
        }
      } else {
        this.$toast("请输入正确的身份证号");
        return false;
      }

      this.isFalse = true;
      postAddressSave({ ...address }).then(res => {
        this.isFalse = false;
        if (res.errno) {
          this.$toast(res.errmsg);
        } else {
          this.$router.go(-1);
        }
      });
    },
    cancelHandle() {
      this.$router.go(-1);
    },
    confirm(values) {
      let area = values[2].name ? `-${values[2].name}` : "";
      this.addressStr = values[0].name + "-" + values[1].name;
      this.addressStr = this.addressStr + area;
      let provinceName = values[0].name ? values[0].name : "";
      let cityName = values[1].name ? values[1].name : "";
      let countyName = values[2].name ? values[2].name : "";
      let detailAddress = provinceName + cityName + countyName;
      this.$set(this.address, "provinceName", provinceName);
      this.$set(this.address, "cityName", cityName);
      this.$set(this.address, "countyName", countyName);
      this.$set(this.address, "provinceId", values[0].value);
      this.$set(this.address, "cityId", values[1].value);
      this.$set(this.address, "areaId", values[2].value ? values[2].value : "");
      this.$set(this.address, "detailAddress", detailAddress);
    },
    openAddress() {
      // let data = {
      //     errMsg: "openAddress:ok",
      //     userName: "大喊大叫",
      //     postalCode: "100010",
      //     provinceName: "北京市",
      //     cityName: "北京市",
      //     countryName: "东城区",
      //     detailInfo: "不仅解决",
      //     nationalCode: "110101",//收货地址国家码。
      //     telNumber: "13333333333"//收货人手机号码。
      // }

      this.$refs.WxJssdk.openAddress(data => {
        this.setData({
          id: this.address.id,
          isDefault: this.address.isDefault,
          name: data.userName,
          mobile: data.telNumber,
          address: data.detailInfo,
          districtId: data.nationalCode + "", //地区标识 也就是国家码
          provinceId: (data.nationalCode + "").slice(0, 2) + "0000", // 省编码
          cityId: (data.nationalCode + "").slice(0, 4) + "00", // 市编码
          areaId: data.nationalCode + "" // 区编码
        });
      });
    }
  },
  watch: {
    fillAddress() {
      let str = !(this.fillAddress.indexOf("卓越时代") == -1);
      let str2 = !(this.fillAddress.indexOf("中付支付") == -1);
      if (str || str2) {
        this.fillAddress = "";
        this.$toast("收货地址不合法");
      } else {
        this.address.address = this.fillAddress;
      }
    }
  }
};
</script>
<style lang='less' scoped>
/deep/ .textarea-style {
  padding-top: 15px !important;
}
.default-checked {
  text-align: center;
  padding: 10px 0;
  display: flex;
  justify-content: center;
  align-items: center;
  background: #fff;
}
.delete-but {
  //   background: #fff;
  text-align: center;
  color: #e0443b;
}

.submit-btn {
  width: 90%;
  border-radius: 99px;
  margin-bottom: 15px;
}
.find-password /deep/ .textarea-style {
  padding-top: 0 !important;
}

// 隐藏一键获取微信地址
.hiddenWeixin {
  display: none;
}
</style>
