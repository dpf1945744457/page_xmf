<template>
    <ul class="address-box">
        <li class="address-one com-bottom-1px" v-for="(item, index) in list" :key="index">
            <div @click="selectAddress(item.id)" class="container">
                <div class="user-box">
                    <div class="username">{{ item.name }}</div>
                    <div class="usermobild">{{ item.mobile }}</div>
                    <div v-if="item.isDefault" class="tipbox"><span class="tip isdefault">默认</span></div>
                </div>
                <p class="address-text">{{ item.province + item.city + item.area + item.address }}</p>
            </div>
            <div class="but-box" @click="editAddress(item.id)"><icon scale="3" name="edit"></icon></div>
        </li>
    </ul>
</template>

<script>
import Xheader from '@src/components/base/x-header';
import Uinput from '@src/components/base/u-input';
import Xbutton from '@src/components/base/x-button';
import '@src/assets/less/butcommon.less';
export default {
    components: { Xheader, Uinput, Xbutton },
    props: ['list'],
    data() {
        return {
            addressId: this.$route.query['addressId'] || 0
        };
    },
    computed: {
        haveSelect() {
            return !(this.list.findIndex(item => item.id == this.addressId) == -1);
        }
    },
    methods: {
        editAddress(id) {
            this.$emit('editAddress', id);
        },
        selectAddress(id) {
            this.$emit('selectAddress', id);
        }
    }
};
</script>

<style lang="less" scoped>
.address-page {
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    margin: auto;
    margin-top: 47px;
    .address-box {
        padding: 0 15px;
        background: #fff;
    }
    .address-one {
        display: flex;
        padding: 15px 0;
        .selected-box {
            flex: 0 0 20px;
            align-items: center;
            svg {
                transform: translateY(10px);
                color: #f23030;
            }
        }
        .container {
            flex: 1;
            overflow: hidden;
        }
        .but-box {
            // flex: 0 0 50px;
            text-align: center;
            vertical-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            /deep/ .svg-icon{
                // width: 60px;
            }
        }
    }
    .user-box {
        display: flex;
        flex-direction: row;
        // font-weight: bold;
        font-size: 16px;
        color: #222;
        .username {
            flex: 1;
            flex: 0 0 70px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .usermobild {
            flex: 1;
            padding-right: 10px;
        }
    }
    .address-text {
        padding-top: 4px;
    }
    .tipbox {
        transform: translateY(-2px);
        .isdefault {
            background: #f23030;
            font-size: 12px !important;
            color: #fff;
            border-radius: 8px;
            box-sizing: border-box;
            padding: 0px 5px;
            flex: 0 0 10px;
        }
    }
}
</style>
