<template>
    <div class="searchData">
        <header>
            <div class="back" @click="back"><div class="left-arrow"></div></div>
            <van-search v-model="value" placeholder="请输入搜索关键词" @search="onSearch" />
        </header>
        <!--<div class="none" v-if='isNo'> 暂无此类商品 敬请期待 </div>-->
        <!--<van-list v-model="loading" :finished="finished" :immediate-check='false' finished-text="没有更多了" @load="onLoad">
            <ProductList :list="goodsList" @clickCartBtn="clickCartBtn"></ProductList>
        </van-list>-->
        <goodsList @isPageLoading="isShowPageLoading" ref='tab'></goodsList>
    </div>
</template>

<script>
import { Search, List } from 'vant';
import { getProductList } from '@src/apis/product.js';
import ProductList from './module/product-list.vue';
import goodsList from './module/goodsList.vue';

export default {
    components: {
        List,
        Search,
        ProductList,
        goodsList
    },
    data() {
        return {
            value:  sessionStorage.getItem('seach'),
            list: this.$store.state.home.searchList,
            goodsList: [],
            loading: false,
            finished: false,
            page: 2,
            isNo: false,
            showPageLoading: true,
        };
    },
    mounted() {
//      this.getData(this.value);
    },
    methods: {
        onSearch(value) {
            let obj = {};
            obj.name = value;
            sessionStorage.setItem('seach', value);
            this.$store.commit('SET_SEARCH', obj);
            this.getData(value);
        },
        async getData(value) {
        	this.$refs.tab.getListslist(true,value);
//          let res = await getProductList({ goodsName: value });
//          this.goodsList = res.goodsList;
//          console.log("goodsList",this.goodsList)
//          if(!this.goodsList.length){
//              this.isNo = true
//          }else{
//              this.isNo = false
//          }
        },
        clickCartBtn() {},
        back() {
            this.$router.push('/');
        },
        async onLoad(){
        	
            this.loading = true
            let res = await getProductList({ goodsName: sessionStorage.getItem('seach') ,page: this.page, });
            
            this.goodsList = [...this.goodsList,...res.goodsList]

            if(res.goodsList.length < 10){
                this.finished = true
                this.loading = false
            }else{
                this.page++
                this.loading = false
            }
        },
        //	       隐藏页面loading
		isShowPageLoading(){
			this.showPageLoading = false;
		},
    }
};
</script>

<style lang="less" scoped>
.searchData {
    height: 100%;
    header {
        height: 44px;
        background: url('../../assets/img/navigationbar@2x.png') no-repeat !important;
        background-size: cover;
        /deep/ .van-search {
            float: left;
            width: 75%;
            height: 34px;
            padding: 5px 0;
            border-radius: 26px;
            overflow: hidden;
            margin: 5px 0;
        }
        /deep/ .van-field__control {
            line-height: 24px;
        }
        /deep/ .van-search__content{
	    	background: #FFFFFF!important;
	    }
        .back {
            position: relative;
            float: left;
            width: 15%;
            height: 44px;
            display: inline-block;
            .left-arrow {
                position: absolute;
                width: 30px;
                height: 30px;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                margin: auto;
            }
            .left-arrow:before {
                content: '';
                position: absolute;
                width: 12px;
                height: 12px;
                border: 1px solid #fff;
                border-width: 2px 0 0 2px;
                transform: rotate(315deg);
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                margin: auto;
            }
        }
    }
    .none{
        text-align: center;
        line-height: 30px;
    }
    /deep/ .yo-scroll {
        position: absolute;
        top: 2rem;
    }
}
</style>
