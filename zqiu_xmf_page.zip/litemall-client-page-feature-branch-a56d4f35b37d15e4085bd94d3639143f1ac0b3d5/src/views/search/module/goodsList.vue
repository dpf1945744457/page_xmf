<template>
  <div
    class="goodsList"
    @touchstart="touchstart()"
    @touchmove="touchmove()"
    :class="{'newStyle' : styleText}"
    ref="list"
  >
    <van-pull-refresh v-model="isDownLoading" @refresh="onRefresh" v-if="!isEmpty">
      <van-list
        v-model="isUpLoading"
        :finished="upFinished"
        finished-text="暂无更多数据"
        :offset="offset"
        :immediate-check="false"
        @load="onLoad"
        :error.sync="error"
        error-text="请求失败，点击重新加载"
      >
        <ul>
          <li v-for="(item,index) in lists" :key="index">
            <div @click="toUrl(item.id)">
              <img :src="item.picUrl" class="goodsPic" />
              <p class="goodsName">{{item.name}}</p>
            </div>
            <div class="otherInfo">
              <div class="priceBox">
                <span class="dollarSign">HK$</span>
                <span class="price">{{item.retailPrice | filterPrice}}</span>
              </div>

              <div class="numBox">
                <div class="titleBox">
                  <p class="title">数量</p>
                  <p class="icon">×</p>
                </div>
                <!--<p class="number other" v-if="currentGoodsId != item.id">{{otherNumber}}</p>-->
                <!--<p class="number current" v-if="item.id == _item.goodsId" v-for="(_item,_index) in newCartList">{{_item.number}}</p>-->
                <p class="number current">{{item.number}}</p>
                <div class="reduceBox" @click="reduceCount(item,index)">
                  <span>-</span>
                </div>
                <div class="addBox" @click="addCount(item.id,index)">
                  <!--<div class="addBox" @click="clickAddCart">-->
                  <span>+</span>
                </div>
              </div>
            </div>
          </li>
        </ul>
      </van-list>
    </van-pull-refresh>
    <div class="emptyBox" v-if="isEmpty">
      <Nodata :imgurl="require('@src/assets/img/bg_empty_data.png')" content="暂无此类商品 敬请期待"></Nodata>
    </div>
  </div>
</template>

<script>
import { getGoodsList } from "@src/apis/home.js";
import {
  getCartIndex,
  postCartChecked,
  postCartDelete,
  postCartUpdate
} from "@src/apis/cart.js";
import Bus from "@src/apis/Bus.js";
import Nodata from "@src/components/base/no-data";
import { mapState, mapActions, mapGetters } from "vuex";
import axios from "axios";
import base from "@src/apis/base.js";
import { getProductList } from "@src/apis/product.js";
const Big = require("big.js");
export default {
  components: {
    Nodata
  },
  props: {
    styleText: {
      type: Boolean
    }
  },
  data() {
    return {
      value: this.$route.query.data,
      page: 1,
      size: 5,
      isDownLoading: false,
      lists: [],
      isUpLoading: false,
      upFinished: false,
      error: false,
      offset: 100,
      classifyId: "",
      isEmpty: false,
      currentNumber: 0,
      otherNumber: 0,
      currentGoodsId: "",
      min: 0,
      max: 5,
      step: 1,
      startX: 0,
      startY: 0,
      moveEndX: 0,
      moveEndY: 0,
      cartList: [],
      newCartList: [],
      last: 0,
      categoryId: ""
    };
  },
  mounted() {
    Bus.$on("classifyId", data => {
      this.changeNav(data);
    });
    //			this.getLists();
  },
  computed: {
    ...mapState({
      productDetail: state => state.productDetail,
      info: state => state.productDetail.info,
      userHasCollect: state => state.productDetail.userHasCollect
    }),
    ...mapGetters(["productItem", "isLogin"])
  },
  created() {
    this.getLists();
    //      	this.getCartGoodscount();
  },
  methods: {
    ...mapActions([
      "getProductDetailById",
      "addCart",
      "buyNow",
      "postCollectByGoods",
      "getCartGoodscount"
    ]),
    getCartList() {
      if (!this.isLogin) {
        return;
      }
      getCartIndex().then(data => {
        if (data && data.cartList.length > 0) {
          this.cartList = data.cartList;
          for (var i = 0; i < this.lists.length; i++) {
            this.lists[i].number = 0;
            for (var k = 0; k < this.cartList.length; k++) {
              if (this.cartList[k].goodsId == this.lists[i].id) {
                this.lists[i].number += this.cartList[k].number;
              }
            }
          }
        }
      });
    },
    async reduceCount(item, index) {
      await this.getProductDetailById(item.id);
      //是否登录

      if (item.number > 0) {
        let id = item.id;
        if (!this.isLogin) {
          this.$router.push({
            path: "/phoneLogin",
            query: {
              redirect: this.$route.fullPath
            }
          });
        } else {
          this.currentGoodsId = id;
          var detail = this.productDetail;

          var specificationList = detail["specificationList"];
          var lists = this.lists;
          var cartLists = this.cartList;
          var num = lists[index].number;

          //	最少为0
          if (num > this.min) {
            //是否有可选规格
            if (specificationList[0].valueList.length > 1) {
              this.$router.push({
                path: "/cart"
              });
            } else {
              for (var j = 0; j < cartLists.length; j++) {
                if (cartLists[j].goodsId == id) {
                  postCartUpdate({
                    productId: cartLists[j].productId,
                    goodsId: cartLists[j].goodsId,
                    number: num - 1,
                    id: cartLists[j].id
                  }).then(result => {
                    num = num - 1;
                    lists[index].number = num;
                    this.getCartList();
                    this.getCartGoodscount();
                  });
                }
              }
            }
          } else {
            this.$toast({
              message: "亲,实在不能再少了",
              iconClass: "icon-success_black"
            });
          }
        }
      }
    },
    //			节流
    throttle(interval) {
      let now = +new Date();
      if (now - this.last >= interval) {
        this.last = now;
        return true;
      } else {
        return false;
      }
    },
    async addCount(id, index) {
      await this.getProductDetailById(id);
      if (!this.throttle(500)) {
        this.$toast({
          message: "操作过于频繁,请稍后重试",
          iconClass: "icon-success_black"
        });
        return;
      }
      //是否登录
      if (!this.isLogin) {
        this.$router.push({
          path: "/phoneLogin",
          query: {
            redirect: this.$route.fullPath
          }
        });
      } else {
        this.currentGoodsId = id;
        var detail = this.productDetail;
        var stock = this.productItem.number;
        var specificationList = detail["specificationList"];
        var lists = this.lists;
        var num = lists[index].number;
        //	最多可加入购物车5个
        //					if(num < stock){
       
          //是否有可选规格
          if (
            specificationList[0] &&
            specificationList[0].valueList.length > 1
          ) {
            this.goDetails(id);
          } else {
             if (num < this.max ) {
            this.addCart().then(
              () => {
                num = num + 1;
                lists[index].number = num;
                this.$toast({
                  message: "加入购物车成功",
                  iconClass: "icon-success_black"
                });
                this.getCartList();
              },
              msg => {
                this.$toast(msg);
              }
            );
             } else {
          this.$toast({
            message: "亲,此商品加入购物车数量已达上限",
            iconClass: "icon-success_black"
          });
        }
          }
          
       
      }
    },
    //			选择规格
    async goDetails(id) {
      this.$router.push({
        path: `/goodsSpecifications/${id}`
      });
    },
    //			async getLists(flag,value) {
    //				var that = this;
    //
    //				let res = await getProductList({ goodsName: value || that.value });
    ////	            this.goodsList = res.goodsList;
    ////	            if(!this.goodsList.length){
    ////	                this.isNo = true
    ////	            }else{
    ////	                this.isNo = false
    ////	            }
    //
    ////				let res = await getGoodsList({
    ////					page: this.page,
    ////					size: this.size,
    ////					classifyId: this.classifyId
    ////				});
    //				if(res) {
    //					this.$emit("isPageLoading");
    //					if(res.count > 0) {
    //						if(flag){
    //                          this.lists = []
    //                     }
    //						this.isEmpty = false;
    //						let rows = res.goodsList;
    //
    //						rows.forEach(item => {
    //							this.$set(item, 'number', 0)
    //						})
    //						this.getCartList();
    //						if(rows == null || rows.length === 0) {
    //							// 加载结束
    //							that.upFinished = true;
    //							return;
    //						}
    //						if(rows.length < this.size) {
    //							// 最后一页不足5条的情况
    //							that.upFinished = true;
    //						}
    //						if(this.page === 1) {
    //							that.lists = rows;
    //						} else {
    //							for(let i of rows) {
    //								that.lists.push(i)
    //							}
    //						}
    //						// 加载状态结束
    //						that.isUpLoading = false;
    //						// 数据全部加载完成
    //						if(that.lists.length >= res.count) {
    //							that.upFinished = true;
    //						}
    //
    //					} else {
    //						that.lists = [];
    //						this.isEmpty = true;
    //					}
    //				} else {
    //					this.error = true;
    //				}
    //
    //			},
 async getListslist(flag, value) {
      var that = this;
      let res = await getProductList({
        page: 1,
        size: this.size,
        goodsName: value ||  sessionStorage.getItem('seach') 
      });
      if (res) {
        this.$emit("isPageLoading");
        if (res.count > 0) {
          if (flag) {
            this.lists = [];
          }
          this.isEmpty = false;
          let rows = res.goodsList;
          // 给每条数据添加 number
          rows.forEach(item => {
            this.$set(item, "number", 0);
          });
          // 加载状态结束
          this.isUpLoading = false;
          this.upFinished = false;

          this.lists = [...this.lists, ...rows];
          this.getCartList();

          // 数据全部加载完成
          if (this.lists.length >= res.count) {
            this.upFinished = true;
          }
        } else {
          this.lists = [];
          this.isEmpty = true;
        }
      } else {
        this.error = true;
      }
    },


    async getLists(flag, value) {
      var that = this;
      let res = await getProductList({
        page: this.page,
        size: this.size,
        goodsName: value ||  sessionStorage.getItem('seach') 
      });
      if (res) {
        this.$emit("isPageLoading");
        if (res.count > 0) {
          if (flag) {
            this.lists = [];
          }
          this.isEmpty = false;
          let rows = res.goodsList;
          // 给每条数据添加 number
          rows.forEach(item => {
            this.$set(item, "number", 0);
          });
          // 加载状态结束
          this.isUpLoading = false;
          this.upFinished = false;

          this.lists = [...this.lists, ...rows];
          this.getCartList();

          // 数据全部加载完成
          if (this.lists.length >= res.count) {
            this.upFinished = true;
          }
        } else {
          this.lists = [];
          this.isEmpty = true;
        }
      } else {
        this.error = true;
      }
    },
    async onLoad() {
      if (this.lists.length >= 5) {
        this.page++;
        this.isUpLoading = false;
        this.getLists();
      } else {
        this.finished = true;
        this.isUpLoading = false;
      }
    },
    //			async onLoad() {
    ////				this.isUpLoading = false;
    ////				if(this.lists.length > 0) {
    ////					this.page++;
    ////              	this.getLists();
    ////				}
    //
    //
    ////				this.isUpLoading = true;
    ////	            let res = await getProductList({ goodsName: this.value ,page: this.page, });
    ////
    ////	            this.goodsList = [...this.goodsList,...res.goodsList]
    //
    //	            if(this.lists.length > 0){
    //	            	this.page++;
    //	                this.isUpLoading = false;
    //	                this.getLists();
    //
    //	            }else{
    //	                this.finished = true;
    //	                this.isUpLoading = false;
    //	            }
    //
    //			},
    // 初始化
    init() {
      this.page = 1;
      this.lists = [];
    },
    onRefresh() {
      this.isDownLoading = false;
      this.isUpLoading = false;
      this.upFinished = false;
      this.page = 1;
      this.getLists(true);
    },
    changeNav(id) {
      this.classifyId = id;
      //				this.isDownLoading = false;
      this.isUpLoading = false;
      this.upFinished = false;
      this.page = 1;
      this.getLists(); // 加载数据
      document.body.scrollTop = 0;
      document.documentElement.scrollTop = 0;
    },
    touchstart() {
      this.startX = event.changedTouches[0].pageX;
      this.startY = event.changedTouches[0].pageY;
    },
    touchmove() {
      var moveEndX = event.changedTouches[0].pageX;
      var moveEndY = event.changedTouches[0].pageY;
      var X = moveEndX - this.startX;
      var Y = moveEndY - this.startY;
      var that = this;
      if (Math.abs(X) > Math.abs(Y) && X > 0) {
        //					console.log('left 2 right'
      } else if (Math.abs(X) > Math.abs(Y) && X < 0) {
        //					console.log('right 2 left')
      } else if (Math.abs(Y) > Math.abs(X) && Y > 0) {
        //					console.log('top 2 bottom');
        that.$emit("isShowTabs");
      } else if (Math.abs(Y) > Math.abs(X) && Y < 0) {
        //					console.log('bottom 2 top');
        that.$emit("isHideTabs");
      } else {
        //					console.log('just touch')
      }
    },
    toUrl(id) {
      this.$router.push({
        path: `/product/${id}`
      });
    }
  },

  filters: {
    filterPrice: function(num) {
      return Number(num).toFixed(2);
    }
  }
};
</script>

<style lang="less" scoped="scoped">
.newStyle {
  margin-top: 44px !important;
}

.goodsList {
  padding: 10px;
  /*width: 355px;*/
  /*min-height: 3000px;*/
  font-family: PingFangSC-Medium;
  /*overflow-y: scroll;*/
  background: #f2f2f2;
  box-sizing: border-box;
  min-height: 100%;
  .van-pull-refresh {
    -webkit-overflow-scrolling: touch !important;
  }
  li {
    margin-bottom: 10px;
    padding-bottom: 10px;
    width: 100%;
    background: #ffffff;
    border-radius: 6px;
    box-sizing: border-box;
    .goodsPic {
      width: 100%;
      height: 206px;
      border-top-left-radius: 6px;
      border-top-right-radius: 6px;
    }
    .goodsName {
      margin: 6px 0;
      padding-left: 12px;
      font-size: 19px;
      color: #333333;
      box-sizing: border-box;
    }
    .otherInfo {
      margin: 0 12px;
      display: flex;
      .priceBox {
        flex: 1;
        color: #ff4a10;
        .dollarSign {
          font-size: 15px;
        }
        .price {
          font-size: 24px;
        }
      }
      .numBox {
        flex: 1;
        text-align: right;
        .titleBox {
          display: inline-block;
          font-family: PingFangSC-Regular;
          font-size: 11px;
          color: #333333;
          text-align: center;
          .icon {
            height: 20px;
            line-height: 18px;
            font-family: PingFangSC-Regular;
            font-size: 20px;
            color: #333333;
          }
        }
        .number {
          margin-left: 4px;
          display: inline-block;
          font-family: PingFangSC-Regular;
          font-size: 26px;
          color: #333333;
          vertical-align: top;
        }
        .reduceBox {
          margin: 0 8px;
          display: inline-block;
          width: 32px;
          height: 32px;
          line-height: 32px;
          background: rgba(247, 207, 32, 0.3);
          border: 1px solid #f7cf20;
          border-radius: 6px;
          text-align: center;
          vertical-align: top;
          box-sizing: border-box;
        }
        .addBox {
          display: inline-block;
          width: 32px;
          height: 32px;
          line-height: 32px;
          background: #f7cf20;
          border-radius: 6px;
          text-align: center;
          vertical-align: top;
        }
      }
    }
  }
  .emptyBox {
    margin-bottom: 150px;
  }
}
</style>