<template>
    <div class="search">
        <form action="/"><van-search v-model="value" placeholder="请输入搜索关键词" show-action @search="onSearch" @cancel="onCancel" /></form>
        <div class="hisBox">
            <p>最近搜索 <span @click='deleteHis'><icon class="tool-icon" slot="icon" name="del" scale="2.3"></icon></span> </p>
            <van-tag plain @click='toSearch(item.name)' v-for='(item,index) in list' :key='index'>{{item.name}}</van-tag>
        </div>
    </div>
</template>

<script>
import { Search,Tag  } from 'vant';
import regExp from '@src/utils/regExp.js'
export default{
    components:{
        Search,
        Tag,
    },
    data(){
        return{
            value: '',
            list: this.$store.state.home.searchList,
        }
    },
    mounted(){
    },
    methods:{
        onSearch(value){
            if(regExp.search.reg.test(value)){
                this.$toast(regExp.search.errMsg)
                return 
            }
            let obj = {}
            obj.name = value
            this.$store.commit('SET_SEARCH',obj)
            sessionStorage.setItem('seach', value);
            this.$router.push({path:'/searchList'})
        },
        onCancel(){
            this.$router.push('/')
        },
        deleteHis(){
            this.$store.commit('DEL_SEARCH')
            this.list = this.$store.state.home.searchList
            
        },
        toSearch(value){
             sessionStorage.setItem('seach', value);
            this.$router.push({path:'/searchList'})
        }
    }
}
</script>

<style lang="less" scoped>
.search {
    height: 100%;
    /deep/ .van-search{
        background: url('../../assets/img/navigationbar@2x.png') no-repeat !important;
        background-size: cover;
    }
    /deep/ .van-field__control{
        line-height: 24px;
    }
    /deep/ .van-cell{
        background: #F6F6F6;
    }
    /deep/ .van-search__content{
        border-radius: 26px;
        overflow: hidden;
    }
    /deep/ .van-tag--plain{
        padding: 5px 10px;
        font-size: 14px;
        background: #F6F6F6;
        color: #666666;
        border: none;
        border-radius: 26px;
        margin-right: 12px;
        margin-top: 10px;
    }
    /deep/ [class*=van-hairline]::after{
        content: none;
    }
    /deep/ .svg-icon{
        width: 40px;
    }
    .hisBox{
        padding: 0 15px;
        p{
            font-size: 16px;
            color: #999999;
            line-height: 30px;
            position: relative;
        }
    }
    .tool-icon{
        position: absolute;
        right: 0;
        bottom: 0;
        top: 0;
        margin: auto;
    }
}
</style>
