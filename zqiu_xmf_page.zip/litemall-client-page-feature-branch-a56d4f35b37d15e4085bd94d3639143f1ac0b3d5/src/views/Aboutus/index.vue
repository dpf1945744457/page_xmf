<template>
  <div>
    <!-- <Xheader class="header-fix" :title="$route.meta.title" :left-options="{preventGoBack:true}" @on-click-back="$router.replace('/user')"></Xheader> -->
    <div style="text-align: center;padding-top: 100px;">
      <img :src="logo" alt style="display: inline-block;
    width: 100px;" />
      <van-divider style="padding-top: 30px;">小蜜蜂电商 v1.0.9</van-divider>

      <!-- <van-button round type="info" @click="to(0)">Android下载</van-button>
      <van-button round type="info" @click="to(1)">苹果下载</van-button> -->
    </div>
    <div style="position: absolute;
    bottom: 100px;
    width: 100%;">
      <a
        @click="$router.push('/Serviceagreement')"
        style="display: inline-block;
    text-align: center;
    width: 100%; color:#1989fa"
      >《服务协议》</a>
      <a
        @click="$router.push('/Privacy')"
        style="display: inline-block;
    text-align: center;
    width: 100%; color:#1989fa;padding-top: 10px;"
      >《隐私协议》</a>
    </div>

    <div class="weixin-tip" v-if="tourl">
      <p>
        <img src="./live_weixin.png" alt="微信打开" />
      </p>
    </div>
  </div>
</template>

<script>
import { danglod } from "@src/apis/danglod.js";
import logo from "../../assets/img/logo.png";
import Xheader from "@src/components/base/x-header";
export default {
  name: "",
  data() {
    return {
      logo: logo,
      ios: "",
      Android: "",
      tourl: false
    };
  },
  components: { Xheader },
  created() {
    this.getdanglods(0);
    this.getdanglods(1);
  },
  mounted() {},
  methods: {
    getdanglods(platform) {
      let data = {
        platform: platform,
        category: 0
      };
      danglod(data)
        .then(response => {
          console.log(response);

          if (platform == 0) {
            this.Android = response.appUrl;
            console.log(this.Android);
          } else {
            this.ios = response.appUrl;
          }
          console.log(response);
        })
        .catch(error => {
          console.log(error);
        });
    },
    is_weixin() {
      var ua = navigator.userAgent.toLowerCase();
      if (ua.match(/MicroMessenger/i) == "micromessenger") {
        return true;
      } else {
        return false;
      }
    },
    to(type) {
      let isWeixin = this.is_weixin();
      if (isWeixin) {
        this.tourl = true;
      } else {
        if (type == 0) {
          window.location.href = this.Android;
        } else {
          window.location.href = this.ios;
        }
      }
    }
  }
};
</script>
<style  scoped>
.weixin-tip {
  position: fixed;
  left: 0;
  top: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.8);
  filter: alpha(opacity=80);
  height: 100%;
  width: 100%;
  z-index: 100;
}
img {
  max-width: 100%;
  height: auto;
}
.weixin-tip p {
  text-align: center;
  margin-top: 10%;
  padding: 0 5%;
}
</style>
