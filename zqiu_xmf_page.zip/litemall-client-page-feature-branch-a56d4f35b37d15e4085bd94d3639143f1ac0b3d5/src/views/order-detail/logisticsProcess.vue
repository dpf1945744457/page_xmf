<template>
    <HeaderLayout class="logistics">
        <Xheader class="header-fix">
            	物流轨迹
        </Xheader>
        <LoadingPage v-if="showPageLoading"></LoadingPage>
        <!--<div class="order-detail">
        	<div class="pic">
        		<img src="../../assets/img/icon_zfcg.png" alt="" />
        	</div>
        	<div class="other-info">
        		<p class="product-name">雅诗兰黛护肤套装 小棕瓶精华+微精华…</p>
        		<p class="logistics-name">中通快递: 3454556778455</p>
        	</div>
	    	</div>-->
	    	<div class="content" v-if="!showPageLoading">
	    		<div class="title">
		    		<div class="left">
						<p class="time">时间</p>
					</div>
					<div class="center"></div>
					<div class="right">
						<p class="text">地点和跟踪进度</p>
					</div>
		    	</div>
		    	<div class="process-list" v-if="!isEmpty">
		    		<ul>
		    			<li v-for="(item,index) in tracks">
		    				<div class="left">
		    					<p class="time">{{item.time}}</p>
		    					<!--<p class="date">2020.03.20</p>-->
		    				</div>
		    				<div class="center">
		    					<img src="../../assets/img/icon_zfcg.png" v-if="index == 0 && status == 4"/>
		    					<img src="../../assets/img/icon_wuliu.png" v-if="index != 0"/>
		    					<img src="../../assets/img/icon_wuliu_ye.png" v-if="index == 0 && status != 4"/>
		    					<div class="line" v-if="index != (tracks.length-1)"></div>
		    				</div>
		    				<div class="right">
		    					<div class="description" v-if="index == 0">{{description}}</div>
		    					<div class="text">{{item.context}}</div>
		    				</div>
		    			</li>
		    		</ul>
		    	</div>
		    	<div class="process-list emptyBox" v-if="isEmpty">
		    		<ul>
		    			<li>
		    				<div class="left">
		    					<p class="time">{{nowTime}}</p>
		    				</div>
		    				<div class="center">
		    					<img src="../../assets/img/icon_wuliu_ye.png"/>
		    					<div class="line"></div>
		    				</div>
		    				<div class="right">
		    					<div class="text">对不起，暂无物流流转信息</div>
		    				</div>
		    			</li>
		    		</ul>
		    	</div>
	    	</div>
	    	
    </HeaderLayout>

</template>
<script>
import HeaderLayout from "@src/layouts/headerLayout.vue"
import Xheader from "@src/components/base/x-header"
import LoadingPage from "@src/components/base/loadingPage"
import { orderQueryTrack } from '@src/apis/order.js';

export default {
    components: {
        HeaderLayout,
        Xheader,
        LoadingPage
    },
    props: [],
    data() {
        return {
        	// 订单ID
        	orderId: this.$route.params["id"],
        	tracks:[],
        	nowTime:'',
        	status: '',
        	description:'',
        	showPageLoading: true,
        	isEmpty: false
        }
    },
    fetch() { },
    created(){
    	this.getQueryTrack();
    	this.timeFormate(new Date());
    },
    methods: {
		async getQueryTrack() {
			try {
	            let res = await orderQueryTrack({ orderId: this.orderId });
	            this.showPageLoading = false;
	            if(res.result == 0){
	            	this.status = res.status;
	            	this.description = res.description;
	       			this.tracks = res.tracks;
	       			if(this.tracks){
	       				this.isEmpty = false;
	       			}else{
	       				this.isEmpty = true;
	       			}
	       		}else{
	       			this.showPageLoading = false;
	       			this.isEmpty = true;
	       		}
	        } catch (error) {
	        	this.showPageLoading = false;
	        	this.isEmpty = true;
	        }
    	},
    	timeFormate(timeStamp) {
	      let year = new Date(timeStamp).getFullYear();
	      let month =new Date(timeStamp).getMonth() + 1 < 10? "0" + (new Date(timeStamp).getMonth() + 1): new Date(timeStamp).getMonth() + 1;
	      let date =new Date(timeStamp).getDate() < 10? "0" + new Date(timeStamp).getDate(): new Date(timeStamp).getDate();
	      let hh =new Date(timeStamp).getHours() < 10? "0" + new Date(timeStamp).getHours(): new Date(timeStamp).getHours();
	      let mm =new Date(timeStamp).getMinutes() < 10? "0" + new Date(timeStamp).getMinutes(): new Date(timeStamp).getMinutes();
//	      let ss =new Date(timeStamp).getSeconds() < 10? "0" + new Date(timeStamp).getSeconds(): new Date(timeStamp).getSeconds();
	      this.nowTime = year + "." + month + "." + date +" "+hh+":"+mm;
    	},
    },
    mounted() {
    	
    },
    watch: {
    	
    }
}
</script>
<style lang='less' scoped>
	.title{
		margin: 16px 10px;
		display: flex;
		width: 100%;
		font-family: PingFangSC-Regular;
		font-size: 15px;
		color: #666666;
		.left{
			.time{
				text-align: center;
				width: 80px;
			}
		}
		.center{
			margin: 0 10px;
			width: 20px;
			height: 20px;
			
		}
		.right{
			.text{
				
			}
		}
	}
	/*.order-detail{
		margin: 0 20px 0 15px;
		padding: 16px 0;
		display: flex;
		
		.pic{
			
			img{
				width: 80px;
				height: 80px;
				border-radius: 5px;
			}
		}
		.other-info{
			margin-left: 8px;
			font-family: PingFangSC-Regular;
			font-size: 14px;
			color: #333333;
			.product-name{
				margin: 20px 0 10px;
			}
			.logistics-name{
				font-size: 13px;
				color: #666666;
			}
		}
	}*/
	/*.divider{
		width: 100%;
		height: 12px;
		background: #F6F6F6;
	}*/
	
	.process-list{
		margin: 0 10px;
		padding: 16px 0 30px;
		li{
			display: flex;
			width: 100%;
			.left{
				.time{
					text-align: center;
					width: 80px;
				}
			}
			.center{
				margin: 0 10px;
				img{
					width: 20px;
					height: 20px;
				}
				.line{
					margin: 10px auto;
					width: 1px;
					height: 48px;
					background: #DEDEDE;
					border-radius: 0.5px;
				}
			}
			.right{
				.description{
					font-family: PingFangSC-Regular;
					font-size: 17px;
					color: #333333;
				}
				.text{
					font-family: PingFangSC-Regular;
					font-size: 13px;
					color: #999999;
				}
			}
		}
	}
	.emptyBox{
		padding: 0;
	}
</style>