<template>
    <div class="order-detail-status">
        <b>{{status}}</b>
        <slot></slot>
    </div>
</template>

<script>
export default {
    props: ["status"]
}
</script>

<style lang="less" scoped>
.order-detail-status {
  //   height: 100px;
  b {
    //  color: #000;
    font-size: 18px;
  }
  background-color: #ffdf00;
  background-image: url("../../../assets/img/order.png");
  background-size: 80px;
  background-position: right center;
  background-repeat: no-repeat;
  color: #de1d00;
  padding: 30px;
  box-sizing: border-box;
}
</style>
