<template>
    <div class="order-detail-goods">
        <div class="m-t-10 item">
            <p class="row">商品信息
                <span class="r">{{orderInfo.orderStatusText}}</span>
            </p>
            <p class="row" style="color:red" v-if="orderInfo.remark">*拒绝退款原因：{{orderInfo.remark}}
                
            </p>
            <a href="javascript:void(0);" class="product-box com-top-1px" v-for="(item,index) in orderGoods" :key="index">
                <img :src="item.picUrl" alt="">
                <div class="left" style="width: 100%;">
                    <p>{{item.goodsName}} <span class="f-r" v-if="item.status"  style="color:red;float: right;">缺货</span></p>
                    <small>{{item.goodsSpecificationValues.join(" ")}}</small>
                    <small>共{{item.number}}件</small>
                    <p>HK${{item.retailPrice | filterPrice}}</p>
                    <p v-if="item.status" style="color:red;">缺货说明:{{item.remark}}</p>
                </div>
                
            </a>
            <!-- <p class="row">实付</p> -->
        </div>
    </div>
</template>

<script>
export default {
    props: ["orderGoods", "orderInfo"],
    filters: {
		filterPrice: function(num) {
			return Number(num).toFixed(2);
		}
	},
}
</script>

<style lang="less" scoped>
.order-detail-goods {
  .item {
    background: #fff;
    padding: 0 10px;
    box-sizing: border-box;
  }

  .row {
    padding: 10px 0;
    .r {
      float: right;
      color: #f23030;
    }
  }

  .product-box {
    padding: 10px 0;
    display: flex;
    img {
      width: 50px;
      height: 50px;
      padding: 5px;
      background: #f6f6f6;
      //   box-sizing: border-box;
    }

    .left {
      margin-left: 10px;
      p {
        color: #000;
      }
    }
  }
}
</style>
