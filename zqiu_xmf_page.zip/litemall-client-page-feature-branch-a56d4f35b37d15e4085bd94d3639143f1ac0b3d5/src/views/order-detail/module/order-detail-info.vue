<template>
    <div class="order-detail-info">
        <p>商品合计：HK${{orderInfo.goodsPrice | filterPrice}}</p>
        <p>运费：HK${{orderInfo.freightPrice | filterPrice}}</p>
        <p>税费：HK${{orderInfo.taxPrice | filterPrice}}</p>
        <p class="red">实付：HK${{orderInfo.actualPrice | filterPrice}}</p>
    </div>
</template>

<script>
export default {
    props: ["orderInfo"],
    filters: {
		filterPrice: function(num) {
			return Number(num).toFixed(2);
		}
	},
}
</script>

<style lang="less" scoped>
.order-detail-info {
  background: #fff;
  padding: 20px 10px;
  p {
    padding: 5px 0;
  }
  .red {
    color: red;
  }
}
</style>
