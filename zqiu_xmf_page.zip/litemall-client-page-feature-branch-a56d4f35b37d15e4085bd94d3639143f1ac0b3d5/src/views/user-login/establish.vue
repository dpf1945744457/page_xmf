<template>
	<div class="header">
		<!-- header头部 -->
		<LoginHeader :isBack='true'></LoginHeader>
		<Uinput label="手机号" type="tel" v-model="mobile"  :topLine="true" maxLength="11" disabled></Uinput>
		<Uinput label="姓名" type="text" v-model="name" :topLine="true" disabled></Uinput>
		<LoginInput label="密码" type="password" v-model="passwords" placeholder="请输入密码"  :topLine="true" maxLength="6"></LoginInput>
		<LoginInput label="确认密码" type="password" v-model="againPassword" placeholder="请再次输入密码" :topLine="true" maxLength="6"></LoginInput>
		<Xbutton class="btn" type="dd" @click.native="register">确认注册</Xbutton>
	</div>
</template>

<script>
	import HeaderLayout from "@src/layouts/headerLayout.vue"
	import LoginHeader from "./module/login-header.vue"
	import LoginInput from "./module/login-input.vue"
	import Xbutton from "@src/components/base/x-button"
	import Uinput from "@src/components/base/u-input"
	import TimerBtn from "@src/components/base/timer-btn"
	import { isWeixin } from '@src/utils/wx.js'
	import { getLoginCode, wxBindingPh } from '@src/apis/user.js'
	import regExp from '@src/utils/regExp.js'
	import { mapState, mapActions, mapGetters } from "vuex";
	import { setStorage, getStorage, removeStorage } from "@src/utils/storage.js"
	import { getToken, setToken, removeToken } from '@src/utils/auth.js'
	import channel from '@src/utils/channel.js'
	import md5 from 'js-md5';
	
	export default {
		components: {
			HeaderLayout,
			LoginHeader,
			Xbutton,
			Uinput,
			TimerBtn,
			LoginInput
		},
		data() {
			return {
				redirectUrl: this.$route.query['redirect'] || getStorage("redirectUrl"),
				name: "",
				passwords: '',
				againPassword: '',
				mobile: "",
				code: "",
				areaCode: '',
			}
		},
		mounted() {
			// 如果没有储存标识 和 有重定向url的话 设置isBack为真就行
			if(this.redirectUrl) setStorage("redirectUrl", this.redirectUrl);
			
			this.name = this.$route.query.name
			this.mobile = this.$route.query.mobile
			this.code = this.$route.query.code
			this.areaCode = this.$route.query.areaId
		},
		beforeRouteEnter(to, from, next) {
			if(isWeixin() && !getToken() && process.env.NODE_ENV === 'production') {

				let redirectUrl0 = encodeURIComponent(`${window.location.href.split("#")[0]}#/bind`);
				// let redirectUrl1 = encodeURIComponent(`${window.location.href.split("#")[0]}#${from.fullPath}`);
				let redirectUrl2 = encodeURIComponent(`${location.origin}/wx/oauth/loginWxWeb?redirectURL=${redirectUrl0}`);
				let redirectUrl3 = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxa56f673775b525bb&redirect_uri=${redirectUrl2}&response_type=code&scope=snsapi_userinfo&state=10001#wechat_redirect`;
//				let redirectUrl3 = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxa418d63f5b2ab75c&redirect_uri=${redirectUrl2}&response_type=code&scope=snsapi_userinfo&state=10001#wechat_redirect`;
				
				window.location.replace(redirectUrl3);

			} else {
				next();
			}
		},
		methods: {
			...mapActions(["userRegisterByMobile"]),
			register() {
				if(!this.passwords) {
					this.$toast("请输入密码");
					return false;
				}
				if(!regExp.num.reg.test(this.passwords)) {
					this.$toast("密码只能为数字");
					return false;
				}
				if(this.passwords.length < 6) {
					this.$toast("密码为6位数字");
					return false;
				}
				if(this.passwords.length > 6) {
					this.$toast("密码为6位数字");
					return false;
				}

				
				if(this.againPassword != this.passwords) {
					this.$toast("请确认密码一致");
					return false;
				}
				
				this.userRegisterByMobile({
					realName: this.name,
					password: this.passwords,
					mobile: this.mobile,
					areaCode: this.areaCode,
					checkedIdx:this.code,
					agentNo: channel.get()
				}).then((res)=>{
					if(res){
						this.$router.replace("/phoneLogin");
					}
				})
			}
		}

	}
</script>

<style lang="less" scoped>
	.btn {
		width: 95%;
		margin: 30px auto 20px ;
		background: #ffdf00;
		color: #000;
	}
	
	.form-right{
		float: right !important;
	}
	
	.img_btn {
		width: 3rem;
	}
	
	.switch{
		text-align: right;
	}
	
	.footer{
		padding: 0 1rem;
		display: flex;
		a{
			flex: 1;
		}
	}
	
	.header /deep/ .timer-btn {
		font: 14px arial, sans-serif;
	}
</style>