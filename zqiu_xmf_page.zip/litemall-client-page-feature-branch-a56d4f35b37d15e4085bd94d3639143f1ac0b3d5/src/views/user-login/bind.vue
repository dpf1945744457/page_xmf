<template>
  <div class="bind">
    <div align="center" class="bd-ph">绑定手机号</div>
    <Uinput phoneShow label="手机区域" v-on:getAreaId="getId"></Uinput>
    <Uinput
      label="手机号"
      type="tel"
      v-model="mobile"
      placeholder="请输入手机号"
      :topLine="true"
      :maxLength="11"
    ></Uinput>
    <Uinput
      label="验证码"
      type="tel"
      v-model="code"
      placeholder="请输入验证码"
      :topLine="true"
      :maxLength="6"
      width="60%"
    >
      <TimerBtn ref="TimerBtn" :text="'发送验证码'" :time="60" :cb="sendCode"></TimerBtn>
    </Uinput>
    <Xbutton class="btn" type="dd" @click.native="bind">绑定</Xbutton>
    <van-dialog
      v-model="show"
      title="该手机号已经注册!"
      cancelButtonText="关联旧账号"
      confirmButtonText="绑定新手机"
      @confirm="open"
      @cancel="clear"
      close-on-click-overlay
      show-cancel-button
    ></van-dialog>
  </div>
</template>

<script>
import Xbutton from "@src/components/base/x-button";
import Uinput from "@src/components/base/u-input";
import TimerBtn from "@src/components/base/timer-btn";
import { isWeixin } from "@src/utils/wx.js";
import {
  getLoginCode,
  wxBindingPhCheck,
  weixinBindPhone,
  getBindMobileCode,
} from "@src/apis/user.js";
import regExp from "@src/utils/regExp.js";
import { mapActions } from "vuex";
import {
  getWxToken,
  getToken,
  setToken,
  removeToken,
} from "@src/utils/auth.js";
import { setStorage, getStorage, removeStorage } from "@src/utils/storage.js";
import { Dialog } from "vant";
export default {
  components: {
    Xbutton,
    Uinput,
    TimerBtn,
  },
  name: "bind",
  data() {
    return {
      mobile: "",
      code: "",
      rule: "no",
      areaCode: "",
      token: "",
      show: false,
    };
  },

  // beforeRouteEnter(to, from, next) {
  // 	console.log(getStorage("fromPath"));

  // 	if(getToken()) {
  // 		next({
  // 			path: getStorage("fromPath")
  // 		})
  // 	}
  // 	next();
  // 	//    wxBindingPhCheck().then(res => {
  // 	//      if(res.errno === 0){
  // 	//        next({ path: '/user' })
  // 	//      }else if(res.errno === 301){
  // 	//        next();
  // 	//      }else{
  // 	//        next({ path: '/' })
  // 	//      }
  // 	//    });
  // },
  mounted() {},
  methods: {
    ...mapActions(["loginByWx", "loginByWxFlush", "loginByWxRouter"]),
    async sendCode() {
      if (this.mobile === "") {
        this.$toast("请输入手机号");
        return false;
      }
      if (this.mobile.length < 8) {
        this.$toast("手机号不能小于8位");
        return false;
      }
      let data = await getBindMobileCode({
        phone: this.mobile,
        areaCode: this.areaCode,
      });
      if (data.errno) {
        this.$toast({
          message: data.errmsg,
        });
      } else if (data === "验证码未过期") {
        this.$toast({
          message: data,
          iconClass: "icon-success_black",
        });
      } else {
        this.$toast({
          message: data,
          iconClass: "icon-success_black",
        });
        this.$refs.TimerBtn.disabled = true;
        this.$refs.TimerBtn.timer();
      }
    },
    getId(data) {
      this.areaCode = data;
    },

    BindPhone() {
      this.loginByWx({
        phone: this.mobile,
        code: this.code,
        rule: this.rule,
        area: this.areaCode,
        woken: getWxToken(),
      }).then((res) => {
        if (res.errno === 0) {
          this.$router.push({
            path: "/user",
          });
        } else {
          //          this.$toast(res.errmsg);
          return false;
        }
      });
    },

    // 创建新账号
    open() {
      // this.loginByWxRouter({
      //   phone: this.mobile,
      //   code: this.token,
      //   area: this.areaCode,
      //   woken: getWxToken(),
      //   route: "wx"
      // }).then(res => {
      //   if (res.errno === 306) {
      //     this.$router.push({
      //       path: "/WXpassword",
      //       query: {
      //         mobile: this.mobile,
      //         areaId: this.areaCode,
      //         code: this.token,
      //         from: false
      //       }
      //     });
      //   } else {
      //     this.$toast(data.errmsg);
      //     return false;
      //   }
      // });
      window.location.reload();
      // this.$router.push({
      //       path: "/bind"
      //     });
    },

    // 关联旧帐号
    async clear() {
      try {
        await this.loginByWxFlush({
          phone: this.mobile,
          code: this.token,
          area: this.areaCode,
          woken: getWxToken(),
        });
      } catch (error) {
        this.$toast(error);
      }
      // .then((res) => {
      //     console.log(res);

      // 	// if(res.errno === 0) {

      // 	// 	alert("success")
      // 	// } else {
      // 	// 	//									this.$toast(data.errmsg);
      // 	// 	return false
      // 	// }
      // })
    },

    async bind() {
      if (this.mobile === "") {
        this.$toast("请输入手机号");
        return false;
      }
      if (this.mobile.length < 8) {
        this.$toast("手机号不能小于8位");
        return false;
      }
      if (!this.code) {
        this.$toast("请输入验证码");
        return false;
      } else {
        let data = await weixinBindPhone({
          phone: this.mobile,
          area: this.areaCode,
          code: this.code,
          woken: getWxToken(),
        });
        this.token = data.data;
        if (data.errno === 302) {
          this.$router.push({
            path: "/WXpassword",
            query: {
              mobile: this.mobile,
              areaId: this.areaCode,
              code: this.token,
              from: true,
            },
          });
        } else if (data.errno === 304) {
          this.show = true;
        } else {
          this.$toast(data.errmsg);
          return false;
        }
      }
    },
  },
};
</script>

<style lang="less" scoped>
.bind {
  position: fixed;
  left: 0;
  right: 0;
}
.btn {
  width: 95%;
  margin: 30px auto;
  background: #ffdf00;
  color: #000;
}

.form-group dl dd .form-control-box .form-right[data-v-5bf3888d] {
  float: right;
}

.bind /deep/ .timer-btn {
  width: 4rem;
  line-height: 1rem;
}

.bd-ph {
  color: black;
  padding: 20px 3%;
  font-size: 16px;
}
</style>