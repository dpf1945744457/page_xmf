
<template>
	<div class="header" >
		<!-- header头部 -->
		<LoginHeader :isBack='back' ></LoginHeader>
		<Uinput phoneShow label="手机区域" v-on:getAreaId='getId' v-on:showBacks='getBack'></Uinput>
		<Uinput label="手机号" type="tel" v-model="mobile" placeholder="请输入手机号" :topLine="true" maxLength="11"></Uinput>
		<Uinput label="验证码" type="tel" v-model="code" placeholder="请输入验证码" :topLine="true" maxLength="6" width="50%">
			<TimerBtn ref="TimerBtn" :text="'发送验证码'" :time="60" :cb="sendCode"></TimerBtn>
		</Uinput>
		<Xbutton class="btn" type="dd" @click.native="register">下一步</Xbutton>
	</div>
</template>

<script>
	import LoginHeader from "./module/login-header.vue"
	import Xbutton from "@src/components/base/x-button"
	import Uinput from "@src/components/base/u-input"
	import TimerBtn from "@src/components/base/timer-btn"
	import { isWeixin } from '@src/utils/wx.js'
	import { getLoginCode, forgetCode,getCode,getForgetCode } from '@src/apis/user.js'
	import regExp from '@src/utils/regExp.js'
	import { mapState, mapActions, mapGetters } from "vuex";
	import { setStorage, getStorage, removeStorage } from "@src/utils/storage.js"
	import { getToken, setToken, removeToken } from '@src/utils/auth.js'
	import channel from '@src/utils/channel.js'
	
	import md5 from 'js-md5';
	export default {
		components: {
			LoginHeader,
			Xbutton,
			Uinput,
			TimerBtn,
		},
		data() {
			return {
				redirectUrl: this.$route.query['redirect'] || getStorage("redirectUrl"),
				mobile: "",
				code: "",
				passwords: '',
				imgCode: '',
				keys: '',
				areaCode: '',
				back: true,
			}
		},
		route: {
			canActivate(transition) {
				
				transition.next();
			}
		},
		mounted() {
			// 如果没有储存标识 和 有重定向url的话 设置isBack为真就行
			if(this.redirectUrl) setStorage("redirectUrl", this.redirectUrl);
			this.updateCode()
		},
		methods: {
			...mapActions(["userLoginByMobile"]),
			async sendCode() {
				if(this.mobile.length == ''){
					this.$toast('请输入手机号');
					return false;
				}
				if(this.mobile.length < 8){
					this.$toast('手机号不能小于8位');
					return false;
				}
				if(this.mobile.length > 11){
					this.$toast('手机号不能大于11位');
					return false;
				}
				let data = await getForgetCode({
					phone: this.mobile,
					areaCode: this.areaCode,
					
				});
				
				if(data.errno){
					this.$toast({
						message: data.errmsg,
					});
				}else if(data === '验证码未过期'){
					this.$toast({
						message: data,
					});
				}else{
					this.$toast({
						message: data,
					});
					this.$refs.TimerBtn.disabled = true;
					this.$refs.TimerBtn.timer();
				}
				
				
			},
			register() {
				if(this.mobile.length == '') {
					this.$toast('请输入手机号');
					return false;
				}
				if(this.mobile.length < 8) {
					this.$toast('手机号不能小于8位');
					return false;
				}
				if(this.mobile.length > 11) {
					this.$toast('手机号不能大于11位');
					return false;
				}
				if(!this.code) {
					this.$toast("请输入验证码");
					return false;
				}
				
//				this.$router.push({
//					path: '/modify',
//					query: {
//						mobile: this.mobile,
//						areaId: this.areaCode,
//						code: this.code,
//					}
//				})
				
				forgetCode({
					phone: this.mobile,
					code: this.code,
					areaCode: this.areaCode,
				}).then((res) => {
					if(!res.errno) {
						this.$router.replace({
							path: '/modify',
							query: {
								mobile: this.mobile,
								areaId: this.areaCode,
								code: res,
							}
						})
					} else {
						this.$toast(res.errmsg);
					}
				})

			},
			getId(data){
				this.areaCode = data;
			},
			getBack(data){
				this.back = data
			},
			updateCode(){
				getCode().then((res)=>{
					this.imgCode = res.code
					this.keys = res.key
				})
			}
		}

	}
</script>

<style lang="less" scoped>
	.header{
		position: fixed;
		left: 0;
		right: 0;
	}
	.btn {
		width: 95%;
		margin: 30px auto 20px ;
		background: #ffdf00;
		color: #000;
	}
	
	.form-right{
		float: right !important;
	}
	
	.img_btn {
		width: 3rem;
	}
	
	.switch{
		text-align: left;
	}
	
	.footer{
		padding: 0 1rem;
		display: flex;
		div{
			flex: 1;
		}
	}
	
	.header /deep/ .timer-btn {
		font: 14px arial, sans-serif;
	}
</style>