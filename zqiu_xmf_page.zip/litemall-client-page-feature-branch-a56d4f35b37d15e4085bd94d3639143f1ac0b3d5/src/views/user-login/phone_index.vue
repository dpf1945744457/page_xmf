<template>
	<div class="header" >
		<!-- header头部 -->
		<LoginHeader :isBack='back'></LoginHeader>
		<Uinput phoneShow label="手机区域" v-on:getAreaId='getId' v-on:showBacks='getBack'></Uinput>
		<Uinput label="手机号" type="tel" v-model="mobile" placeholder="请输入手机号" :topLine="true" maxLength="11"></Uinput>
		<LoginInput label="密码" v-model="passwords" placeholder="请输入密码" :topLine="true" maxLength="6"></LoginInput>
		<Uinput label="验证码" type="tel" v-model="code" placeholder="请输入验证码" :topLine="true" maxLength="6" width="50%">
			<template>
				<div @click="updateCode" style="background: #ffdf00;line-height: 1rem;  padding: .3rem .5rem; border-radius: 4px ;">{{imgCode}}</div>
			</template>
		</Uinput>
		<Xbutton class="btn" type="dd" @click.native="login">登录</Xbutton>

		<div class="footer">
			<div class='switch' @click="$router.push('/register')">用户注册</div>
			<div style="text-align: right;" @click="$router.replace('/forgetIndex')">忘记密码</div>
		</div>
	</div>
</template>

<script>
	import HeaderLayout from "@src/layouts/headerLayout.vue"
	import LoginHeader from "./module/login-header.vue"
	import LoginInput from "./module/login-input.vue"
	import Xbutton from "@src/components/base/x-button"
	import Uinput from "@src/components/base/u-input"
	import TimerBtn from "@src/components/base/timer-btn"
	import { isWeixin } from '@src/utils/wx.js'
	import { getLoginCode, wxBindingPh, getCode } from '@src/apis/user.js'
	import regExp from '@src/utils/regExp.js'
	import { mapState, mapActions, mapGetters } from "vuex";
	import { setStorage, getStorage, removeStorage } from "@src/utils/storage.js"
	import { getToken, setToken, removeToken } from '@src/utils/auth.js'
	import channel from '@src/utils/channel.js'
	import Cookies from 'js-cookie'

	import md5 from 'js-md5';
	export default {
		components: {
			HeaderLayout,
			LoginHeader,
			Xbutton,
			Uinput,
			TimerBtn,
			LoginInput
		},
		data() {
			return {
				redirectUrl: this.$route.query['redirect'] || getStorage("redirectUrl"),
				mobile: "",
				code: "",
				passwords: '',
				imgCode: '',
				keys: '',
				areaCode: '',
				back: true,
			}
		},
		route: {
			canActivate(transition) {
				
				transition.next();
			}
		},
		mounted() {
			Cookies.set('names', 'yangkai')
			// 如果没有储存标识 和 有重定向url的话 设置isBack为真就行
			if(this.redirectUrl) setStorage("redirectUrl", this.redirectUrl);
			this.updateCode()
		},
		beforeRouteEnter(to, from, next) {
			if(isWeixin() && !getToken() && process.env.NODE_ENV === 'production') {
				let redirectUrl0 = encodeURIComponent(`${window.location.href.split("#")[0]}#/`);
				// let redirectUrl0 = encodeURIComponent(`${window.location.href.split("#")[0]}#/bind`);
				// let redirectUrl1 = encodeURIComponent(`${window.location.href.split("#")[0]}#${from.fullPath}`);
				let redirectUrl2 = encodeURIComponent(`${location.origin}/wx/oauth/loginWxWeb?redirectURL=${redirectUrl0}`);
				let redirectUrl3 = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxa56f673775b525bb&redirect_uri=${redirectUrl2}&response_type=code&scope=snsapi_userinfo&state=10001#wechat_redirect`;
//				let redirectUrl3 = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxa418d63f5b2ab75c&redirect_uri=${redirectUrl2}&response_type=code&scope=snsapi_userinfo&state=10001#wechat_redirect`;
				
				setStorage("fromPath",from.path)
				window.location.replace(redirectUrl3);

			} else {
				next();
			}
		},
		methods: {
			...mapActions(["userLoginByMobile"]),
			async login() {
				if(this.mobile.length == '') {
					this.$toast('请输入手机号');
					return false;
				}
				if(this.mobile.length < 8) {
					this.$toast('手机号不能小于8位');
					return false;
				}
				if(this.mobile.length > 12) {
					this.$toast('手机号不能大于11位');
					return false;
				}
				if(this.passwords.length == 0) {
					this.$toast('请输入密码');
					return false;
				}

				if(!this.code) {
					this.$toast("请输入验证码");
					return false;
				}
				
				
				
				try{
					let isSuccess = await this.userLoginByMobile({
						phone: this.mobile,
						password: this.passwords,
						code: this.code,
						key: this.keys,
						areaCode: this.areaCode,
					})
					if(isSuccess) {
	                    let temp = sessionStorage.getItem('lgins') || false
	                    if(temp || sessionStorage.getItem('lgins') =='true'){
	                        this.$router.replace("/");
	                    } else {
	                        history.go(-1);
	                    }
					}
				}catch (error) {
					this.updateCode()
				}
				
			},
			getId(data) {
				
				this.areaCode = data
			},
			getBack(data) {
				this.back = data
				
			},
			updateCode() {
				getCode().then((res) => {
					this.imgCode = res.code
					this.keys = res.key
				})
			}
		}

	}
</script>

<style lang="less" scoped>
.header{
	position: fixed;
	left: 0;
	right: 0;
}
	.btn {
		width: 95%;
		margin: 30px auto 20px;
		background: #ffdf00;
		color: #000;
	}

	.form-right {
		float: right !important;
	}

	.img_btn {
		width: 3rem;
	}

	.switch {
		text-align: left;
	}

	.footer {
		padding: 0 1rem;
		display: flex;
		div {
			flex: 1;
		}
	}

	.header /deep/ .timer-btn {
		font: 14px arial, sans-serif;
	}
</style>