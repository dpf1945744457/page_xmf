<template>
  <TabbarLayout class="cart padding-top-46" :showPageLoading="!show">
    <Xheader
      class="header-fix"
      :left-options="{preventGoBack:true}"
      @on-click-back="$router.replace('/')"
    >
      {{ $route.meta.title }}
      <a
        slot="right"
        v-if="cartList.length>0 && !isEditing"
        @click="isEditing=!isEditing"
      >编辑</a>
      <a slot="right" v-if="cartList.length>0 && isEditing" @click="isEditing=!isEditing">完成</a>
      <a slot="right" v-if="cartList.length>0" @click="clearCarts">清空</a>
    </Xheader>
    <div class="no-login-tip" v-if="!isLogin">
      <span>登录后可以看到您选中的商品</span>
      <!-- <router-link to="/phoneLogin" class="bg-color">登录</router-link> -->
      <a href="javascript:void(0)" @click="clickHrefs" class="bg-color">登录</a>
    </div>
    <no-data v-if="show && showEmpty"></no-data>
    <cart-list
      ref="carts"
      v-if="show && cartList.length>0"
      :cartList="cartList"
      :isEditing="isEditing"
      @deleteCarts="deleteCarts(false)"
    ></cart-list>
  </TabbarLayout>
</template>

<script>
import TabbarLayout from "@src/layouts/tabbar.vue";
import Xheader from "@src/components/base/x-header";
import NoData from "./module/no-data.vue";
import CartList from "./module/cart-list.vue";
import {
  getCartIndex,
  postCartChecked,
  postCartDelete
} from "@src/apis/cart.js";
import { mapState, mapActions, mapGetters } from "vuex";
export default {
  components: { TabbarLayout, Xheader, NoData, CartList },
  layout: "tabbar",
  data() {
    return {
      show: false,
      isEditing: false,
      cartList: [],
      showEmpty: false
    };
  },
  computed: {
    ...mapGetters(["isLogin"])
  },
  // activated() {
  //     this.getCartList();
  // },
  created() {
    this.getCartList();
    this.getCartGoodscount();
  },
  methods: {
    ...mapActions(["getCartGoodscount"]),
    getCartList() {
      if (!this.isLogin) {
        this.isEditing = false;
        this.show = true;
        return;
      }
      getCartIndex().then(data => {
        this.show = true;
        if (data && data.cartList) {
          this.cartList = data.cartList;
          if (this.cartList.length === 0) {
            this.showEmpty = true;
          }
          this.$nextTick(() => {
            if (this.$refs.carts != null) {
              this.isEditing = false;
              this.$refs.carts.calcTotal();
            }
          });
        }
      });
    },

    clearCarts() {
      this.deleteCarts(true);
    },

    deleteCarts(isAllDelete) {

      let productIds = [];
      let carts = this.cartList;
      console.log(carts);
      let message=""
      for (let index = 0; index < carts.length; index++) {
        if (isAllDelete) {
          productIds.push(carts[index].productId);
          message="确认清空购物车？"
        } else if (carts[index].deleted) {
          productIds.push(carts[index].productId);
           message="确认要删除这"+productIds.length+"种商品吗？"
        }
      }
      if (productIds.length === 0) {
        this.$toast("请选择商品");
        return;
      }
      this.$dialog
        .confirm({
          title: "删除",
          message: message
        })
        .then(() => {
          postCartDelete({
            productIds: productIds
          }).then(result => {
            this.getCartList();
            this.getCartGoodscount();
            location.reload();
          });
        })
        .catch(() => {
          // on cancel
        });
    },
    clickHrefs() {
      this.$router.push({ path: "/phoneLogin" });
    }
  }
};
</script>

<style lang="less" scoped>
/deep/ .weui-tabbar {
  height: 50px;
}
.cart {
  padding-bottom: 53px;
}
.no-login-tip {
  height: 23px;
  line-height: 23px;
  padding: 11px 0px;
  text-align: center;
  background: #fff;
  border-bottom: 1px solid #eee;
  font-size: 13px;
  a {
    display: inline-block;
    height: 21px;
    line-height: 21px;
    padding: 0 12px;
    border-radius: 4px;
    margin-left: 3px;
    color: #fff;
    font-size: 0.5rem;
  }
  span {
    color: #666;
  }
}
</style>
