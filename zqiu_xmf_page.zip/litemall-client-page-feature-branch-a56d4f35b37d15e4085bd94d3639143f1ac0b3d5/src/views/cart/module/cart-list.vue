<template>
  <div class="cart-list">
    <div class="list-box">
      <div v-for="(item, index) in cartList" v-if="handleDomestic(item, index)">
        <div class="goods-title">国内自营商品</div>
        <cart-item
          v-if="item.shipmentRegion === 0"
          v-for="(item, index) in cartList"
          :key="index"
          :item="item"
          :isEditing="isEditing"
          @numberChanged="changeNum"
          @selectChanged="changeSelect"
          @deleteChanged="changeDelete"
        ></cart-item>
      </div>
      <div v-for="(item, index) in cartList" v-if="handleForeign(item, index)">
        <div class="goods-title">海外自营商品</div>
        <cart-item
          v-if="item.shipmentRegion === 1"
          v-for="(item, index) in cartList"
          :key="index"
          :item="item"
          :isEditing="isEditing"
          @numberChanged="changeNum"
          @selectChanged="changeSelect"
          @deleteChanged="changeDelete"
        ></cart-item>
      </div>
      <div v-for="(item, index) in cartList" v-if="handlenafeng(item, index)">
        <div class="goods-title">海外奶粉专区</div>
        <cart-item
          v-if="item.shipmentRegion === 11"
          v-for="(item, index) in cartList"
          :key="index"
          :item="item"
          :isEditing="isEditing"
          @numberChanged="changeNum"
          @selectChanged="changeSelect"
          @deleteChanged="changeDelete"
        ></cart-item>
        
      </div>
    </div>
    <div class="list-total flow-bottom-fix com-top-1px" v-if="!isEditing">
      <div class="cart-checkbox" @click="selectAll(!isSelectAll)">
        <CheckIcon :value="isSelectAll"></CheckIcon>
        <span>全选</span>
      </div>
      <div id="cart_count">
        <div class="total">
          <dl class="total-money">
            <dt>合计:</dt>
            <dd>
              <em class="SZY-CART-SELECT-GOODS-AMOUNT price-color">HK${{ total | filterPrice}}</em>
            </dd>
          </dl>
        </div>
        <div class="check-btn bg-color wait-loading SZY-CART-SUBMIT-LOADING" style="display:none">
          <i></i>
        </div>
        <div
          @click="toOrderConfirm"
          class="submit-btn check-btn bg-color SZY-CART-SUBMIT"
          :disabled="!selectedCount"
          :class="selectedCount ? '' : 'check'"
        >去结算</div>
      </div>
    </div>
    <div class="list-total flow-bottom-fix com-top-1px" v-if="isEditing">
      <div class="cart-checkbox" @click="deleteAll(!isDeleteAll)">
        <CheckIcon :value="isDeleteAll"></CheckIcon>
        <span>全选</span>
      </div>
      <div id="cart_count">
        <div class="total">
          <dl class="total-money"></dl>
        </div>
        <div class="check-btn bg-color wait-loading SZY-CART-SUBMIT-LOADING" style="display:none">
          <i></i>
        </div>
        <div @click="deleteCarts" class="submit-btn check-btn bg-color SZY-CART-SUBMIT">删除</div>
      </div>
    </div>

    <van-dialog
      v-model="show"
      show-cancel-button
      :before-close="beforeClose"
      title="请分开结算以下商品"
      confirmButtonText="去结算"
      cancelButtonText="返回购物车"
    >
      <van-radio-group v-model="radio" class="ck-radio">
        <van-radio class="ck-cont" name="1" v-if="foreignSum!=0">海外自营商品 {{ foreignSum }} 件</van-radio>
        <van-radio name="0" v-if="domesticSum!=0">国内自营商品 {{ domesticSum }} 件</van-radio>
        <van-radio class="ck-cont" name="2" v-if="nafengnSum!=0">海外奶粉专区 {{ nafengnSum }} 件</van-radio>
      </van-radio-group>
    </van-dialog>
  </div>
</template>

<script>
import { postCartChecked, postCartUpdate } from "@src/apis/cart.js";
import { getConfirmOrder } from "@src/apis/order.js";
import CartItem from "./cart-item";
import CheckIcon from "@src/components/base/check-icon";
import { mapState, mapActions, mapGetters } from "vuex";
import { toFixed } from "@src/utils/to-fixed.js";
let _ = require("lodash");
export default {
  components: {
    CartItem,
    CheckIcon
  },
  props: {
    isEditing: {
      type: Boolean
    },
    cartList: {
      type: Array,
      default() {
        return [];
      }
    }
  },
  data() {
    return {
      total: 0,
      isSelectAll: false,
      isDeleteAll: false,
      selectedCount: 0,
      deleteCount: 0,
      show: false,
      nafeng: [],
      radio: 1,
      foreign: [],
      foreignAcc: [],
      nafengnAcc: [],
      foreignSum: "",
      nafengnSum: "",
      domestic: [],
      domesticAcc: [],
      domesticSum: "",
      GN: [],
      GW: [],
      NF: []
    };
  },
  created() {
    this.handleAdd();
  },

  filters: {
    filterPrice: function(num) {
      return Number(num).toFixed(2);
    }
  },
  computed: {
    ...mapState({
      productDetail: state => state.productDetail,
      info: state => state.productDetail.info,
      userHasCollect: state => state.productDetail.userHasCollect
    }),
    ...mapGetters(["productItem", "isLogin"])
  },
  methods: {
    ...mapActions(["getCartGoodscount"]),
    changeNum(item) {
      postCartUpdate({
        productId: item.productId,
        goodsId: item.goodsId,
        number: item.number,
        id: item.id
      }).then(result => {
        if (result.errno == 0) {
          this.calcTotal();
          this.getCartGoodscount();
          // location.reload();
        } else {
          item.number = item.number - 1;
          this.$toast({
            message: result.errmsg,
            iconClass: "icon-success_black"
          });
        }
      });
    },
    changeSelect(item) {
      postCartChecked({
        productIds: [item.productId],
        isChecked: item.checked ? 1 : 0
      }).then(result => {
        this.calcTotal();
      });
    },
    changeDelete(item) {
      let carts = this.cartList;
      this.deleteCount = 0;
      for (let index in carts) {
        if (carts[index].deleted) {
          this.deleteCount++;
        }
      }
      if (this.deleteCount === carts.length) {
        this.deleteAll(true);
      } else if (this.deleteCount === 0) {
        this.deleteAll(false);
      } else {
        this.isDeleteAll = false;
      }
    },
    calcTotal() {
      this.total = 0;
      let total = 0;
      let carts = this.cartList;
      this.selectedCount = 0;
      for (let index in carts) {
        if (carts[index].checked) {
          this.selectedCount++;
          if (carts[index].taxFlag == 1) {
            total += carts[index].number * carts[index].price;
          } else {
            total +=
              carts[index].number * carts[index].price +
              carts[index].number * carts[index].taxes;
          }

          this.total = toFixed(total);
        }
      }
      if (this.selectedCount === carts.length) {
        this.selectAll(true);
      } else if (this.selectedCount === 0) {
        this.isSelectAll = false;
        this.selectAll(false);
      } else {
        this.isSelectAll = false;
      }
    },
    selectAll(flag) {
      this.isSelectAll = flag;
      let carts = this.cartList;
      for (let index in carts) {
        carts[index].checked = this.isSelectAll;
      }
    },
    deleteAll(flag) {
      this.isDeleteAll = flag;
      let carts = this.cartList;
      for (let index in carts) {
        carts[index].deleted = this.isDeleteAll;
      }
    },

    beforeClose(action, done) {
      if (action === "confirm") {
        let carts = this.cartList;
        for (let index in carts) {
          if (
            parseInt(this.radio) === 0 &&
            carts[index].shipmentRegion === 0 &&
            carts[index].checked === true
          ) {
            carts[index].checked = true;
          } else if (
            parseInt(this.radio) === 1 &&
            carts[index].shipmentRegion === 1 &&
            carts[index].checked === true
          ) {
            carts[index].checked = true;
          } else if (
            parseInt(this.radio) === 2 &&
            carts[index].shipmentRegion === 11 &&
            carts[index].checked === true
          ) {
            carts[index].checked = true;
          } else {
            carts[index].checked = false;
          }
        }
        setTimeout(() => {
          done();
          this.$router.push({
            path: "/cart/confirm",
            query: { key: this.radio }
          });
          this.handleEmpty();
        }, 1000);
      } else {
        done();
        this.handleEmpty();
      }
    },
    handleEmpty() {
      this.domesticAcc = [];
      this.foreignAcc = [];
      this.nafengnAcc = [];

      this.domesticSum = "";
      this.foreignSum = "";
      this.nafengnSum = "";
    },

    handleAdd() {
      for (let i in this.cartList) {
        if (this.cartList[i].shipmentRegion === 0) {
          this.domestic.push(i);
        } else if (this.cartList[i].shipmentRegion === 1) {
          this.foreign.push(i);
        } else if (this.cartList[i].shipmentRegion === 11) {
          this.nafeng.push(i);
        }
      }
    },
    sumArr(arr) {
      var sum = 0;
      arr.forEach(function(val, index, arr) {
        sum += val;
      });
      return sum;
    },
    handleDomestic(item, index) {
      // console.info("最大值：" + Math.max.apply(null, this.domestic))

      if (
        item.shipmentRegion === 0 &&
        index >= Math.max.apply(null, this.domestic)
      ) {
        return true;
      }
    },
    handleForeign(item, index) {
      //console.info("最大值：" + Math.max.apply(null, this.foreign))

      if (
        item.shipmentRegion === 1 &&
        index >= Math.max.apply(null, this.foreign)
      ) {
        return true;
      }
    },
    handlenafeng(item, index) {
      // console.info("最大值：" + Math.max.apply(null, this.nafeng))

      if (
        item.shipmentRegion === 11 &&
        index >= Math.max.apply(null, this.nafeng)
      ) {
        return true;
      }
    },
    async toOrderConfirm() {
      if (this.selectedCount != 0) {
        let data = await getConfirmOrder({
          cartId: 0,
          addressId: 0,
          couponId: 0,
          grouponRulesId: 0
        });

        console.log(data);
        if (!data.errno) {
          //  if (data.checkedGoodsList.length!=this.cartList.length) {
          //      this.$toast("所选商品已下架请重新选购");
          //      setTimeout(() => {
          //        //window.location.reload();
          //      }, 2000);

          //        return
          //      }
          this.GN.length = 0;
          this.GW.length = 0;
          this.NF.length = 0;
          //求和
          this.domesticAcc.length = 0;
          this.foreignAcc.length = 0;
          this.nafengnAcc.length = 0;
          for (let i in this.cartList) {
            if (
              this.cartList[i].shipmentRegion === 0 &&
              this.cartList[i].checked === true
            ) {
              this.GN.push(this.cartList[i].checked);
              // 求和
              this.domesticAcc.push(this.cartList[i].number);
            } else if (
              this.cartList[i].shipmentRegion === 1 &&
              this.cartList[i].checked === true
            ) {
              this.GW.push(this.cartList[i].checked);
              // 求和
              this.foreignAcc.push(this.cartList[i].number);
            } else if (
              this.cartList[i].shipmentRegion === 11 &&
              this.cartList[i].checked === true
            ) {
              this.NF.push(this.cartList[i].checked);
              // 求和
              this.nafengnAcc.push(this.cartList[i].number);
            }
          }

          if (
            JSON.stringify(this.GN).includes("true") &&
            !JSON.stringify(this.GW).includes("true") &&
            !JSON.stringify(this.NF).includes("true")
          ) {
            this.radio = "0";
            this.$router.push({
              path: "/cart/confirm",
              query: { key: this.radio }
            });
          }
          if (
            JSON.stringify(this.GW).includes("true") &&
            !JSON.stringify(this.GN).includes("true") &&
            !JSON.stringify(this.NF).includes("true")
          ) {
            this.radio = "1";
            this.$router.push({
              path: "/cart/confirm",
              query: { key: this.radio }
            });
          }

          if (
            JSON.stringify(this.NF).includes("true") &&
            !JSON.stringify(this.GN).includes("true") &&
            !JSON.stringify(this.GW).includes("true")
          ) {
            this.radio = "2";
            this.$router.push({
              path: "/cart/confirm",
              query: { key: this.radio }
            });
          }
          if (
            JSON.stringify(this.GW).includes("true") &&
            JSON.stringify(this.GN).includes("true") &&
            JSON.stringify(this.NF).includes("true")
          ) {
            this.show = true;
            this.radio = "1";
            Array.prototype.sum = function() {
              return this.reduce(function(partial, value) {
                return partial + value;
              });
            };

            this.domesticSum = this.sumArr(this.domesticAcc);
            this.foreignSum = this.sumArr(this.foreignAcc);
            this.nafengnSum = this.sumArr(this.nafengnAcc);
          }

          if (
            JSON.stringify(this.GW).includes("true") &&
            JSON.stringify(this.GN).includes("true") &&
            !JSON.stringify(this.NF).includes("true")
          ) {
            this.show = true;
            this.radio = "1";
            Array.prototype.sum = function() {
              return this.reduce(function(partial, value) {
                return partial + value;
              });
            };

            this.domesticSum = this.sumArr(this.domesticAcc);
            this.foreignSum = this.sumArr(this.foreignAcc);
            this.nafengnSum = this.sumArr(this.nafengnAcc);
          }

          if (
            !JSON.stringify(this.GW).includes("true") &&
            JSON.stringify(this.GN).includes("true") &&
            JSON.stringify(this.NF).includes("true")
          ) {
            this.show = true;
            this.radio = "1";
            Array.prototype.sum = function() {
              return this.reduce(function(partial, value) {
                return partial + value;
              });
            };

            this.domesticSum = this.sumArr(this.domesticAcc);
            this.foreignSum = this.sumArr(this.foreignAcc);
            this.nafengnSum = this.sumArr(this.nafengnAcc);
          }
          if (
            JSON.stringify(this.GW).includes("true") &&
            !JSON.stringify(this.GN).includes("true") &&
            JSON.stringify(this.NF).includes("true")
          ) {
            this.show = true;
            this.radio = "1";
            Array.prototype.sum = function() {
              return this.reduce(function(partial, value) {
                return partial + value;
              });
            };

            this.domesticSum = this.sumArr(this.domesticAcc);
            this.foreignSum = this.sumArr(this.foreignAcc);
            this.nafengnSum = this.sumArr(this.nafengnAcc);
          }
        } else {
          this.$toast(data.errmsg);
          setTimeout(() => {
            window.location.reload();
          }, 2000);
        }
      }
    },

    deleteCarts() {
      this.$emit("deleteCarts", this);
    }
  },
  watch: {}
};
</script>

<style lang="less" scoped>
.cart-list {
  overflow: hidden;
  width: 100%;
  background: #f6f6f6;
  padding-bottom: 45px;
  .flow-bottom-fix {
    position: fixed !important;
    width: 100%;
    height: 45px;
    left: 0;
    bottom: 50px;
  }
  .list-box {
    width: 100%;
    overflow: hidden;
  }
  .list-total {
    overflow: hidden;
    width: 100%;
    height: 45px;
    background: #fff;
    .cart-checkbox {
      position: absolute;
      top: 10px;
      left: 0;
      margin-top: 0;
      margin-left: 12px;
      height: 25px;
      width: 60px;
      display: block;
      overflow: hidden;
      span {
        position: absolute;
        right: 0;
        top: 5px;
      }
    }
    .total {
      display: block;
      float: left;
      text-align: right;
      width: 75%;
      .total-money {
        height: 1rem;
        margin-right: 1rem;
        padding-top: 0.5rem;
        font-size: 0;
        line-height: 1rem;
        dt {
          display: inline-block;
          font-size: 0.7rem;
          position: relative;
          bottom: 2px;
        }
        dd {
          display: inline-block;
          font-size: 0.7rem;
          font-weight: 600;
        }
        dd em {
          font-size: 0.9rem;
        }
      }
    }
    .check-btn {
      display: block;
      float: right;
      width: 25%;
      height: 50px;
      color: #fff;
      line-height: 2.05rem;
      text-align: center;
      position: relative;
      bottom: 0;
      cursor: pointer;
    }
  }
}
.ck-radio {
  padding: 20px 20px;
  .ck-cont {
    padding: 10px 0;
  }
}
.goods-title {
  padding: 5px 15px;
  font-size: 14px;
  background: rgba(242, 48, 48, 1);
  color: white;
}

.check {
  background: #ccc;
}
</style>
