<template>
    <div class="goods-footer-nav bdr-top">
        <!-- <a href="javascript:void(0);" class="nav-button goods-col right collect-goods" data-goods-id="40851" @click="$router.push({path:'/'})">
            <icon name="home" scale="2.5"></icon>
            <p>首页</p>
        </a> -->

        <a href="javascript:void(0);" class="nav-button com-right-1px" v-if="userHasCollect == 0" @click="postCollectByGoods">
            <icon name="collection" scale="2.5"></icon>
            <p>收藏</p>
        </a>
        <a href="javascript:void(0);" class="nav-button com-right-1px" v-else @click="postCollectByGoods">
            <icon name="collection-active" scale="2.5"></icon>
            <p>已收藏</p>
        </a>

        <a href="javascript:void(0);" class="nav-button com-right-1px goods-col right collect-goods" data-goods-id="40851" @click="$router.push({path:'/cart'})">
            <icon name="cart-1" scale="2.5"></icon>
            <p>购物车</p>
            <Badge class="badge" :text="goodscount"></Badge>
        </a>

        <dl class="ub-f1 ub">
            <dd class="cart" @click="openSkuModule">
                加入购物车
            </dd>
            <dd class="buy" @click="clickBuyNow">
              立即购买
            </dd>
        </dl>
    </div>
</template>
<script>
import Badge from '@src/components/base/badge'
import { mapState, mapActions, mapGetters } from "vuex";
export default {
    components: { Badge },
    computed: {
        ...mapState({
            goodscount: state => state.productDetail.goodscount,
            userHasCollect: state => state.productDetail.userHasCollect
        })
    },
    methods: {
        ...mapActions(["isOpenSkuModule", "buyNow", "postCollectByGoods"]),
        openSkuModule() {
            this.isOpenSkuModule({
                open: true,
                skuBtnType: "confirm"
            });
        },

        // 用户点击立即购买
        clickBuyNow() {
            this.isOpenSkuModule({
                open: true,
                skuBtnType: "buyNow"
            });
        }
    }
}
</script>
<style lang='less' scoped>
@keyframes fadeInUp {
  from {
    opacity: 0;
    -webkit-transform: translate3d(0, 100%, 0);
    transform: translate3d(0, 100%, 0);
  }

  to {
    opacity: 1;
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }
}

.active-fill-color {
  fill: #f23030;
}
.goods-footer-nav {
  width: 100%;
  height: 50px;
  position: fixed;
  z-index: 222;
  left: 0;
  bottom: 0px;
  background-color: rgba(243, 245, 249, 0.9);

  display: flex;
  text-align: center;
  animation: fadeInUp 0.3s;
  > a {
    width: 18%;
    padding-top: 5px;
    padding-bottom: 5px;
    box-sizing: content-box;
    p {
      font-size: 12px;
      margin-top: -2px;
    }

    .badge {
      position: absolute;
      top: 5px;
      right: 5px;
    }
  }
  dl {
    flex: 1;
    display: flex;
    dd {
      flex: 1;
      line-height: 50px;
      color: #fff;
    }
  }
  .buy {
    background: #f23030;
  }
  .cart {
    background: #ff9301;
  }
}
</style>
