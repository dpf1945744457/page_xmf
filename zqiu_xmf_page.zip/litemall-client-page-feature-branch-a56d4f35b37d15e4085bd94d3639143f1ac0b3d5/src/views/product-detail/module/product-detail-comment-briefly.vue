<template>
    <div class="product-detail-comment" v-if="comment.count != 0">
        <Ucell title="大家都在说" :borderLine="true"></Ucell>
        <!-- 评价列表 -->
        <GoodsComment v-for="(item, index) in commentList" :key="index" :item="item" @clickImg="show"></GoodsComment>

        <u v-if="comment.count > 1" @click="$emit('btnShowAll')">查看全部({{ comment.count }})条评价</u>

        <!-- <Ucell v-if="comment.count > 1" :borderLine="true" :isLink="true" style="text-align:center;" :title="`查看全部（${comment.count}）条评价`" @click.native="$emit('btnShowAll')"></Ucell> -->

        <!-- 预览组件 -->
        <!-- <div v-transfer-dom> -->
        <div><previewer :list="list" ref="previewer" @on-index-change="logIndexChange"></previewer></div>
    </div>
</template>
<script>
// import Previewer from "@src/components/base/previewer"
import Xbutton from '@src/components/base/x-button';
import GoodsComment from '@src/components/base/goods-comment';
import Ucell from '@src/components/base/u-cell';
import TransferDom from '@src/directives/transfer-dom/index.js';
import { mapState, mapActions, mapGetters } from 'vuex';
export default {
    directives: { TransferDom },
    components: {
        Xbutton,
        GoodsComment,
        Ucell,
        Previewer: () => import(/* webpackChunkName: "previewer" */ '@src/components/base/previewer')
    },
    data() {
        return {
            count: 0,
            target: null,
            list: []
        };
    },
    computed: {
        commentList() {
            return this.comment.data.slice(0, 1);
        },
        ...mapState({
            comment: state => state.productDetail.comment
        })
    },
    methods: {
        logIndexChange(arg) {
        	
        },
        show(e, index, picList) {
            this.target = e.target;
            this.list = picList;
            this.$nextTick(() => {
                this.$refs.previewer.show(index);
            });
        }
    }
};
</script>
<style lang="less" scoped>
.product-detail-comment {
    overflow: hidden;
    u{
        width: 100%;
        line-height: 26px;
        background: #fff;
        display: inline-block;
        text-align: center;
    }
}
</style>
