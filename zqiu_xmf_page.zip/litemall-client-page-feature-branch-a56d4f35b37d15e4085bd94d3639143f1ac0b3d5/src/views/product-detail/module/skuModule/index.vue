<template>
  <Popup
    v-model="productDetail.skuStatus"
    position="bottom"
    style="overflow-y:inherit; background:#fff;"
  >
    <HeaderInfo></HeaderInfo>
    <!-- <Sku ref="Sku"></Sku> -->

    <!-- 规格渲染 -->
    <div class="sku-box" :style="`max-height:${APP.winW/1.5}px`">
      <div class="sku" v-for="(item,index) in productDetail.specificationList" :key="index">
        <div class="name">{{item.name}}</div>
        <checker
          v-model="item.checked"
          default-item-class="sku-item"
          selected-item-class="sku-item-selected"
          :radio-required="true"
        >
          <checker-item v-for="(_item,i) in item.valueList" :key="i" :value="_item">{{_item.value}}</checker-item>
        </checker>
      </div>
    </div>

    <Xnumber title="购买数量" v-model="productDetail.number" :min="1" :max="5"></Xnumber>

    <!-- 如果已经登录 -->
    <template v-if="isLogin">
      <!-- 如果有库存 -->
      <div class="choose-foot" v-if="productItem.number > 0">
        <a
          href="javascript:void(0)"
          class="disable"
          v-if="productDetail.skuBtnType == 'confirm' && cartNumber >= 5"
        >此商品加入购物车数量已达上限</a>

        <a
          href="javascript:void(0)"
          class="buy"
          v-if="productDetail.skuBtnType == 'confirm' && cartNumber < 5"
          @click="clickAddCart"
        >确定</a>
        <a
          href="javascript:void(0)"
          class="buy"
          v-if="productDetail.skuBtnType == 'buyNow'"
          @click="clickBuyNow"
        >确认购买</a>
        <a
          href="javascript:void(0)"
          class="cart"
          v-if="productDetail.skuBtnType == 'addCart'"
          @click="clickAddCart"
        >加入购物车</a>
        <a
          href="javascript:void(0)"
          class="disable"
          v-if="productDetail.skuBtnType == 'addCart'  && cartNumber >= 5"
        >此商品加入购物车数量已达上限</a>
      </div>
      <!-- 没有库存 -->
      <div class="choose-foot" v-else>
        <a href="javascript:void(0)" class="disable">暂无库存</a>
      </div>
    </template>

    <!-- 没有登录 -->
    <div class="choose-foot" v-else>
      <a
        href="javascript:void(0)"
        class="cart"
        @click="$router.push({path:'/phoneLogin',query:{redirect:$route.fullPath}})"
      >立即登录</a>
    </div>
  </Popup>
</template>
<script>
import Popup from "@src/components/base/popup";
import Xnumber from "@src/components/base/x-number";
import { Checker, CheckerItem } from "@src/components/base/checker";
import Sku from "./sku.vue";
import HeaderInfo from "./header-info.vue";
import { mapState, mapActions, mapGetters } from "vuex";
import { getCartIndex } from "@src/apis/cart.js";
export default {
  props: ["info"],
  components: {
    Popup,
    HeaderInfo,
    Xnumber,
    Checker,
    CheckerItem,
    Sku,
  },
  data() {
    return {
      cartList: [],
      id: this.$route.params["id"],
      cartNumber: 0,
    };
  },
  created() {
    this.getCartList();
  },
  computed: {
    ...mapState({
      productDetail: (state) => state.productDetail,
    }),
    ...mapGetters(["productItem", "isLogin"]),
  },
  methods: {
    ...mapActions(["addCart", "buyNow", "getCartGoodscount"]),
    getCartList() {
      if (!this.isLogin) {
        return;
      }
      getCartIndex().then((data) => {
        if (data && data.cartList) {
          this.cartList = data.cartList;
          for (var i = 0; i < this.cartList.length; i++) {
            if (this.id == this.cartList[i].goodsId) {
              this.cartNumber = this.cartList[i].number;
            }
          }
        }
      });
    },
    clickAddCart() {
      this.addCart().then(
        () => {
          this.$toast({
            message: "加入购物车成功",
            iconClass: "icon-success_black",
          });
          // setTimeout(() => {
          // 	location.reload();
          // },500)
        },
        (msg) => {
          this.productDetail.number = 0;

          this.$toast(msg);
        }
      );
    },
    // 用户点击立即购买
    clickBuyNow() {
      //				this.getCartGoodscount();
      this.buyNow().then(
        (cartId) => {
          this.$router.push({
            path: "/cart/confirm",
            query: {
              cartId,
            },
          });
          // setTimeout(() => {
          // 	location.reload();
          // },600)
        },
        (msg) => {
			 this.productDetail.number = 0;
          this.$toast(msg);
        }
      );
    },
  },
};
</script>
<style lang='less' scoped>
.sku-box {
  overflow-y: auto;
  padding: 10px 0;
  background: #fffefe;
}

.sku {
  padding: 0 15px;
  .name {
    padding-bottom: 10px;
  }
}

.sku-item {
  display: inline-block;
  margin-right: 5px;
  margin-bottom: 10px;
  border: 1px solid #cacaca;
  -moz-border-radius: 5px;
  -webkit-border-radius: 5px;
  border-radius: 5px;
  padding: 0 15px;
  line-height: 25px;
  display: inline-block;
  color: #666;
}

.sku-item-selected {
  // background: #ffffff url(../assets/demo/checker/active.png) no-repeat right
  //   bottom;
  border-color: #f23030;
  color: #f23030;
}

.choose-foot {
  width: 100%;
  height: 45px;
  text-align: center;
  display: flex;
  a {
    display: block;
    flex: 1;
    height: 45px;
    line-height: 46px;
    color: #fff;
    font-size: 0.8rem;
    text-align: center;
    cursor: pointer;
  }
  .buy {
    background: #f23030;
  }
  .cart {
    background: #ff9301;
  }
  .disable {
    background: #dbdbdb;
  }
}
</style>