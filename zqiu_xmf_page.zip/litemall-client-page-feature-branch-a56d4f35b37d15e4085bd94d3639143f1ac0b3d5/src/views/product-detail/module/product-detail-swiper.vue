
<style lang="less" scoped>
.banner{
    position: relative;
    z-index: 0;
    height: 503px;
    overflow: hidden;
    video{
        position: relative;
        z-index: 1;
    }
    .viedios{
        width: 100vw;
        height: 503px;
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        position: relative;
        z-index: 1;
        background-color: #000
    }
    .imgBacks{
        width: 100vw;
        height: 503px;
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        position: relative;
        z-index: 1;
    }
    /deep/ van-swipe{
        width: 100vw;
        height: 503px;
    }
    /deep/ .video-player{
        width: 100vw;
        height: 503px;
    }
    /deep/ .van-swipe__indicator{
    	background-color: #ccc!important;
    }
    /deep/ .van-swipe__indicator--active{
    	background-color: #ff9700!important;
    }
    /deep/ .video-js .vjs-tech{
        width: 100vw;
        height: 503px;
    }
    /deep/ .vjs-poster{
        width: 100vw;
        height: 503px;
    }
    /deep/ .video-js .vjs-big-play-button {
        font-size: 2.8em;
        line-height: 1.9em;
        height: 2em;
        width: 2em;
        display: block;
        position: absolute;
        top: 50%;
        left: 50%;
        padding: 0;
        cursor: pointer;
        opacity: 1;
        border: 0.06666em solid #fff;
        background-color: #2B333F;
        background-color: rgba(43, 51, 63, 0.7);
        border-radius: 2em;
        -webkit-transition: all 0.4s;
        transition: all 0.4s;
        transform: translate(-50%, -50%);
    }
    video::-internal-media-controls-download-button {
        display:none;
    }
    
    video::-webkit-media-controls-enclosure {
        overflow:hidden;
    }
    
    video::-webkit-media-controls-panel {
        width: calc(100% + 30px); 
    }


    
    /deep/ video::-internal-media-controls-download-button {
        display:none;
    }
    
    /deep/ video::-webkit-media-controls-enclosure {
        overflow:hidden;
    }
    
    /deep/ video::-webkit-media-controls-panel {
        width: calc(100% + 30px); 
    }
    /deep/ .video-js{
        width: 100vw;
        height: 503px;
    }


    .video-js .vjs-tech {
        position: inherit;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
    }
}
img{
    width: 100%;
}
.fixSwips{
    position: absolute;
    z-index: 1;
    display: flex;
    bottom: 25px;
    width: 100%;
    text-align: center;
    justify-content: center;
    align-items: center;
    .lf{
        background-color:rgba(255,255,255,0.7);
        border-radius: 28px;
        display: flex;
        margin-right: 12px;
        span{
            background:none;
        }
        span.active{
            color: #fff;
            em{
                color: #fff;
            }
            background:linear-gradient(270deg, #F2302F 0%, #FF4A10 100%);
        }
    }
    .rg{
        span.active{
            color: #fff;
            em{
                color: #fff;
            }
            background:linear-gradient(270deg, #F2302F 0%, #FF4A10 100%);
        }
    }
    span{
        height: 28px;
        font-size: 12px;
        color: #666666;
        display: flex;
        background-color:rgba(255,255,255,0.7);
        padding: 0 10px;
        align-items: center;
        border-radius: 28px;
        justify-content: center;
    }
    em{
        font-size: 12px;
        color: #666666;
        display: block;
    }
    
    img{
        width: 6px;
        height: 8px;
        margin-right: 3px;
    }
}
</style>

<template>
    <div class="banner">
        <!-- <van-swipe :width="winW" indicator-color="white">
            <van-swipe-item v-for="(item, index) in bannerList" :key="index" @click='clickSwiper(item)'>
                <div class="imgBacks" :style="'background-image:url('+ item.image +')'"></div>
            </van-swipe-item>
            
            <van-swipe-item v-for="(item, inx) in bannerVedio" :key="inx" @click='clickSwiper(item)'>
                <div class="imgBacks video-box">
                    <video-player class="video-player vjs-custom-skin" :src="playerOptions[index].sources[0].src" :posters='playerOptions[index].poster'></video-player>
                </div>
            </van-swipe-item>
        </van-swipe> -->

        <van-swipe :touchable='true' :initial-swipe='current' :width="winW" indicator-color="white" @change="onChange">
            <!-- <van-swipe-item v-for="(item, index) in bannerVedio" :key="index" @click='clickSwiper(item)'>
                <div class="imgBacks video-box">
                    <video-player class="video-player vjs-custom-skin" :src="playerOptions[index].sources[0].src" :posters='playerOptions[index].poster'></video-player>
                </div>
            </van-swipe-item> -->
            <van-swipe-item v-for="(item, inex) in bannerList" :key="inex" @click='clickSwiper(item)'>
                <div class="imgBacks" :style="'background-image:url('+ item.image +')'"></div>
            </van-swipe-item>
        </van-swipe>
        <div class="fixSwips">
            <div class="lf" slot="indicator">
                <!-- <span v-for="(item, exa) in bannerVedio" :key="exa" @click="swipVedio(true, exa)"  :class="current == exa ?'active':''">
                    <img v-if="current != exa" src="../../../assets/img/icon_jt_black.png" alt="">
                    <img v-if="current == exa" src="../../../assets/img/icon_jt_black_wiher.png" alt="">
                    <em>{{item.txtMedia}}</em>
                </span>
                <span :class="(bannerVedio.length<=0 || current == (bannerVedio.length)) ?'active':''" @click="swipVedio(true, bannerVedio.length)"><em>图片</em></span> -->
                <span class="active"><em>图片</em></span> 
            </div>
        </div>
    </div>
</template>

<script>
import { Swiper, SwiperItem } from '@src/components/base/swiper';

import { mapState, mapActions, mapGetters } from 'vuex';

// import 'video.js/dist/video-js.css'
// import 'vue-video-player/src/custom-theme.css'
// import { videoPlayer } from 'vue-video-player'
// Vue.use(VueVideoPlayer)
import videoPlayer from './videoPlayers'

export default {
    components: { Swiper, SwiperItem, videoPlayer },
    data() {
        return {
            // banner高度默认值
            winW: 375,
            hidenShow: true,
            current: 0,
            playerOptions: []
        };
    },
    created() {
        this.winW = window.innerWidth || 375;
        for(let i in this.bannerVedio){
            this.playerOptions.push(
                {
                    playbackRates: [1.0], //播放速度
                    autoplay: false, //如果true,浏览器准备好时开始回放。
                    muted: false, // 默认情况下将会消除任何音频。
                    loop: false, // 导致视频一结束就重新开始。
                    preload: 'auto', // 建议浏览器在<video>加载元素后是否应该开始下载视频数据。auto浏览器选择最佳行为,立即开始加载视频（如果浏览器支持）
                    language: 'zh-CN',
                    aspectRatio: '16:9', // 将播放器置于流畅模式，并在计算播放器的动态大小时使用该值。值应该代表一个比例 - 用冒号分隔的两个数字（例如"16:9"或"4:3"）
                    fluid: true, // 当true时，Video.js player将拥有流体大小。换句话说，它将按比例缩放以适应其容器。
                    sources: [{
                        type: this.bannerVedio[i].type,
                        src: this.bannerVedio[i].video //视频url地址
                    }],
                    poster: this.bannerVedio[i].image, //你的封面地址
                    width: document.documentElement.clientWidth,
                    notSupportedMessage: '此视频暂无法播放，请稍后再试', //允许覆盖Video.js无法播放媒体源时显示的默认信息。
                    controlBar: {
                        timeDivider: true,
                        durationDisplay: true,
                        remainingTimeDisplay: false,
                        fullscreenToggle: false  //全屏按钮
                    }
                }
            )
        }
    },
    computed: {
        ...mapState({
            bannerList: state => state.productDetail.bannerList,
            bannerVedio:  state => state.productDetail.bannerVedioList
        }),
    },
    mounted(){
    	
        for(let i of this.bannerList){
        	
        }
        
    },
    methods:{
        onPlayerPlay(){ // 开始
        	
        },
        onPlayerPause(){ // 暂停
        	
        },
        clcikPlayFucn(){ // 视频播放

        },
        swipVedio(flag, index){
            this.current = index
            this.hidenShow = flag
        },
        onChange(index){
            this.current = index
        },
        clickSwiper(e){
            if(e.type === 'video/mp4'){
                location.href = e.video;
            }
        }
    }
};
</script>

