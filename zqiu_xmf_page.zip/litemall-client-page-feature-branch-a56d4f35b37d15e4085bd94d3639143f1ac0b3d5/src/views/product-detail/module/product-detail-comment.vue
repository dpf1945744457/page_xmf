<template>
    <div class="product-detail-comment" :style="`min-height:${APP.winH}px`">
        <!-- 评价列表 -->
        <GoodsComment v-for="(item,index) in commentList" :key="index" :item="item" @clickImg="show"></GoodsComment>
        <div style="min-height:80px; overflow: hidden;">
            <LoadMore v-if="status=='请求中'" tip="" :showLoading="true"></LoadMore>
            <LoadMore v-if="status=='没有更多'" tip="没有更多了" :showLoading="false"></LoadMore>
            <LoadMore v-if="status=='请求失败'" tip="加载失败，点我重试" :showLoading="false" @click.native="loadMore"></LoadMore>
            <Xbutton v-if="status=='请求更多'" plain mini class="load-btn" @click.native="loadMore">查看更多评价</Xbutton>
            <Nodata v-if="status=='暂无数据'" :imgurl="require('@src/assets/img/bg_empty_data.png')" content='暂无评价'></Nodata>
        </div>
        <!-- 预览组件 -->
        <!-- <div v-transfer-dom> -->
        <div>
            <Previewer :list="list" ref="previewer"></Previewer>
        </div>
    </div>
</template>
<script>
import LoadMore from "@src/components/base/load-more"
import Nodata from "@src/components/base/no-data"
import Xbutton from "@src/components/base/x-button"
import GoodsComment from "@src/components/base/goods-comment"
import Ucell from '@src/components/base/u-cell'
import TransferDom from '@src/directives/transfer-dom/index.js'
import { getGoodsCommentList } from '@src/apis/comment.js'
import { mapState, mapActions, mapGetters } from "vuex";
import { picListTransformData } from '@src/utils/data-transform-utils.js'
export default {
    directives: { TransferDom },
    components: {
        LoadMore, Nodata, Xbutton, GoodsComment, Ucell,
        Previewer: () => import(/* webpackChunkName: "previewer" */ '@src/components/base/previewer'),
    },
    data() {
        return {
            status: "",
            count: 0,
            query: { limit: 5, page: 1 },
            commentList: [],
            target: null,
            list: []
        }
    },
    computed: {
        ...mapState({
            info: state => state.productDetail.info
        }),
        infiniteDisabled() {
            return this.status == '请求中' || this.status == '没有更多' || this.status == '暂无数据' || this.status == '请求失败';
        }
    },

    created() {
        this.loadMore();
    },
    methods: {
        async loadMore(append) {
            try {
                this.status = "请求中";
                let data = await getGoodsCommentList({ id: this.info.id, ...this.query });
                this.count = data.count;
                // 转换符合预览组件需要的数据
                let commentList = picListTransformData(data.data);
                // 追加数据
                this.commentList = this.commentList.concat(commentList);
                if (this.commentList.length == 0) {
                    this.status = "暂无数据";
                } else if (this.commentList.length >= this.count) {
                    this.status = "没有更多";
                } else {
                    this.status = "请求更多";
                    this.query.page++;
                }
            } catch (error) {
                this.status = "请求失败";
            }
        },
        show(e, index, picList) {
            this.target = e.target;
            this.list = picList;
            this.$nextTick(() => {
                this.$refs.previewer.show(index)
            })
        }
    }
}
</script>
<style lang='less' scoped>
.product-detail-comment {
  //   background: #fff;
  overflow: hidden;

  .loading {
    text-align: center;
    margin-top: 20px;
  }

  .comment-list {
    padding: 5px 0px 20px;
    box-sizing: border-box;
    border-bottom: 1px solid #eee;
  }

  .comment-header {
    color: #333;
    display: flex;
    align-items: center;
    .header {
      width: 30px;
      height: 30px;
      border-radius: 50%;
      overflow: hidden;
      margin-right: 10px;
      img {
        width: 100%;
        height: 100%;
      }
    }
  }

  .comment-pic {
    // display: flex;
    li {
      float: left;
      display: block;
      background: #fafafa;
      margin-bottom: 6px;
      width: 32%;
      height: 5.6rem;
      margin-right: 1.3%;
      img {
        width: 100%;
        height: 100%;
      }
    }
  }
  .load-btn {
    display: block;
    border-radius: 99px;
    width: 40%;
    margin: 10px auto;
    border-color: #ccc;
  }
}
</style>
