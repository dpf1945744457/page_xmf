<template>
	<HeaderLayout class="product-detail" :showPageLoading="!pageShow">
		<Xheader :class="{'toggle':bodyScrollTop>tabOffsetTop-5}" class="header-fix product-detail-header bottomLine" :style="`background:rgba(250,250,250,${1});`" headerStyle="margin:0 70px;" :right-options="{showMore:false}">
			<span class="header-tab" :class="{'header-tab-active':currentView !='ProductDetailComment'}" @click="toTabView('ProductDetailContent')">详情</span>
			<span class="header-tab" :class="{'header-tab-active':currentView =='ProductDetailComment'}" @click="toTabView('ProductDetailComment')">评价</span>
			<icon name="tab-home" slot="right" @click.native="$router.push('/')" scale="2.3"></icon>
			<!-- <icon name="share1" slot="right" @click.native="$router.push('/')" scale="2.3"></icon> -->
		</Xheader>

		<!-- 商品banner -->
		<ProductDetailSwiper></ProductDetailSwiper>

		<!-- 商品标题 -->
		<ProductDetailTitle @on-share="onShare"></ProductDetailTitle>

		<!-- 规格选择 -->
		<Ucell class="u-cell m-t-5" :title='productItem.specifications && productItem.specifications.join(" ")' :topLine="true" :isLink="true" @click.native="SkuModuleOpen">
			<span class="u-title" slot="icon">已选择：</span>
		</Ucell>

		<!-- 常见问题 -->
		<Ucell class="u-cell" :borderLine="true" :topLine="true" :isLink="true" @click.native="issueOpen = true">
			<span class="u-title" slot="icon">购买说明</span>
		</Ucell>

		<!-- 商品评价摘要 -->
		<!--<ProductDetailCommentBriefly class="m-t-5" @btnShowAll="toTabView('ProductDetailComment')"></ProductDetailCommentBriefly>-->

		<!-- 详情——参数——评价 -->
		<div class="m-t-5" style="height:44px;" ref="tab">
			<tab :class="{'tabs-fixed':bodyScrollTop>tabOffsetTop}" :animate="true" :line-width="1">
				<!-- <tab-item :selected="currentView == item.currentView" v-for="(item,index) in tabItems" @click.native="clickTab(item.currentView)" :key="index">{{item.tabName}}</tab-item> -->
				<tab-item :selected="currentView == 'ProductDetailContent'" @click.native="clickTab('ProductDetailContent')">图文详情</tab-item>
				<tab-item :selected="currentView == 'ProductDetailAttribute'" @click.native="clickTab('ProductDetailAttribute')">商品参数</tab-item>
				<tab-item :selected="currentView == 'ProductDetailComment'" @click.native="clickTab('ProductDetailComment')">用户评价</tab-item>
			</tab>
		</div>

		<!-- 详情——参数——评价 -->
		<keep-alive>
			<component :is="currentView"></component>
		</keep-alive>

		<!-- 推荐商品 -->
		<BDGuessSlider class="m-t-5"></BDGuessSlider>

		<!-- footer -->
		<!--<CommonFooterCopyright></CommonFooterCopyright>-->

		<!-- Bar -->
		<ProductFooterBar></ProductFooterBar>

		<!-- Sku模块 -->
		<SkuModule ref="SkuModule"></SkuModule>

		<!-- 购买说明 -->
		<Popup v-model="issueOpen" position="bottom" :should-scroll-top-on-show="true">
			<PopupHeader title="购买说明" right-text="关闭" left-text="" @on-click-left="issueOpen = false" @on-click-right="issueOpen = false"></PopupHeader>
			<ProductDetailIssue></ProductDetailIssue>
		</Popup>

		<!-- 置顶 -->
		<ViewFixedTool :showCartBar="false" :bottom="50"></ViewFixedTool>

		<!-- 分享 -->
		<GoodsShare ref="GoodsShare"></GoodsShare>
	</HeaderLayout>
</template>
<script>
	import HeaderLayout from "@src/layouts/headerLayout.vue"
	import Xheader from "@src/components/base/x-header"
	import Ucell from '@src/components/base/u-cell'
	import { Tab, TabItem } from '@src/components/base/tab'
	import { Swiper, SwiperItem } from '@src/components/base/swiper'
	import ViewFixedTool from '@src/components/base/view-fixed-tool'
	import LoadMore from "@src/components/base/load-more"
	import CommonFooterCopyright from '@src/components/base/common-footer/footer-copyright.vue'
	import Popup from '@src/components/base/popup'
	import PopupHeader from '@src/components/base/popup-header'
	import ProductDetailSwiper from "./module/product-detail-swiper"
	import ProductDetailTitle from "./module/product-detail-title"
	import ProductDetailAttribute from "./module/product-detail-attribute"
	import ProductDetailContent from "./module/product-detail-content"
	import ProductDetailComment from "./module/product-detail-comment"
	import ProductDetailCommentBriefly from "./module/product-detail-comment-briefly"
	import ProductDetailIssue from "./module/product-detail-issue"
	import ProductFooterBar from './module/product-footer-bar.vue'
	import SkuModule from './module/skuModule/index.vue'
	import scrollOpacity from '@src/mixins/scroll-opacity.js'
	import throttle from '@src/utils/throttle.js'
	import { mapState, mapActions, mapGetters } from "vuex";
	export default {
		components: {
			HeaderLayout,
			Xheader,
			ProductDetailSwiper,
			ProductDetailTitle,
			Tab,
			TabItem,
			Swiper,
			SwiperItem,
			ViewFixedTool,
			Ucell,
			ProductDetailAttribute,
			ProductDetailContent,
			ProductDetailComment,
			ProductDetailCommentBriefly,
			ProductDetailIssue,
			LoadMore,
			CommonFooterCopyright,
			SkuModule,
			ProductFooterBar,
			Popup,
			PopupHeader,
			BDGuessSlider: () =>
				import( /* webpackChunkName: "BDGuessSlider" */ '@src/components/public/bd-guess-slider.1.vue'),
			GoodsShare: () =>
				import( /* webpackChunkName: "goodsShare" */ '@src/components/public/goods-share.vue')
		},
		mixins: [scrollOpacity],
		data() {
			return {
				issueOpen: false,
				id: this.$route.params["id"],
				currentView: "ProductDetailContent",
				index: 0,
				tabOffsetTop: 200000,
				bodyScrollTop: 0,
			}
		},
		computed: {
			...mapGetters(["productItem"]),
			...mapState({
				pageShow: state => state.productDetail.pageShow,
				tabItems: state => state.productDetail.tabItems,
				info: state => state.productDetail.info
			})
		},
		beforeRouteUpdate(to, from, next) {
			// ...
			this.getProductDetailById(to.params["id"]);
			this.currentView = "ProductDetailContent";
			document.documentElement.scrollTop = document.body.scrollTop = 0;
			next();
		},
		created() {
			this.getProductDetailById(this.id);
		},
		mounted() {
//			location.reload()
			// 利用节流函数 20毫秒触发一次
			window.onscroll = throttle(() => {
				this.bodyScrollTop = document.body.scrollTop || document.documentElement.scrollTop;
				this.tabOffsetTop = this.$refs.tab.offsetTop;
			}, 20);
		},
		destroyed() {
			// 移除事件
			window.onscroll = null;
		},
		methods: {
			...mapActions(["getProductDetailById", "isOpenSkuModule"]),
			SkuModuleOpen() {
				this.isOpenSkuModule({
					open: true,
					skuBtnType: "addCart"
				});
			},
			clickTab(currentView) {
				this.currentView = currentView;
				this.toTabView(currentView);
			},
			toTabView(currentView) {
				document.body.scrollTop = document.documentElement.scrollTop = this.$refs.tab.offsetTop;
				this.currentView = currentView;
			},
			onShare() {
				this.$refs.GoodsShare.clickShare();
			}
		},
		beforeRouteLeave(to, from, next) {
			this.isOpenSkuModule({
				open: false
			});
			next();
		}
	}
</script>
<style lang='less' scoped>
	@import "../../components/styles/weui/base/mixin/setOnepx.less";
	.product-detail {
		padding-bottom: 60px;
		//   padding-top: 0 !important;
		.u-cell {
			color: #000;
			padding: 15px 3%;
			.u-title {
				color: #4e4e4e;
			}
		}
	}
	/* header */
	
	.product-detail-header {
		background: transparent;
		border-bottom: none;
		transition: all 0.2s;
		transform: translateY(0%);
	}
	
	.toggle {
		transform: translateY(-100%);
	}
	
	.bottomLine {
		&::after {
			.setBottomLine();
		}
	}
	
	.tabs-fixed {
		position: fixed;
		left: 0;
		//   top: 46px;
		top: 0px;
		width: 100%;
		z-index: 99;
	}
	/* 顶部tab */
	
	.header-tab {
		font-size: 14px;
		margin: 0 5%;
		position: relative;
		display: block;
		height: 80%;
	}
	
	.header-tab-active {
		color: red;
		border-bottom: 1px solid red;
	}
</style>