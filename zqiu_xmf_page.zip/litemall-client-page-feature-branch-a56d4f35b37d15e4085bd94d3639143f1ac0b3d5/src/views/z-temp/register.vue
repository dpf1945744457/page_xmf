<template>
    <UserRegister></UserRegister>
</template>

<script>
import UserRegister from "@src/components/user/user-register.vue"
export default {
    components: { UserRegister }
}
</script>

<style>
</style>
