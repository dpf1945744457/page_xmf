<template>
    <div>
        <Xheader :left-options="{showBack:false}" class="">注册成功</Xheader>
        <div class="box">
            <p>登录用户名：{{userInfo.nickName}}</p>
            <Xbutton mini class="btn m-t-20" @click.native="$router.replace('/')" type="warn">回首页</Xbutton>
            <Xbutton mini class="btn m-t-20" @click.native="toUrl" type="warn">继续访问</Xbutton>
        </div>
    </div>
</template>

<script>

import Xheader from "@src/components/base/x-header"
import Xbutton from "@src/components/base/x-button"
import { mapState, mapActions, mapGetters } from "vuex";
import { setStorage, getStorage, removeStorage } from "@src/utils/storage.js"
export default {
    components: { Xheader, Xbutton },
    data() {
        return {
            redirectUrl: getStorage('redirectUrl')
        }
    },
    computed: {
        ...mapState({
            userInfo: state => state.user.userInfo
        }),
    },
    methods: {
        toUrl() {
            if (this.redirectUrl) {
                this.$router.go(-3)
                removeStorage("redirectUrl");
            } else {
                this.$router.replace("/user");
            }
        }
    }
}
</script>

<style lang="less" scopeed>
.box {
  text-align: center;
  padding: 50px 0;

  .btn {
    margin: 0 auto;
  }
}
</style>
