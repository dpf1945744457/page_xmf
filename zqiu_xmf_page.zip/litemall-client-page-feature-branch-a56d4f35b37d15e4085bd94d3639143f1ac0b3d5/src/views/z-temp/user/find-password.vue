<template>
    <div class="find-password">
        <Xheader class="">找回密码</Xheader>
        <Code ref="Code"></Code>
        <Uinput label="密码" type="password" v-model="params.password" placeholder="请输入至少6位数的密码" maxLength="30" :topLine="true"></Uinput>
        <Uinput label="确认密码" type="password" v-model="params.repassword" placeholder="再次输入密码" maxLength="30" :topLine="true"></Uinput>

        <Xbutton class="btn m-t-20" type="warn" @click.native="userReset">密码重置</Xbutton>
    </div>
</template>

<script>
import Xheader from "@src/components/base/x-header"
import Uinput from "@src/components/base/u-input"
import Xbutton from "@src/components/base/x-button"
import Code from "@src/components/user/code"
import { userReset } from '@src/apis/user.js'
import regExp from '@src/utils/regExp.js'
export default {
    components: { Xheader, Uinput, Xbutton, Code },
    data() {
        return {
            params: {
                password: "",
                repassword: ""
            }
        }
    },
    methods: {
        async userReset() {

            let mobile = this.$refs.Code.mobile;
//          if (!regExp.mobile.reg.test(mobile)) {
//              this.$toast(regExp.mobile.errMsg);
//              return false;
//          }
            let code = this.$refs.Code.code;
            if (!code) {
                this.$toast("请输入验证码");
                return false;
            }

            if (this.params.password.length < 6) {
                this.$toast("请输入至少6位数的密码");
                return false;
            }

            if (!regExp.normal.reg.test(this.params.password)) {
                this.$toast(`密码${regExp.normal.errMsg}`);
                return false;
            }

            if (this.params.password !== this.params.repassword) {
                this.$toast("两次输入的密码不一致");
                return false;
            }

            let data = await userReset({ ...this.params, mobile, code });
            if (data.errno == 0) {
                this.$toast({
                    message: "修改成功，请登录",
                    iconClass: "icon-success_black"
                });
                setTimeout(() => {
                    this.$router.go(-1);
                }, 1000);
            } else {
                this.$toast(data.errmsg);
            }
        }
    }
}
</script>

<style lang="less" scoped>
.btn {
  width: 95%;
}
</style>
