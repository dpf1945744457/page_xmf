<template>
    <div class="user-register">
        <Xheader class="">快速注册</Xheader>
        <Uinput label="用户名" v-model="params.username" placeholder="请输入用户名" maxLength="20"></Uinput>
        <Uinput label="密码" type="password" v-model="params.password" placeholder="请输入至少6位数的密码" maxLength="30" :topLine="true"></Uinput>
        <Uinput label="确认密码" type="password" v-model="params.repassword" placeholder="再次输入密码" maxLength="30" :topLine="true"></Uinput>
        <Code ref="Code"></Code>
        <Xbutton class="btn m-t-20" type="warn" @click.native="register">注册</Xbutton>
    </div>
</template>

<script>
import Xheader from "@src/components/base/x-header"
import Uinput from "@src/components/base/u-input"
import Xbutton from "@src/components/base/x-button"
import Code from "@src/components/user/code"
import channel from '@src/utils/channel.js'
import { mapState, mapActions, mapGetters } from "vuex";
import regExp from '@src/utils/regExp.js'

export default {
    components: { Xheader, Uinput, Xbutton, Code },
    data() {
        return {
            params: {
                username: "",
                password: "",
                repassword: "",
            }
        }
    },
    methods: {
        ...mapActions(["userRegister"]),
        async register() {
            // 用户名去除空格 简单校验不为空
            this.params.username = this.params.username.replace(/\s+/g, "");
            if (this.params.username.length === 0) {
                this.$toast("用户名不能为空");
                return false;
            }

            if (!regExp.normal.reg.test(this.params.username)) {
                this.$toast(`用户名${regExp.normal.errMsg}`);
                return false;
            }

            if (this.params.password.length < 6) {
                this.$toast("请输入至少6位数的密码");
                return false;
            }

            if (!regExp.normal.reg.test(this.params.password)) {
                this.$toast(`密码${regExp.normal.errMsg}`);
                return false;
            }

            if (!this.params.repassword) {
                this.$toast("再次输入密码");
                return false;
            }

            if (this.params.password !== this.params.repassword) {
                this.$toast("两次输入的密码不一致");
                return false;
            }

            let mobile = this.$refs.Code.mobile;
//          if (!regExp.mobile.reg.test(mobile)) {
//              this.$toast(regExp.mobile.errMsg);
//              return false;
//          }
            let code = this.$refs.Code.code;
            if (!code) {
                this.$toast("请输入验证码");
                return false;
            }
            let isSuccess = await this.userRegister({ ...this.params, mobile: mobile, code: code, agentNo: channel.get() });
            if (isSuccess) {
                this.$router.push({ path: "/registerSuccess" });
            }
        }
    }
}
</script>

<style lang="less" scoped>
.header {
  background: #f23030;
  color: #fff;

  a {
    color: #fff !important;
  }
}

.btn {
  width: 95%;
}
</style>
