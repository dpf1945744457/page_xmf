<template>
    <div class="user-login">
        <Code ref="Code"></Code>
        <Xbutton class="btn" type="warn" @click.native="login">登录</Xbutton>
    </div>
</template>

<script>
import Xbutton from "@src/components/base/x-button"
import Code from "@src/components/user/code"
import { setStorage, getStorage, removeStorage } from "@src/utils/storage.js"
import { mapState, mapActions, mapGetters } from "vuex";
import regExp from '@src/utils/regExp.js'
export default {
    components: { Xbutton, Code },
    data() {
        return {
            redirectUrl: this.$route.query['redirect'] || getStorage("redirectUrl"),
        }
    },
    mounted() {
        // 如果没有储存标识 和 有重定向url的话 设置isBack为真就行
        if (this.redirectUrl) setStorage("redirectUrl", this.redirectUrl);
    },
    methods: {
        ...mapActions(["loginByUsername"]),
        async login() {

            let mobile = this.$refs.Code.mobile;
//          if (!regExp.mobile.reg.test(mobile)) {
//              this.$toast(regExp.mobile.errMsg);
//              return false;
//          }
            let code = this.$refs.Code.code;
            if (!code) {
                this.$toast("请输入验证码");
                return false;
            }

            let isSuccess = await this.loginByUsername({ mobile, code })
            if (isSuccess) {
                if (this.redirectUrl) {
                    // this.$router.replace(this.redirectUrl);
                    this.$router.go(-1);
                    removeStorage("redirectUrl");
                } else {
                    this.$router.replace("/user");
                }
            }
        }
    }
}
</script>

<style lang="less" scoped>
.btn {
  width: 95%;
  margin: 30px auto;
}
</style>
