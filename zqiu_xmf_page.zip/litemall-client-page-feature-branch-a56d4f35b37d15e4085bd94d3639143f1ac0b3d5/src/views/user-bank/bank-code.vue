<template>
    <div class="bank_code">
        <Xheader class="header" :left-options="{ showBack: isBack }">{{ $route.meta.title }}</Xheader>
        <header>请输入收到的短信验证码</header>
        <p>{{ phone }}</p>
        <div class="content">
            <van-cell-group>
                <van-field class="pass" center clearable v-model="code" type="tel" placeholder="请输入验证码" maxlength="6">
                    <van-button slot="button" size="small" type="primary" @click="getPhoneCode" class="codes" :loading="load" :disabled="disab">{{ count }}</van-button>
                </van-field>
            </van-cell-group>
            <van-button class="btn" type="primary" size="large" @click="toPassWord" :disabled="disabled">
                <i class="weui-loading" style="margin-bottom: 3px;" v-show="showLoading"></i>下一步
            </van-button>

        </div>
    </div>
</template>

<script>
import Xheader from '@src/components/base/x-header';
import { Cell, CellGroup, Field, Button } from 'vant';
import { checkBindCardSms, postCheckBind, postBankList } from '@src/apis/bank.js';
import { Toast } from 'vant';
	import { mapState, mapActions, mapGetters } from "vuex"
export default {
    name: 'bank_code',
    components: { Cell, CellGroup, Field, Button, Xheader, Toast },
    data() {
        return {
            isBack: Boolean,
            code: '',
            load: false,
            disab: false,
            disabled: true,
            count: '获取验证码',
            formObj: {}
        };
    },
    computed: {
        phone() {
            return this.$route.query.cardPhone;
        },
        ...mapGetters(["showLoading"]),
    },

    mounted() {
        this.sendcode();
        this.getUser();
        this.formObj = this.$route.query;
    },
    methods: {
        async getUser() {
            let res = await postBankList();
            this.formObj.isUser = res.isUser;
        },
        async getPhoneCode() {
            this.load = true;
            let obj = {
                cardNum: this.formObj.cardNum,
                idtCardName: this.formObj.idtCardName,
                idtCardNo: this.formObj.idtCardNo,
                cardFlag: this.formObj.cardFlag,
                cardCountry: this.formObj.cardCountry,
                cardPhone: this.formObj.cardPhone,
                cardExpired: this.formObj.cardExpired,
                cardCvn: this.formObj.cardCvn
            };
            
            let res = await postCheckBind(obj);
            if (res.errno) {
                this.$toast(res.errmsg);
            } else {
            	this.formObj.bindId = res.bindId;
                this.sendcode();
            }
        },
        sendcode() {
            this.disab = true;
            this.load = false;
            let count = 60;
            this.count = '60s';
            let self = this;
            this.timer = setInterval(() => {
                this.load = false;
                if (count > 0 && count <= 60) {
                    count--;
                    self.count = count + 's';
                } else {
                    self.load = false;
                    self.disab = false;
                    clearInterval(self.timer);
                    self.timer = null;
                    self.count = '获取验证码';
                }
            }, 1000);
        },
        async toPassWord() {
            let obj = this.formObj;
            obj.smsCode = this.code;
            this.$store.commit('SHOWLOADING')
            let res = await checkBindCardSms(obj);
            this.$store.commit('HIDELOADING')
            if (res.errno) {
                this.$toast(res.errmsg);
            } else {
            	
                if (this.$store.state.user.bankUser) {
                    this.$router.push('/bankCheckCode');
                } else {
                    let that = this
                    Toast.success({
                        message: '绑定成功！' ,
                        duration: 1500,
                        onClose:function(){
                            that.$router.push('/bank');
                        }
                    });
                }
            }
        }
    },
    watch: {
        code() {
        	
            if (this.code.length > 5) {
                this.disabled = false;
            } else {
                this.disabled = true;
            }
        }
    }
};
</script>

<style scoped lang="less">
.bank_code {
    height: 100%;
    background: #fff;
    header,
    p {
        height: 20px;
        font-size: 16px;
        color: #333333;
        text-align: center;
        line-height: 20px;
    }
    p {
        margin-top: 10px;
    }
    header {
        margin-top: 30px;
        color: #999;
    }
    .pass {
        border-bottom: 1px solid #e6e6e6;
        width: 100% !important;
    }
    .codes {
        background: #fff;
        border: none;
        color: #d2423a;
    }
    .content {
        margin-top: 50px;
        padding: 0 15px;
    }
    .btn {
        background-color: #ffdf00;
        border: none;
        height: 40px;
        line-height: 40px;
        width: 90%;
        margin-left: 5%;
        margin-top: 40px;
        color: #000;
    }
    /deep/ .van-button--disabled {
        opacity: 0.7;
        font-size: 16px;
    }
}
</style>
