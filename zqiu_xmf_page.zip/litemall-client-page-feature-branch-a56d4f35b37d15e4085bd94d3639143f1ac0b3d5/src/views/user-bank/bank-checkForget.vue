<template>
    <div class="bank_add">
        <Xheader class="header" :left-options="{ showBack: isBack }">{{ $route.meta.title }}</Xheader>
        <div class="box">
            <h3>请确认支付密码</h3>
            <van-password-input :value="value" :focused="showKeyboard" @focus="showKeyboard = true" />
            <van-number-keyboard :show="showKeyboard" @input="onInput" @delete="onDelete" @blur="showKeyboard = false" />
        </div>
    </div>
</template>

<script>
import Xheader from '@src/components/base/x-header';
import { changeAccountPwd } from '@src/apis/bank.js';
import { PasswordInput, NumberKeyboard } from 'vant';
import { Toast } from 'vant';
export default {
    components: { Xheader, PasswordInput, NumberKeyboard },
    data() {
        return {
            isBack: Boolean,
            value: '',
            showKeyboard: true
        };
    },
    methods: {
        async onInput(key) {
            this.value = (this.value + key).slice(0, 6);
            if (this.value.length > 5) {
                if (this.value != this.$route.query.code) {
                    this.$toast('密码不一致，请重新输入');
                    this.value = '';
                    return;
                }
                let value = this.$getRSA(this.value);
                let res = await changeAccountPwd({ password: value, reToken: this.$route.query.reToken });
                this.showKeyboard = false;
                if (res.errno) {
                    this.$toast(res.errmsg);
                } else {
                    let that = this;
                    Toast.success({
                        message: '支付密码修改成功！',
                        duration: 1500,
                        onClose: function() {
                            that.$router.push('/bank');
                        }
                    });
                }
            }
        },
        onDelete() {
            this.value = this.value.slice(0, this.value.length - 1);
        }
    }
};
</script>

<style lang="less" scoped>
.bank_add {
    background: #fff;
    height: 100%;
    h3 {
        text-align: center;
        line-height: 100px;
        color: #333333;
    }
    .box {
        position: absolute;
        left: 0;
        right: 0;
        bottom: 0;
        top: 46px;
        background: #fff;

        a {
            line-height: 38px;
            float: right;
            color: #357bb3;
            margin-right: 30px;
        }
    }
}
</style>
