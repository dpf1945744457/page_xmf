<template>
    <div class="bank_add">
        <Xheader class="header" :left-options="{ showBack: isBack }">{{ $route.meta.title }}</Xheader>
        <div class="input"><Uinput label="卡号" width="100" type="tel" disabled v-model="card" placeholder="请输入银行卡号" maxLength="19"></Uinput></div>
        <div class="input" v-if="!checkCardInfo.idtCardName"><Uinput label="姓名" width="100" type="text" v-model="name" placeholder="请输入姓名" maxLength="19"></Uinput></div>
        <div class="input" v-if="checkCardInfo.idtCardName"><Uinput label="姓名" width="100" type="text" disabled v-model="name" placeholder="请输入姓名" maxLength="19"></Uinput></div>
       
       <div class="input inputs">
            <div class="label">证件类型</div>
            <div class="type">
                <van-dropdown-menu><van-dropdown-item v-model="value" :options="option1" /></van-dropdown-menu>
            </div>
        </div>
        <div class="input" v-if="!checkCardInfo.idtCardNo"><Uinput label="证件号码" width="100" type="tel" v-model="num" placeholder="请输入证件号码" maxLength="19"></Uinput></div>
        <div class="input" v-if="checkCardInfo.idtCardNo"><Uinput label="证件号码" width="100" type="tel" disabled v-model="num" placeholder="请输入证件号码" maxLength="19"></Uinput></div>
        <div class="input phone">
            <Uinput label="手机号" type="tel" width="75%" v-model="phone" placeholder="请输入银行开户预留手机号" maxLength="19"></Uinput>
            <div class="area" @click="show = true">
                +{{ area }}
                <icon class="tool-icon" slot="icon" name="arrow" scale="1.5"></icon>
            </div>
        </div>
        <div class="input card bor" v-if="cardType">
            <Uinput label="有效期" type="tel" width="70%" v-model="time" placeholder="示例：09/15，输入0915" maxLength="4"></Uinput>
            <div class="area">
                <!-- <div @click="changeTime(isTime)"><icon class="eyes-icon" slot="icon" name="eyes" scale="2"></icon></div> -->
                <!-- <p></p> -->
                <div @click="showEyes = true"><icon class="warning-icon" slot="icon" name="warning" scale="2"></icon></div>
            </div>
        </div>
        <div class="input card" v-if="cardType">
            <Uinput label="CVN" type="tel" width="70%" v-model="CVN" placeholder="卡背后三位数字" maxLength="3"></Uinput>
            <div class="area">
                <!-- <div @click="changeEye(isCVN)"><icon class="eyes-icon" slot="icon" name="eyes" scale="2"></icon></div> -->
                <!-- <p></p> -->
                <div @click="showTime = true"><icon class="warning-icon" slot="icon" name="warning" scale="2"></icon></div>
            </div>
        </div>

        <Xbutton class="btn" type="dd" @click.native="nextStep">
            <i class="weui-loading" style="margin-bottom: 3px;" v-show="showLoading"></i>
            下一步
        </Xbutton>



        <van-action-sheet v-model="show" :actions="actions" @select="onSelect" />

        <van-overlay :show="showEyes" class-name="overlay" @click="showEyes = false" />
        <div class="showTime show" v-show="showEyes">
            <div class="strip"></div>
            <div class="ellipsis">**** **** **** ****</div>
            <p class="card_time">08/16</p>
            <p class="card_bot">MM/YY 卡正面有效期，如08/16</p>
        </div>

        <van-overlay :show="showTime" class-name="overlay" @click="showTime = false" />
        <div class="showSvn show" v-show="showTime">
            <div class="strip"></div>
            <p class="card_time">8482 939</p>
            <p class="card_bot">卡背面三位数字，如939</p>
        </div>
    </div>
</template>

<script>
import Xheader from '@src/components/base/x-header';
import Uinput from '@src/components/base/u-input';
import Xbutton from '@src/components/base/x-button';
import { DropdownMenu, DropdownItem, ActionSheet, Overlay } from 'vant';
import { postCheckBind,postCheckCard } from '@src/apis/bank.js';
	import { mapState, mapActions, mapGetters } from "vuex"
export default {
    components: { Xheader, Uinput, Xbutton, DropdownMenu, DropdownItem, ActionSheet, Overlay },
    data() {
        return {
            showEyes: false,
            showTime: false,
            isBack: Boolean,
            keepCard: '',
            isFalse: false,
            card: '',
            name: '',
            type: '',
            num: '',
            phone: '',
            time: '',
            keepTime: '',
            isTime: false,
            CVN: '',
            keepCVN: '',
            isCVN: false,
            area: '86',
            value: 0,
            option1: [{ text: '身份证', value: 0 }, { text: '护照', value: 1 }, { text: '回乡证', value: 2 }, { text: '士兵证', value: 3 }, { text: '警官证', value: 4 }],
            show: false,
            actions: [
                { name: '+86 中国', value: '86' },
                { name: '+852 香港', value: '852' },
                { name: '+65 新加坡', value: '65' },
                { name: '+853 澳门', value: '853' },
                { name: '+60 马来西亚', value: '60' }
            ],
            isTrue: true,
            checkCardInfo: {}
        };
    },
    computed: {
        ...mapGetters(["showLoading"]),
        cardType(){
            if(this.$route.query.type == '1'){
                return false
            }
            return true
        }
    },
    created(){
    	this.card = this.$route.query.card;
    	this.checkType();
    },
    methods: {
    	async checkType(){
            let res = await postCheckCard({cardNum:this.card});
            
            if(!res.errno){
            	this.checkCardInfo = res;
            	this.num = this.checkCardInfo.idtCardNo;
            	this.name = this.checkCardInfo.idtCardName;
//              this.$router.push({path:'/bankInfo',query:{card:this.mobile,type:res.cardType}})
            }else{
                this.$toast(res.errmsg)
            }
        },
        async nextStep() {
            if (!this.check()) return;
            this.$store.commit('SHOWLOADING')
            this.isTrue = false
            this.keepCard = this.card.replace(/\s+/g, '');
            let obj = {
                "cardNum": this.keepCard,
                "idtCardName": this.name,
                "idtCardNo": this.num,
                "cardFlag": this.value,
                "cardCountry": this.area,
                "cardPhone": this.phone,
                "cardExpired": this.time,
                "cardCvn": this.CVN,
            }
            let res = await postCheckBind(obj)
            this.isTrue = true
            this.$store.commit('HIDELOADING')
            if(res.errno){
                this.$toast(res.errmsg)
            }else{
                obj.bindId = res.bindId
                this.$router.push({ name: 'bankCode', query: obj });
            }

        },
        check() {
            if(!this.isTrue){
                return false;
            }
            if (this.name == '') {
                this.$toast('请输入姓名');
                return false;
            }
            if (this.num == '') {
                this.$toast('请输入证件号码');
                return false;
            }
            if (this.phone == '') {
                this.$toast('请输入银行开户预留手机号');
                return false;
            }
            if (this.time == '' && this.cardType) {
                this.$toast('请输入有效期');
                return false;
            }
            if (this.CVN == '' && this.cardType) {
                this.$toast('请输入CVN');
                return false;
            }
            return true;
        },
        onSelect(item) {
            // 点击选项时默认不会关闭菜单，可以手动关闭
            this.show = false;
            this.area = item.value;
            
        },
        changeEye(type) {
            if (!type) {
                this.keepCVN = this.CVN;
                let str = '';
                for (let i in this.CVN) {
                    str += '*';
                }
                this.CVN = str;
            } else {
                this.CVN = this.keepCVN;
            }
            this.isCVN = !type;
        },
        changeTime(type) {
            if (!type) {
                this.keepTime = this.time;
                let str = '';
                for (let i in this.time) {
                    str += '*';
                }
                this.time = str;
            } else {
                this.time = this.keepTime;
            }
            this.isTime = !type;
        },
    },
    mounted() {
//      this.card = this.$route.query.card;
//      console.log(this.card)
    }
};
</script>

<style lang="less" scoped>
.bank_add {
    background: #fff;
    height: 100%;
    .btn {
        width: 95%;
        margin: 30px auto;
        background: #ffdf00;
        color: #000;
    }
    .input {
        width: 95%;
        margin: 0 auto;
        line-height: 56px;
        border-bottom: 1px solid #e6e6e6;
        /deep/ .form-group dl dt {
            height: unset;
            line-height: unset;
        }
        /deep/ .form-group dl dd {
            height: unset;
            line-height: unset;
        }
    }
    .inputs {
        height: 50px;
        display: flex;
        /deep/ .van-overlay {
            background: rgba(0, 0, 0, 0);
        }
        .label {
            color: #222;
            padding-left: 10px;
            line-height: 50px;
            flex: 2.5;
            text-align: left;
        }
        .type {
            padding-right: 14px;
            flex: 1;
        }
    }
    .change {
        opacity: 0.5;
    }
    .phone {
        position: relative;
        border: none;
        .area {
            height: 30px;
            width: 60px;
            // border-left: 1px solid #e6e6e6;
            line-height: 30px;
            position: absolute;
            top: 4px;
            bottom: 0;
            margin: auto;
            right: 5px;
        }
    }
    .bor {
        border-top: 10px solid #f6f6f6;
    }
    .card {
        width: 100%;
        padding: 0 3%;
        box-sizing: border-box;
        position: relative;
        .area {
            height: 30px;
            width: 50px;
            line-height: 30px;
            position: absolute;
            top: 10px;
            bottom: 0;
            margin: auto;
            right: 10px;
            .eyes-icon {
                margin-right: 5px;
            }
            .warning-icon {
                margin-left: 5px;
            }
            p {
                display: inline-block;
                height: 70%;
                width: 1px;
                background: #e6e6e6;
                margin: 0 auto;
            }
            div {
                display: inline-block;
                width: 25px;
                height: 30px;
            }
        }
    }
    /deep/ .van-popup--top {
        width: 35%;
        right: 0 !important;
        left: unset;
    }
    /deep/ .form-control {
        width: 95%;
        text-align: right;
    }
    .header {
        // background: #ffdf00;
    }
    .btn {
        width: 95%;
        margin: 30px auto;
        background: #ffdf00;
        color: #000;
    }
    .overlay {
        background: rgba(51, 51, 51, 0.3);
    }
    .show {
        background: #ffffff;
        border-radius: 20px;
        width: 280px;
        height: 180px;
        position: fixed;
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
        margin: auto;
        z-index: 9999;
        padding: 20px 28px;
        box-sizing: border-box;
    }
    .showTime {
        .strip {
            width: 108px;
            height: 24px;
            border-radius: 3px;
            background: #e3e9ef;
        }
        .ellipsis {
            margin-top: 10px;
            font-size: 22px;
            color: #666666;
            line-height: 22px;
        }
        .card_time {
            font-size: 18px;
            color: #d2423a;
            line-height: 24px;
        }
        .card_bot {
            position: absolute;
            bottom: 30px;
            font-size: 14px;
            color: #333333;
            text-align: center;
            line-height: 14px;
        }
    }
    .showSvn {
        padding: unset;
        padding-top: 20px;
        .strip {
            width: 100%;
            height: 36px;
            background: #e3e9ef;
        }
        .card_time {
            width: 120px;
            line-height: 30px;
            margin-left: 28px;
            margin-top: 10px;
            background: #e3e9ef;
            border-radius: 5px;
            color: #d2423a;
            text-align: right;
        }
        .card_bot {
            position: absolute;
            bottom: 30px;
            font-size: 14px;
            color: #333333;
            width: 100%;
            text-align: center;
            line-height: 14px;
        }
    }
}
</style>
