<template>
    <div class="bank_card">
        <Xheader class="header" :left-options="{preventGoBack:true}" @on-click-back="$router.replace('/user')">
            {{ $route.meta.title }}
            <icon name="add" slot="right" @click.native="toPath" scale="2.3"></icon>
        </Xheader>

        <card ref='card'></card>
    </div>
</template>

<script>
import Xheader from '@src/components/base/x-header';
import card from './module/bankCard';
import { mapState, mapActions, mapGetters } from 'vuex';
export default {
    components: { Xheader, card },
    computed: {
        ...mapGetters(['isLogin'])
    },

    data() {
        return {
            isBack: Boolean,
        };
    },
    mounted() {
    },
    methods: {
        toPath(){
            this.$refs.card.toPath()
        }
    },
};
</script>

<style lang="less" scoped>
	.bank_card {
		
	}
</style>
