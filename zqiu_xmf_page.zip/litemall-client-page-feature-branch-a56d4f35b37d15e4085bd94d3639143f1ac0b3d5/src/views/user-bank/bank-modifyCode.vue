<template>
    <div class="bank_add">
        <Xheader class="header" :left-options="{preventGoBack:true}"  @on-click-back="$router.replace('/bank')">{{ $route.meta.title }}</Xheader>
        <div class="box">
            <h3>请输入支付密码，以验证身份</h3>
            <van-password-input :value="value" :focused="showKeyboard" @focus="showKeyboard = true" />
            <van-number-keyboard :show="showKeyboard" @input="onInput" @delete="onDelete" @blur="showKeyboard = false" />
            <p><a @click="$router.push('/bankChange')">忘记密码</a></p>
        </div>
    </div>
</template>

<script>
import Xheader from '@src/components/base/x-header';
import { checkPayPwd } from '@src/apis/bank.js';
import { PasswordInput, NumberKeyboard } from 'vant';
export default {
    components: { Xheader, PasswordInput, NumberKeyboard },
    data() {
        return {
            isBack: Boolean,
            value: '',
            showKeyboard: true
        };
    },
    methods: {
        nextStep() {
            this.$router.push({ path: '/bankInfo', query: { card: this.mobile } });
        },
        async onInput(key) {
            this.value = (this.value + key).slice(0, 6);
            if(this.value.length > 5){
                let value = this.$getRSA(this.value)
                let res = await checkPayPwd({password : value})
                this.showKeyboard = false
                if(res.errno){
                    this.$toast(res.errmsg)
                    this.value = ''
                }else{
                    this.$router.push('/addCard')
                }
            }
        },
        onDelete() {
            this.value = this.value.slice(0, this.value.length - 1);
        }
    }
};
</script>

<style lang="less" scoped>
.bank_add {
    background: #fff;
    height: 100%;
    h3 {
        text-align: center;
        line-height: 100px;
        color: #333333;
    }
    .box{
        position: absolute;
        left: 0;
        right: 0;
        bottom: 0;
        top: 46px;
        background: #fff;

        a{
            line-height: 38px;
            float: right;
            color: #357bb3;
            margin-right: 30px;
        }
    }
}
</style>
