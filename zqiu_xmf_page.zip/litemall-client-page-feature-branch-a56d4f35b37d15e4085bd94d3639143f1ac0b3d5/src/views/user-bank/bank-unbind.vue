<template>
    <div class="bank_card">
        <Xheader class="header" :left-options="{preventGoBack:true}" @on-click-back="$router.replace('/bank')">
            {{ $route.meta.title }}
            <a slot="right" @click="unbind" class="unbind_icon">解绑</a>
        </Xheader>
		<div class="cardList">
			<ul>
				<li @click.stop.prevent="">
					<div class="img_box"><img :src="cardInfo.cardImage" alt="" /></div>
					<p class="cardType">{{cardInfo.cardType}}</p>
					<div class="cardInfo">
						<p class="card_num">{{cardInfo.cardNum}}</p>
						<p class="icon"  @click="watchCard()" :class="isKeep ? 'open' : 'close'"></p>
					</div>
				</li>
			</ul>
		</div>
    </div>
</template>

<script>
import Xheader from '@src/components/base/x-header';
import { mapState, mapActions, mapGetters } from 'vuex';
export default {
    components: { Xheader },
    computed: {
        ...mapGetters(['isLogin'])
    },

    data() {
        return {
            isBack: Boolean,
            cardInfo: JSON.parse(localStorage.getItem("cardInfo")),
            cardId: JSON.parse(localStorage.getItem("cardInfo")).cardNum,
            isKeep: false
        };
    },
    created() {
    	if (this.isKeep) {
            this.cardInfo.cardNum = this.cardInfo.cardNum;
        } else {
            this.cardInfo.cardNum = '**** **** **** ' + this.cardInfo.cardNum.substring(this.cardInfo.cardNum.length - 4);
            
        }
    	
    },
    methods: {
    	watchCard(){
    		if (!this.isKeep) {
	            this.cardInfo.cardNum = this.cardId;
	            this.isKeep = true;
	        } else {
	            this.cardInfo.cardNum = '**** **** **** ' + this.cardInfo.cardNum.substring(this.cardInfo.cardNum.length - 4);
	            this.isKeep = false;
	        }
    	},
    	unbind(){
    		this.$router.push('/unbindCardCode');
    	}
    },
};
</script>

<style lang="less" scoped>
	.unbind_icon {
		font-family: PingFang-SC-Medium;
		font-size: 15px;
		color: #666666;
	}
	.cardList li{
		position: relative;
		margin: 20px 16px 0 16px;
		height: 112px;
		/*background-image: linear-gradient(135deg, #F8456A 0%, #F88466 100%);*/
		border-radius: 6px;
		.img_box {
        	position: absolute;
        	top: 0;
        	left: 0;
            /*flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;*/
            img {
                width: 100%;
                pointer-events: none;
            }
        }
		.cardType{
			padding: 32px 0 22px 48px;
			box-sizing: border-box;
			opacity: 0.8;
			font-family: PingFangSC-Regular;
			font-size: 12px;
			color: #FFFFFF;
		}
		.cardInfo{
			display: flex;
			margin: 0 24px 0 48px;
			.card_num{
				z-index: 1;
				flex: 3;
				font-family: PingFang-SC-Medium;
				font-size: 18px;
				color: #FFFFFF;
			}
			.icon{
				z-index: 1;
				flex: 1;
			}
			.icon.close{
				background: url(../../assets/img/user/eye_close.png) no-repeat right center;
				background-size: 19px 8px;
			}
			.icon.open{
				background: url(../../assets/img/user/eye_open.png) no-repeat right center;
				background-size: 24px 15px;
			}
		}
	}
</style>
