<template>
    <HeaderLayout>
        <Xheader class="header-fix" :title="$route.meta.title" :left-options="{preventGoBack:true}" @on-click-back="$router.replace('/user')"></Xheader>

        <tab class="header-fix" style="top: 47px;" v-model="showType">
            <tab-item @click.native="getOrderList(0)" :selected="showType == 0">全部</tab-item>
            <tab-item @click.native="getOrderList(1)" :selected="showType == 1">待付款</tab-item>
            <tab-item @click.native="getOrderList(2)" :selected="showType == 2">待发货</tab-item>
            <tab-item @click.native="getOrderList(3)" :selected="showType == 3">待收货</tab-item>
            <tab-item @click.native="getOrderList(4)" :selected="showType == 4">待评价</tab-item>
        </tab>
        <keep-alive>
            <component :is="componentId" :showType="showType"></component>
        </keep-alive>
    </HeaderLayout>
</template>
<script>
import HeaderLayout from "@src/layouts/headerLayout.vue"
import Xheader from "@src/components/base/x-header"
import { Tab, TabItem } from '@src/components/base/tab'
import historyReplaceState from '@src/utils/history-replace-state.js'
import OrderList5 from './order-view.vue'
import OrderList1 from './order-view.vue'
import OrderList2 from './order-view.vue'
import OrderList3 from './order-view.vue'
import OrderList4 from './order-view.vue'

export default {
    components: {
        HeaderLayout, Xheader, Tab, TabItem,
        OrderList5,
        OrderList1,
        OrderList2,
        OrderList3,
        OrderList4
    },
    data() {
        return {
            showType: Number(this.$route.query["showType"]) || 0,
            componentId: ""
        }
    },
    created() {
        this.getOrderList(this.showType);
    },
    methods: {
        async getOrderList(showType) {
            this.showType = showType;
            this.componentId = "OrderList" + (showType + 1);
            historyReplaceState({ showType: showType });
        },
    },

}
</script>
<style lang='less' scoped>
</style>