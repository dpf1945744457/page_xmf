<template>
  <div class="goodsSpecifications">
    <indexHeader></indexHeader>
    <div>
      <!-- <div class="headerBox">
        <div class="goodsName">{{info.name}}</div>

        <div class="goodsPrice">HK${{productItem.price | filterPrice}}</div>

        <div class="closeIcon" @click="backHome">x</div>
      
      </div>-->
      <div class="header-info com-bottom-1px">
        <img :src="productItem.url || imgUrl" />
        <div class="attribute-header-right">
          <p class="goodprice">{{info.name}}</p>
          <p class="goodprice price-color">HK${{productItem.price | filterPrice}}</p>
          <p class="goodprice">库存：{{productItem.number}}{{info.unit | unit}}</p>
          <p
            class="goodprice"
          >已选：{{productItem.specifications && productItem.specifications.join(" ")}}</p>
          <p
            class="goodprice"
            v-if="taxFlag!=1"
            style="color:red"
          >税费:HK${{productItem.incomeTax*productDetail.number| filterPrice}}</p>
        </div>
      </div>
      <div class="content">
        <div class="specification">
          <div v-for="(item,index) in productDetail.specificationList" :key="index">
            <div class="title">{{item.name}}:</div>
            <div class="lists">
              <checker
                v-model="item.checked"
                default-item-class="sku-item"
                selected-item-class="sku-item-selected"
                :radio-required="true"
              >
                <checker-item
                  v-for="(_item,i) in item.valueList"
                  :key="i"
                  :value="_item" @on-item-click="onItemClick(_item)"
                >{{_item.value}}</checker-item>
              </checker>

              <div class="clear"></div>
            </div>
          </div>
        </div>
        <div class="goodsNumber">
          <div class="title">数量:</div>
          <div class="numberBox">
            <!--<div class="reduceIcon" @click="reduceCount(item.id)">-</div>
						<div class="amount">{{currentNumber}}</div>
            <div class="addIcon" @click="addCount(item.id)">+</div>-->
            <Xnumber
              v-model="productDetail.number"
              :min="1"
              :max="5"
              :align="'left'"
              :myGoodsStyle="1"
            ></Xnumber>
          </div>
        </div>
      </div>
      <div class="footer">
        <div class="others">
          <div class="backIcon" @click="backHome"></div>
          <div class="customerService">
            <div class="icon"></div>
            <div class="text" @click="contact">客服</div>
          </div>
          <div class="collect" @click="postCollectByGoods" v-if="userHasCollect == 0">
            <div class="icon"></div>
            <div class="text">收藏</div>
          </div>
          <div class="collect" @click="postCollectByGoods" v-else>
            <div class="icon active"></div>
            <div class="text">已收藏</div>
          </div>
        </div>

        <div class="addCart" v-if="productItem.number > 0" @click="clickAddCart">加入购物车</div>
        <div class="buyIcon" v-if="productItem.number > 0" @click="clickBuyNow">立即购买</div>

        <div class="disable" v-if="productItem.number == 0">暂无库存</div>
      </div>
    </div>

    <!--底部导航-->
    <!-- <TabbarLayout ></TabbarLayout> -->
  </div>
</template>

<script>
import indexHeader from "../home/module/header";
import TabbarLayout from "@src/layouts/tabbar.vue";
import { mapState, mapActions, mapGetters } from "vuex";
import Xnumber from "@src/components/base/x-number";
import unitJson from "@src/data/unit.json";
import { Checker, CheckerItem } from "@src/components/base/checker";

const Big = require("big.js");
export default {
  filters: {
    filterPrice: function(num) {
      return Number(num).toFixed(2);
    },
    unit(unitCode) {
      let unit = unitJson.find(item => item.code == unitCode);
      if (unit) {
        return unit.name;
      } else {
        return "";
      }
    }
  },
  components: {
    indexHeader,
    TabbarLayout,
    Xnumber,
    Checker,
    CheckerItem
  },
  data() {
    return {
      id: this.$route.params["id"],
      currentNumber: 1,
      min: 1,
      max: 5,
      step: 1,
      chooseId: "",
      taxFlag: 0,
      incomeTax: 0,
      imgUrl: require("@src/assets/img/logo.png")
    };
  },
  computed: {
    ...mapState({
      productDetail: state => state.productDetail,
      info: state => state.productDetail.info,
      productList: state => state.productDetail.productList,
      userHasCollect: state => state.productDetail.userHasCollect
    }),
    ...mapGetters(["productItem", "isLogin"])
  },
  created() {
    console.log(this.$store.state);
    this.getProductDetailById(this.id);
    setTimeout(() => {
      console.log(this.productList);
      this.info.retailPrice = this.$store.state.productDetail.productList[0].price;
      this.incomeTax = this.$store.state.productDetail.productList[0].incomeTax;
      this.taxFlag = this.$store.state.productDetail.productList[0].taxFlag;
    }, 1000);
  },
  methods: {
    ...mapActions([
      "getProductDetailById",
      "addCart",
      "buyNow",
      "postCollectByGoods"
    ]),
    reduceCount(id) {
      if (!this.isLogin) {
        this.$router.push({
          path: "/phoneLogin",
          query: { redirect: this.$route.fullPath }
        });
      } else {
        if (this.currentNumber > this.min) {
          //						this.currentNumber --;
          const x = new Big(this.currentNumber);
          this.currentNumber = x.minus(this.step) * 1;
        }
      }
    },
    addCount(id) {
      if (!this.isLogin) {
        this.$router.push({
          path: "/phoneLogin",
          query: { redirect: this.$route.fullPath }
        });
      } else {
        if (this.currentNumber < this.max) {
          const x = new Big(this.currentNumber);
          this.currentNumber = x.plus(this.step) * 1;
        }
      }
    },
    onItemClick() {
      this.productDetail.number = 1;
    },
    clickAddCart() {
      this.addCart().then(
        () => {
          //	                this.$toast({
          //	                    message: "加入购物车成功",
          //	                    iconClass: "icon-success_black"
          //	                });
          this.$router.push({ path: "/" });
          // location.reload();
        },
        msg => {
          this.$toast(msg);
        }
      );
      //	            setTimeout(() => {
      //	            	this.$router.push({ path: "/"});
      //	            },500)
    },
    // 用户点击立即购买
    clickBuyNow() {
      this.buyNow().then(
        cartId => {
          this.$router.push({ path: "/cart/confirm", query: { cartId } });
        },
        msg => {
          this.$toast(msg);
        }
      );
    },
    contact() {
      window.location.href =
        "https://im.7x24cc.com/phone_webChat.html?accountId=N000000013029&chatId=6aded8fa-f405-4371-8aba-c982f8fb7f8d";
    },
    backHome() {
      this.$router.push({ path: "/" });
    },
    chooseSpec(id) {
      this.chooseId = id;
    }
  }
};
</script>

<style lang="less" scoped>
.disable {
  background: #dbdbdb;
  flex: 1;
  line-height: 44px;
  background: #ff4a10;
  font-family: PingFangSC-Regular;
  font-size: 18px;
  color: #ffffff;
  text-align: center;
}
.header-info {
  height: 100px;
  margin-top: 24px;
  color: #58595b;
  background: #fff;

  img {
    width: 90px;
    height: 90px;
    border: #f8f8f8 1px solid;
    border-radius: 4px;
    padding: 5px;
    background: #fff;
    margin-top: -15px;
    margin-left: 15px;
    float: left;
  }

  .attribute-header-right {
    margin-left: 10px;

    float: left;
    overflow: hidden;
    width: 60%;
    .goodprice {
      display: block;
      width: 100%;
      overflow: hidden;
      color: #666;
      font-size: 12px;
      line-height: 150%;
      white-space: nowrap;
      text-overflow: ellipsis;
    }

    .price-color {
      color: #f23030;
      font-size: 18px;
    }
  }

  .choose-attribute-close {
    position: absolute;
    top: -20px !important;
    right: 8px;
    width: 38px;
    height: 38px;
    line-height: 25px;
    text-align: center;
    background-color: rgb(255, 255, 255);
    border-radius: 0px;
    border-top-right-radius: 3px;
    border-top-left-radius: 3px;
    z-index: 9999999;
    opacity: 1;
    border: 0px;
    font-size: 22px;
    color: #000;
    background-image: none;
  }
}

.goodsSpecifications {
  width: 100%;
  background: #ffffff;
  .headerBox {
    padding-left: 13px;
    display: flex;
    height: 40px;
    line-height: 40px;
    background: #f3f3f5;
    font-family: PingFang-SC-Bold;
    box-sizing: border-box;
    .goodsName {
      flex: 2;
      font-size: 20px;
      color: #333333;
      overflow: hidden;
    }
    .goodsPrice {
      flex: 1.5;
      font-size: 16px;
      color: #ff4a10;
    }
    .closeIcon {
      flex: 1;
      color: #999999;
      text-align: center;
      font-size: 30px;
      line-height: 34px;
    }
  }
  .content {
    font-family: PingFangSC-Regular;
    .title {
      margin: 6px 0;
      padding-left: 12px;
      box-sizing: border-box;
      font-size: 15px;
      color: #666666;
    }
    .lists {
      padding-left: 7px;
      box-sizing: border-box;
      font-size: 17px;
      color: #333333;
      li {
        margin: 5px;
        float: left;
        width: 80px;
        height: 38px;
        line-height: 38px;
        background: #f3f3f5;
        border-radius: 4px;
        text-align: center;
      }
      .active {
        font-family: PingFangSC-Medium;
        font-size: 17px;
        color: #333333;
        background: rgba(247, 207, 32, 0.5);
      }
      .clear {
        clear: both;
      }
    }
    .goodsNumber {
      margin-top: 16px;
      .numberBox {
        margin-left: 12px;
        color: #000000;
        font-size: 21px;
        .reduceIcon,
        .addIcon {
          display: inline-block;
          width: 36px;
          height: 36px;
          line-height: 36px;
          background: #f3f3f5;
          border-radius: 4px;
          text-align: center;
        }
        .amount {
          padding: 0 20px;
          display: inline-block;
          height: 36px;
          line-height: 36px;
          font-family: PingFangSC-Regular;
          color: #333333;
          box-sizing: border-box;
          vertical-align: top;
        }
        .weui-cell {
          padding: 0 !important;
        }
        .weui-cell:before {
          content: none;
        }
      }
    }
  }
  .footer {
    position: fixed;
    bottom: 0px;
    left: 0;
    display: flex;
    width: 100%;
    height: 44px;
    .others {
      display: flex;
      flex: 1;
      text-align: center;
      background: #f6f6f6;
      .backIcon {
        flex: 1;
        background: url(../../assets/img/specificate/arrow_left@2x.png)
          no-repeat center center;
        background-size: 12px 22px;
      }
      .customerService {
        flex: 1;
        padding-top: 3px;
        box-sizing: border-box;
        .icon {
          width: 100%;
          height: 24px;
          background: url(../../assets/img/specificate/contact@2x.png) no-repeat
            center center;
          background-size: 24px;
        }
        .active {
          background: url(../../assets/img/specificate/contact_active@2x.png)
            no-repeat center center;
          background-size: 24px;
        }
        .text {
          font-family: PingFang-SC-Medium;
          font-size: 10px;
          color: #999999;
        }
      }
      .collect {
        flex: 1;
        padding-top: 3px;
        box-sizing: border-box;
        .icon {
          width: 100%;
          height: 24px;
          background: url(../../assets/img/specificate/collect@2x.png) no-repeat
            center center;
          background-size: 24px;
        }
        .active {
          background: url(../../svg/collection-active.svg) no-repeat center
            center;
          background-size: 24px;
        }
        .text {
          font-family: PingFang-SC-Medium;
          font-size: 10px;
          color: #999999;
        }
      }
    }
    .addCart {
      flex: 1;
      line-height: 44px;
      background: #f7cf20;
      font-family: PingFangSC-Regular;
      font-size: 18px;
      color: #ffffff;
      text-align: center;
    }
    .buyIcon {
      flex: 1;
      line-height: 44px;
      background: #ff4a10;
      font-family: PingFangSC-Regular;
      font-size: 18px;
      color: #ffffff;
      text-align: center;
    }
  }

  .sku-item {
    margin: 5px;
    padding: 0 10px;
    float: left;
    line-height: 38px;
    background: #f3f3f5;
    border-radius: 4px;
    text-align: center;
  }

  .sku-item-selected {
    font-family: PingFangSC-Medium;
    font-size: 17px;
    color: #333333;
    background: rgba(247, 207, 32, 0.5);
  }
}
</style>