<template>
    <div>
        <div class="payment-page">
            <div class="content-box">
            	<p class="logo"></p>
                <p class="title success">订单已受理</p>
                <div class="priceBox">
                	HK$
                	<span class="price">{{amount | filterPrice}}</span>
                </div>
                <p class="payType">{{type}}</p>
            </div>
            <div class="button-group">
                <a @click="toOrder" class="button orderDetails">
                    查看订单详情
                </a>
                <a @click="toIndex" class="button goOn">
                    继续逛
                </a>
            </div>
        </div>
    </div>

</template>
<script>
import "@src/assets/less/butcommon.less"
export default {
    components: {
    },
    props: {
    	amount:{
    		type: String
    	},
    	type:{
    		type: String
    	}
    },
    head() { return {} },
    asyncData(context) { },
    data() { return {} },
    fetch() { },
    methods: {
        toIndex() {
            this.$router.replace('/')
        },
        toOrder() {
            this.$router.replace('/order')
        }
    },
    filters: {
		filterPrice: function(num) {
			return Number(num).toFixed(2);
		}
	},
}
</script>
<style lang='less' scoped>
.payment-page {
  background: #fff;
  padding: 40px 15px 10px;
  .content-box {
    text-align: center;
    .logo{
    	width: 100%;
    	height: 60px;
    	background: url(../../../assets/img/icon_zfcg.png) no-repeat center center;
    	background-size: 60px;
    }
    p {
      line-height: 25px;
    }
    /*.title {
      font-size: 18px;
      // font-weight: bold;
      padding: 10px 0;
      &.fail {
        color: #e0443b;
      }
      &.success {
        color: #1aad19;
      }
    }*/
    .success{
    	margin: 10px 0;
    	font-family: PingFang-SC-Medium;
		font-size: 18px;
		color: #333333;
    }
    .priceBox{
    	font-family: PingFang-SC-Heavy;
		font-size: 14px;
		color: #FB4D44;
		span{
			font-family: DINAlternate-Bold;
			font-size: 48px;
			color: #FB4D44;
		}
    }
    .payType{
    	font-family: PingFangSC-Regular;
		font-size: 13px;
		color: #666666;
    }
  }
  .button-group {
    display: flex;
    flex-direction: row;
    height: 44px;
    justify-content: space-around;
    align-items: center;
    margin-top: 50px;
    .button {
    	width: 150px;
    	height: 44px;
    	line-height: 44px;
		border-radius: 22px;
		text-align: center;
		font-family: PingFang-SC-Medium;
		font-size: 18px;
		color: #333333;
    }
    .orderDetails{
    	border: 1px solid #333333;
    }
    .goOn{
		background: #F7CF20;
    }
  }
}
</style>