<template>
    <HeaderLayout>
        <Xheader class="header-fix">
            <i slot="overwrite-left"></i>
            支付结果
        </Xheader>
        <LoadingPage v-if="showPageLoading"></LoadingPage>
        <Success v-if="tradeStatus=='00'" :amount='txnAmt' :type="payType"></Success>
        <Fail v-if="tradeStatus=='01'"></Fail>
       	
    </HeaderLayout>

</template>
<script>
import HeaderLayout from "@src/layouts/headerLayout.vue"
import Xheader from "@src/components/base/x-header"
import LoadingPage from "@src/components/base/loadingPage"
import Success from "./module/success"
import Fail from "./module/fail"
export default {
    components: {
        HeaderLayout,
        Xheader,
        Success,
        Fail,
        LoadingPage
    },
    props: [],
    head() { return {} },
    asyncData(context) { },
    data() {
        return {
            tradeStatus: '',
            txnAmt:'',
            payType:'',
            showPageLoading: true,
        }
    },
    fetch() { },
    created(){
      	setTimeout(() => {
      		this.showPageLoading = false;
			this.tradeStatus = this.$route.query.tradeStatus || '00';
			this.txnAmt = this.$route.query.txnAmt;
			this.payType = this.$route.query.payType;
        }, 3000)
    },
    methods: {

    },
    mounted() {
        history.pushState(null, null, document.URL);
        window.addEventListener('popstate', function () {
            history.pushState(null, null, document.URL);
        });
    },
    watch: {
        $route(val) {
            this.tradeStatus = this.$route.query.tradeStatus
        }
    }
}
</script>
<style lang='less' scoped>
// .payment-page {
//   background: #fff;
//   padding: 40px 15px 10px;
//   .content-box {
//     text-align: center;
//     p {
//       line-height: 25px;
//     }
//     .title {
//       font-size: 18px;
//       // font-weight: bold;
//       padding: 10px 0;
//       &.fail {
//         color: #e0443b;
//       }
//       &.success {
//         color: #1aad19;
//       }
//     }
//   }
//   .button-group {
//     display: flex;
//     flex-direction: row;
//     height: 36px;
//     justify-content: space-around;
//     align-items: center;
//     margin-top: 36px;
//     .button {
//       border: 1px solid #868686;
//       border-radius: 5px;
//       padding: 0 30px;
//       height: 36px;
//       line-height: 36px;
//     }
//   }
// }
</style>