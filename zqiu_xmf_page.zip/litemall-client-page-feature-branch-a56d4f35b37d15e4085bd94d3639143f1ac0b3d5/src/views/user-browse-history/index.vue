<template>
    <HeaderLayout v-infinite-scroll="loadMore" infinite-scroll-immediate-check="false" infinite-scroll-disabled="infiniteDisabled" infinite-scroll-distance="80">
        <Xheader class="header-fix" :title="$route.meta.title">
            <icon name="delete" slot="right" v-if="list.length > 0 && !isClear" @click.native="isClear = true" scale="2"></icon>
            <span slot="right" v-if="list.length > 0 && isClear" class="clear-btn" @click="isClear = false">完成</span>
        </Xheader>

        <div class="product-list clearfix">
            <GoodsItem style="top: 0" v-for="(item,index) in list" :key="index" :disabled="isClear" @click.native="check(item)" :item="{name:item.name,picUrl:item.picUrl,retailPrice:item.retailPrice,brief:item.brief,id:item.goodsId}">
                <CheckIcon slot="actionIcon" v-if="isClear" class="check-icon" v-model="item.checkd"></CheckIcon>
                <!-- <CheckIcon slot="actionIcon" v-if="isClear" class="check-icon" :value.sync="item.checkd"></CheckIcon> -->
              </GoodsItem>
        </div>

        <div style="min-height:80px; overflow: hidden;">
            <LoadMore v-if="status=='请求中'" tip="正在加载" :showLoading="true"></LoadMore>
            <LoadMore v-if="status=='没有更多'" tip="没有更多了" :showLoading="false"></LoadMore>
            <LoadMore v-if="status=='请求失败'" tip="加载失败，点我重试" :showLoading="false" @click.native="loadMore"></LoadMore>
            <Nodata v-if="status=='暂无数据'" :imgurl="require('@src/assets/img/bg_empty_data.png')" content='暂无相关记录'></Nodata>
        </div>

        <div class="clear-btns" v-if="isClear">
            <div class="checkall-btn" @click="clickAllCheck">
                <CheckIcon slot="actionIcon" class="check-icon" v-model="isAllCheckd"></CheckIcon>
                <span>全选</span>
            </div>
            <Xbutton recta type="warn" class="del-btn weui-btn_inline" :disabled="btnDisabled" @click.native="deleteCheck">删除选中</Xbutton>
        </div>
    </HeaderLayout>
</template>

<script>
import HeaderLayout from "@src/layouts/headerLayout.vue"
import Xheader from "@src/components/base/x-header"
import Nodata from "@src/components/base/no-data"
import GoodsItem from '@src/components/base/goodsItem/index.vue'
import CheckIcon from '@src/components/base/check-icon'
import Xbutton from "@src/components/base/x-button"
import LoadMore from "@src/components/base/load-more"
import { getUserBrowseHistory, userBrowseClearAll, userBrowseDelete } from '@src/apis/user.js'
import routeLeaveByisRoutePush from '@src/mixins/routeLeaveByisRoutePush.js'
import infiniteScroll from '@src/directives/vue-infinite-scroll'
export default {
    directives: { infiniteScroll },
    components: { HeaderLayout, Xheader, Nodata, GoodsItem, CheckIcon, Xbutton, LoadMore },
    mixins: [routeLeaveByisRoutePush],
    async beforeRouteEnter(to, from, next) {
        if (['product-detail'].indexOf(from.name) !== -1 && from.meta.isRouterPush) {
            next();
        } else {
            let query = { page: 1, size: 10 };
            let data = await getUserBrowseHistory(query);
            next(vm => {
                vm.list = [];
                vm.query = query;
                vm.isClear = false;
                vm.setData(data, query)
            })
        }
    },
    computed: {
        btnDisabled() {
            return this.list.find(item => item.checkd === true) ? false : true;
        },
        isAllCheckd() {
            return this.list.find(item => item.checkd === false) ? false : true;
        },
        infiniteDisabled() {
            return this.status == '请求中' || this.status == '没有更多' || this.status == '暂无数据' || this.status == '请求失败';
        }
    },
    data() {
        return {
            status: "",
            // 查询条件
            query: {},
            // 商品列表
            list: [],
            // 选中的id数组，发送到后台
            checkdList: [],
            // 是否删除状态
            isClear: false
        }
    },
    methods: {
        async loadMore() {
            this.status = "请求中";
            try {
                let data = await getUserBrowseHistory(this.query);
                this.setData(data);
            } catch (error) {
                this.status = "请求失败";
            }
        },
        setData(data) {
            data.footprintList = data.footprintList.map(item => {
                item.checkd = false;
                return item;
            })
            this.list = this.list.concat(data.footprintList);

            // 是否有更多数据
            if (this.list.length === 0) {
                this.status = "暂无数据";
            } else if (this.query.page >= data.totalPages) {
                this.status = "没有更多";
            } else {
                this.status = "请求更多";
                this.query.page++;
            }
        },

        // 删除选中国
        async deleteCheck() {
            let arr = new Array();
            this.list.filter(item => {
                if (item.checkd) return arr.push(item.id);
            })
            if (arr.length === 0) return;
            await userBrowseDelete(arr);
            window.location.reload();
        },

        // 选中
        check(item) {
            if (this.isClear) {
                item.checkd = !item.checkd;
                item = item;
            }
        },

        // 点击全选
        clickAllCheck() {
            if (this.isAllCheckd) {
                this.list.forEach((item, index, array) => {
                    item.checkd = false;
                });
            } else {
                this.list.forEach((item, index, array) => {
                    item.checkd = true;
                });
            }
        }
    }
}
</script>

<style lang="less" scoped>
.clear-btn {
  padding: 10px 0;
}
.check-icon {
  display: flex;
}
.clear-btns {
  position: fixed;
  bottom: 0;
  left: 0;
  width: 100%;
  background: #fff;
  border-top: 1px solid #eee;
  display: flex;
  .checkall-btn {
    width: 114px;
    display: flex;
    align-items: center;
    padding-left: 10px;
    span {
      margin: 0 10px;
    }
  }
  .del-btn {
    margin-right: 0;
  }
}
</style>
