// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import store from './vuex'
import config from './config.js'
import Vant from 'vant';
import 'vant/lib/index.css';
import RSA from '@src/utils/RSA.js'

import "@src/assets/less/reset.less"
import "@src/assets/less/common.less"
import "@src/assets/icomoon/style.css"
import "@src/plugins/vue-svg-icon.js"
import "@src/plugins/fastclick.js"
import "@src/plugins/fontSize.js"
import "@src/plugins/toast-mobile.js"
import "@src/plugins/vue-lazyload.js"
import "@src/plugins/vue-alert-view.js"
import "@src/middleware/routerController.js"
import {
    Image,
    Lazyload,
    Toast
} from 'vant';
Vue.use(Image);
Vue.use(Lazyload);
Vue.use(Toast);
Vue.prototype.APP = config
Vue.config.productionTip = false
Vue.use(Vant);
import VConsole from 'vconsole'
if (process.env.NODE_ENV === 'development') {
    new VConsole()
}
let app = new Vue({
    router,
    store,
    components: {
        App
    },
    template: '<App/>'
})



window.mountApp = () => {
    app.$mount('#app')
}
if (process.env.NODE_ENV === 'production') {
    window.onload = function () {
        window.mountApp()
    }
} else {
    window.mountApp()
}
