import { isWeixin } from '@src/utils/wx.js'
export default {
    winH: window.innerHeight,
    winW: window.innerWidth,
    isWeixin: isWeixin()
}