## reddot

> 使用的元素`display`需要为 `inline-block` 

- vux-reddot 普通红点
- vux-reddot-s 比普通更小的红点