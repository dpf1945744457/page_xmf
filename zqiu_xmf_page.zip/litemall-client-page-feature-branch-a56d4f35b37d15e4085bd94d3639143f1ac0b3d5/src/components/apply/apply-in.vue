<template>
  <div class="">
    <Xheader class="">申请入驻</Xheader>
    <div class="t-info-message">商户信息</div>
    <Uinput label="商户名称" v-model.trim="params.merName" placeholder="请输入商户名称" maxLength="50"></Uinput>
    <Uinput label="结算银行名称" v-model.trim="params.settleBankName" placeholder="请输入结算银行名称" maxLength="30" :topLine="true"></Uinput>
    <Uinput label="结算银行账号" v-model.trim="params.settleBankAccount" placeholder="请输入结算银行账号" maxLength="30" type="number" :topLine="true"></Uinput>
    <Uinput label="结算账号户名" v-model.trim="params.settleAccountName" placeholder="请输入结算账号户名" maxLength="30" :topLine="true"></Uinput>
    <Uinput label="社会信用代码" v-model.trim="params.enunSocrCode" placeholder="请输入社会信用代码" maxLength="30" :topLine="true"></Uinput>

    <div class="t-info-message">用户信息</div>
    <Uinput label="用户名称" v-model.trim="params.userName" placeholder="请输入用户名称" maxLength="20"></Uinput>
    <Uinput label="用户密码" type="password" v-model.trim="params.userPwd" placeholder="请输入用户密码" maxLength="30" :topLine="true"></Uinput>
    <Uinput label="确认密码" type="password" v-model.trim="params.repassword" placeholder="请确认密码" maxLength="30" :topLine="true"></Uinput>
    <Uinput label="联系邮箱" v-model="params.merMail" placeholder="请输入联系邮箱" maxLength="30" :topLine="true"></Uinput>

    <Xbutton class="btn m-t-20" type="warn" @click.native="applyIn">申请入驻</Xbutton>
  </div>
</template>

<script>
  import Xheader from "@src/components/base/x-header"
  import Uinput from "@src/components/base/u-input"
  import Xbutton from "@src/components/base/x-button"
  import regExp from '@src/utils/regExp.js'

  import { apply } from '@src/apis/apply.js'
  export default {
    components: { Xheader, Uinput, Xbutton },
    name:'apply-in',
    data() {
      return {
        params: {
          merName:"",
          merMail:"",
          settleBankName:"",
          settleBankAccount:"",
          settleAccountName:"",
          enunSocrCode:"",
          userName: "",
          userPwd: "",
          repassword: "",
        }
      }
    },
    methods: {

      applyIn() {

        if (this.params.merName.length === 0) {
          this.$toast("商户名称不能为空");
          return false;
        }
        if (this.params.settleBankName.length === 0) {
          this.$toast("结算银行名称不能为空");
          return false;
        }
        if (this.params.settleBankAccount.length === 0) {
          this.$toast("结算银行账户不能为空");
          return false;
        }
        if (this.params.settleAccountName.length === 0) {
          this.$toast("结算账号户名不能为空");
          return false;
        }

        if (this.params.enunSocrCode.length === 0) {
          this.$toast("信用代码不能为空");
          return false;
        }


        // 用户名去除空格 简单校验不为空
        this.params.userName = this.params.userName.replace(/\s+/g, "");
        if (this.params.userName.length === 0) {
          this.$toast("用户名不能为空");
          return false;
        }

        if (!regExp.normal.reg.test(this.params.userName)) {
          this.$toast(`用户名${regExp.normal.errMsg}`);
          return false;
        }

        if (this.params.userPwd.length < 6) {
          this.$toast("请输入至少6位数的密码");
          return false;
        }

        if (!regExp.normal.reg.test(this.params.userPwd)) {
          this.$toast(`密码${regExp.normal.errMsg}`);
          return false;
        }

        if (!this.params.repassword) {
          this.$toast("再次输入密码");
          return false;
        }

        if (this.params.userPwd !== this.params.repassword) {
          this.$toast("两次输入的密码不一致");
          return false;
        }


        if (this.params.merMail.length === 0) {
          this.$toast("联系邮箱不能为空");
          return false;
        }


        var reg = new RegExp("^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$");
        if(!reg.test(this.params.merMail)){
          this.$toast("邮箱格式不正确");
          return false;
        }

        apply({
          merName: this.params.merName,
          merMail: this.params.merMail,
          settleBankName: this.params.settleBankName,
          settleBankAccount: this.params.settleBankAccount,
          settleAccountName: this.params.settleAccountName,
          enunSocrCode: this.params.enunSocrCode,
          userName: this.params.userName,
          userPwd: this.params.userPwd,
        }).then(res => {
          var _self = this;

          if(res.errno == 0){
            this.$toast('申请入驻成功');
            setTimeout(function () {
              _self.$router.push({ path: "/" });
            },2000)
          }else {
            this.$toast(res.errmsg);
          }
        }).catch(err => {
        	
        });

      }
    }
  }
</script>

<style lang="less" scoped>
  input{
    -webkit-tap-highlight-color: rgba(0,0,0,0);
    height: 40px;
    background: cornsilk;
    font-size: 14px !important;
  }
  .header {
    background: #f23030;
    color: #fff;

    a {
      color: #fff !important;
    }
  }

  .btn {
    width: 95%;
    border: none;
  }
  .t-info-message{
    position: relative;
    margin-left: 3%;
    line-height: 2rem;
    color: black;
  }
  .control{
    font-size: 14px !important;
  }
</style>
