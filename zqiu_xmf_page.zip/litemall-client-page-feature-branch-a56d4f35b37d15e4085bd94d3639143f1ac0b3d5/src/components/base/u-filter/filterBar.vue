<template>
    <div class="filterbar" :style="{'top': top + 'px'}">
        <div class="container top-line bottom-line">
            <div class="row">
                <div class="col" :class="{'selected1': index == selectedIndexMenu}" v-for="(barMenu, index) in barMenus" :key="index" @click="clickBarMenu(barMenu,index)">
                    <span>{{barMenu.barMenuValue.name}}</span>
                    <!-- barMenu icon -->
                    <span :class="index == selectedIndexMenu ? barMenu.selectIcon : barMenu.defaultIcon"></span>
                </div>
            </div>
        </div>
        <!-- pop 容器 -->
        <keep-alive>
            <component :is="currPopComponent" @change="change" v-model="defaultBarMenuValue" :data="barMenu"></component>
        </keep-alive>

    </div>
</template>

<script>
import RadioList from './pop/radio-list.vue'
import Checkbox from './pop/checkbox.vue'

export default {
    components: { RadioList, Checkbox },
    props: {
        top: String,
    },
    data() {
        return {
            // 当前选中的menu索引
            selectedIndexMenu: 0,
            // 当前显示的pop组件
            currPopComponent: "",
            // 当前显示的pop组件内数据
            barMenu: [],
            // 当前显示的pop组件默认值
            defaultBarMenuValue: {},

            barMenus: [
                {
                    popComponent: "RadioList",
                    barMenuValue: {
                        name: '最新上架',
                        icon: 'icon-success_black',
                        value: '一级1'
                    },
                    data: [
                        {
                            name: '综合',
                            icon: 'icon-success_black',
                            value: '一级1',
                        }, {
                            name: '最新上架',
                            icon: 'icon-success_black',
                            value: '一级1',
                        }, {
                            name: '价格最低',
                            icon: 'icon-success_black',
                            value: '一级1',
                        }, {
                            name: '价格最高',
                            icon: 'icon-success_black',
                            value: '一级1',
                        }, {
                            name: '评价最多',
                            icon: 'icon-success_black',
                            value: '一级1',
                        }
                    ]
                },
                {
                    popComponent: "Checkbox",
                    barMenuValue: {
                        name: "分类",
                        value: true,
                    },
                    data: [{
                        name: '全部',
                        value: '全部',
                        list: [{
                            name: "全部",
                            value: 'all'
                        }]
                    }, {
                        name: '中餐馆',
                        value: '中餐馆',
                        list: [{
                            name: '全部',
                            value: 'all'
                        }, {
                            name: '火锅',
                            value: 'hot pot'
                        }, {
                            name: '川菜',
                            value: 'Sichuan cuisine'
                        }]
                    }, {
                        name: '西餐馆',
                        value: '西餐管',
                        list: [{
                            name: '全部',
                            value: 'all'
                        }, {
                            name: '披萨',
                            value: 'pizza'
                        }, {
                            name: '牛排',
                            value: 'steak'
                        }]
                    }]
                },
                {
                    popComponent: "RadioList",
                    barMenuValue: {
                        name: '京东物流',
                        icon: 'icon-success_black',
                        value: '一级1',
                    },
                    data: [
                        {
                            name: '京东物流',
                            icon: 'icon-success_black',
                            value: '一级1',
                        }, {
                            name: '品牌',
                            icon: 'icon-success_black',
                            value: '一级1',
                        }, {
                            name: '材质',
                            icon: 'icon-success_black',
                            value: '一级1',
                        }
                    ]
                },
                {
                    popComponent: "",
                    barMenuValue: {
                        name: "筛选"
                    },
                },
            ]
        }
    },
    methods: {
        clickBarMenu(barMenu, index) {
            // 如果点击的menu有pop组件名称 则渲染该组件
            this.hasOpen(barMenu.popComponent);

            if (this.currPopComponent) {
                this.defaultBarMenuValue = barMenu.barMenuValue;
                this.barMenu = barMenu;
            }
        },

        // 渲染pop 或 移除pop组件
        hasOpen(popComponent) {
            this.currPopComponent = popComponent;
        },

        // 当前pop触发变化时会通过事件通知方式,传递pop组件名称 popComponent和vaue
        change(barMenu, valueObject) {
            this.hasOpen("");
            // console.log(menuKey, valueObject);
            // barMenu.value = valueObject;
        },
    }
}
</script>

<style lang="less" scoped>
@import "../../styles/weui/base/mixin/setOnepx.less";
.filterbar {
  width: 100%;
  background: #fff;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 1;
  .top-line {
    &::before {
      .setTopLine();
    }
  }

  .bottom-line {
    &::after {
      .setBottomLine();
    }
  }

  .container {
    width: 100%;
    position: relative;
    .row {
      display: flex;
      display: -ms-flexbox;
      display: -moz-box;
      display: -webkit-box;
      display: -webkit-flex;
      flex-direction: row;
      -webkit-flex-direction: row;
      justify-content: space-around;
      -webkit-box-pack: space-around;
      -moz-box-pack: space-around;
      -ms-flex-pack: space-around;
      width: 100%;
      height: 40px;
      margin: 0 auto;
      line-height: 40px;
      .selected {
        color: red;
      }
      .col {
        flex: 1;
        text-align: center;
        span {
          vertical-align: middle;
        }
      }
    }
  }
}
</style>
