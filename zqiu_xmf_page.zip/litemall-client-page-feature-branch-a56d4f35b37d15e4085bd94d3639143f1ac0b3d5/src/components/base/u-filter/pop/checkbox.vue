<template>
    <div class="checkbox">
        <div class="container">
            <div class="left">
                <Ucell :title="item.name" :class="{selected:value.name == item.name}" @click.native="clickLeft(item,index)" :borderLine="true" v-for="(item,index) in data.data" :key="index"></Ucell>
            </div>
            <div class="right">
                <Ucell :title="item.name" :class="{selected:value.name == item.name}" @click.native="clickItem(item,index)" :borderLine="true" v-for="(item,index) in list" :key="index"></Ucell>
            </div>
        </div>
    </div>
</template>

<script>
import Ucell from '@src/components/base/u-cell'
export default {
    props: {
        data: {
            type: Object,
            default: () => {
                return {};
            }
        },
        value: {
            type: Object,
            default: () => {
                return {};
            }
        },
    },
    data() {
        return {
            list: []
        }
    },
    components: { Ucell },
    methods: {
        clickLeft(item, index) {
            this.list = item.list;
        }
    }
}
</script>

<style lang="less" scoped>
.checkbox {
  .container {
    display: flex;

    .left,
    .right {
      flex: 1;
    }
  }
}
</style>
