<template>
    <div class="comment-item">
        <Ucell class="comment-header" :title="item.nickname | nickname">
            <div class="header" slot="icon">
                <img v-lazy="item.avatar" alt="">
            </div>
            <span slot="desc" style="font-size: 12px;" class="addTime">{{item.addTime.split(" ")[0]}}</span>
        </Ucell>
        <div class="comment-content p-15 p-t-0 p-b-5">
            {{item.content}}
        </div>
        <div class="comment-goods p-15 p-t-0 p-b-5 font-12">商品型号：{{item.specifications.join(",")}}</div>
        <ul class="comment-pic clearfix p-10 p-b-5">
            <li v-for="(pic,i) in item.picList" :key="i" @click="$emit('clickImg',$event,i,item.picList)">
                <img class="previewer-demo-img" v-lazy="pic.src" alt="">
            </li>
        </ul>
    </div>
</template>

<script>
import Ucell from '@src/components/base/u-cell'
export default {
    components: { Ucell },
    props: ['item'],
    filters: {
        nickname(val) {
            val = `${val.slice(0, 1)}***${val.slice(val.length - 1, val.length)}`;
            return val;
        }
    },

}
</script>

<style lang="less" scoped>
.comment-item {
  padding: 5px 0px 20px;
  box-sizing: border-box;
  border-bottom: 1px solid #eee;
  background: #fff;
}

.comment-header {
  color: #333;
  display: flex;
  align-items: center;
  .header {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    overflow: hidden;
    margin-right: 10px;
    img {
      width: 100%;
      height: 100%;
    }
  }
}

.comment-pic {
  // display: flex;
  li {
    float: left;
    display: block;
    background: #fafafa;
    margin-bottom: 6px;
    width: 32%;
    height: 5.6rem;
    margin-right: 1.3%;
    img {
      width: 100%;
      height: 100%;
    }
  }
}
</style>
