<template>
    <div class="filterbar" :style="{'top': top + 'px'}">
        <div class="container" :class="{'top-line':topLine,'bottom-line':bottomLine}">
            <div class="row">
                <div class="col" :class="{'selected': index == selectedIndexMenu}" v-for="(barMenu, index) in barMenus" :key="index" @click="handleShowDialog(barMenu, index)">
                    <span>{{barMenu.name}}</span>
                    <span :class="index == selectedIndexMenu ? barMenu.selectIcon : barMenu.defaultIcon"></span>
                </div>
            </div>
            <filter-bar-pop :filterTop="top" :show-dialog="isShow" :hasTabHeader="hasTabHeader" :menu="selectedMenu" @changeTab="handleChangeTab" @changeMainItem="handleChangeMainItem" @changeSelect="changeSelect" @closeDialog="handleCloseDialog">
            </filter-bar-pop>
        </div>
    </div>
</template>
<script>
import FilterBarPop from './filterBarPop'

export default {
    props: {
        barMenus: {
            type: Array,
            required: true,
            validator: function (value) {
                //TODO:验证数据有效性
                return true;
            }
        },
        top: String,
        topLine: Boolean,
        bottomLine: Boolean
    },
    data() {
        return {
            // 是否显示Pop
            isShow: false,
            // 是否显示Pop header
            hasTabHeader: false,
            // 当前点击的menu对象
            selectedMenu: {},
            // 当前点击的menu索引值
            selectedIndexMenu: undefined
        }
    },
    methods: {
        handleShowDialog(menu, index) {
            if (menu.tabs instanceof Array) {
                this.isShow = true;
                this.selectedMenu = menu;
                this.selectedIndexMenu = index;
                if (menu.showTabHeader) {
                    this.hasTabHeader = true;
                } else {
                    this.hasTabHeader = false;
                }
            }
            let _menu = JSON.parse(JSON.stringify(menu));
            delete _menu.tabs;
            this.$emit('showDialog', _menu);
        },
        handleChangeTab(tab) {
            this.$emit('changeTab', tab.index);
        },
        handleChangeMainItem(mainItem) {
            let _mainItem = JSON.parse(JSON.stringify(mainItem));
            this.$emit('changeMainItem', _mainItem);
        },
        handleCloseDialog() {
            this.isShow = false;
            this.selectedIndexMenu = -1;
            this.$emit('closeDialog');
        },
        changeSelect() {
            var selectData = [];
            this.barMenus.forEach(function (barMenu, index, arr) {
                let _selectBarData = {};
                
                _selectBarData.name = barMenu.name;
                _selectBarData.value = barMenu.value;
                _selectBarData.tab = {};
                let tab = barMenu.tabs[barMenu.selectIndex];
                
                _selectBarData.tab.name = tab.name;
                _selectBarData.tab.value = tab.value;
                let mainItem = tab.detailList[tab.selectIndex];
                _selectBarData.tab.mainItem = {}
                       
                _selectBarData.tab.mainItem.name = mainItem.name;
                _selectBarData.tab.mainItem.value = mainItem.vaule;
                let subItem = false;
                if (mainItem.list) {
                    subItem = mainItem.list[mainItem.selectIndex];
                    _selectBarData.tab.mainItem.subItem = {};
                                       
                    _selectBarData.tab.mainItem.subItem.name = subItem.name;
                    _selectBarData.tab.mainItem.subItem.value = subItem.value;
                } else {
                    _selectBarData.tab.mainItem.subItem = subItem;
                }
                selectData.push(_selectBarData);
            });
            this.$emit('changeSelect', selectData);
        }
    },
    components: {
        'filter-bar-pop': FilterBarPop
    }
}
</script>
<style lang="less" scoped>
@import "../../styles/weui/base/mixin/setOnepx.less";
.filterbar {
  width: 100%;
  background: #fff;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 1;
  .top-line {
    &::before {
      .setTopLine();
    }
  }

  .bottom-line {
    &::after {
      .setBottomLine();
    }
  }

  .container {
    width: 100%;
    // outline: 1px solid #dbdcde;
    position: relative;
    .row {
      display: flex;
      display: -ms-flexbox;
      display: -moz-box;
      display: -webkit-box;
      display: -webkit-flex;
      flex-direction: row;
      -webkit-flex-direction: row;
      justify-content: space-around;
      -webkit-box-pack: space-around;
      -moz-box-pack: space-around;
      -ms-flex-pack: space-around;
      width: 100%;
      height: 40px;
      margin: 0 auto;
      line-height: 40px;
      .selected {
        color: red;
      }
      .col {
        flex: 1;
        text-align: center;
        span {
          vertical-align: middle;
        }
      }
    }
  }
}
</style>