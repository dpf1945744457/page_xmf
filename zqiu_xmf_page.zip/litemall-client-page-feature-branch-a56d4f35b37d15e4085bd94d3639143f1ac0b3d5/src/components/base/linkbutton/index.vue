<template>
  <div class="side-distance linkbutton-bar">
    <div class="linkbutton">
      <div class="title">
        {{lable}}
      </div>
      <div class="content">
        <span :style="constyle">{{content}}</span>
        <icon v-if="icon" scale="2" name="linkright"></icon>
      </div>
    </div>
  </div>

</template>
<script>
export default {
  props: {
    lable: String,
    content: String,
    constyle: Object,
    icon: Boolean
  },
  components: {},
  head() { return {} },
  asyncData(context) { },
  data() { return {} },
  fetch() { },
  methods: {}
}
</script>
<style lang='less' scoped>
.linkbutton-bar {
  background: #fff;
  .linkbutton {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    background: #fff;
    height: 40px;
    .title {
      white-space: nowrap;
      color: #222;
    }
    .content {
      white-space: nowrap;
      display: flex;
      flex-direction: row;
      justify-content: center;
    }
  }
}
</style>