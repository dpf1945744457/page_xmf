<template>
  <div class="x-cell" :class="{'border-1px':borderLine,'top-line':topLine}">
    <slot name="icon"></slot>
    <div class="title">{{title}}</div>
    <div class="desc" :class="{'mr-l':isLink}">
      <span v-if="title=='免税袋条码'"> 

        <p   v-for="list in desc" :key="list">{{list}}</p>
    </span>
      <span v-else>{{desc}}</span>
    </div>
    <slot name="desc"></slot>
    <img v-if="isLink" class="link-icon" src="@src/assets/img/icon/user_right.png" alt />
  </div>
</template>

<script>
export default {
  props: ["title", "desc", "isLink", "borderLine", "topLine", "to"]
};
</script>

<style lang="less" scoped>
@import "../../styles/weui/base/mixin/setOnepx.less";
.x-cell {
  position: relative;
  display: flex;
  background-color: #fff;
  padding: 12px 3%;
  box-sizing: border-box;
  overflow: hidden;
  align-items: center;

  .title {
    flex: 1.2;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    //   font-size: 16px;
  }

  .desc {
    //   font-size: 24px;
    color: #aaa;
    //   flex: 0.8;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    text-align: right;
    /* display: table-cell;  */
    /* line-height: 30rpx;  */
    /* vertical-align:middle; */
  }

  .link-icon {
    width: 10px;
    height: 17px;
    margin-left: 3px;
  }

  .mr-l {
    margin-right: 20px;
  }
}
.border-1px {
  &::after {
    .setBottomLine();
  }
}

.top-line {
  &::before {
    .setTopLine();
  }
}
</style>
