import Swiper from './swiper.vue'
import SwiperItem from './swiper-item'

export {
  Swiper,
  SwiperItem
}
