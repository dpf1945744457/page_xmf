<template>
    <span v-if="loaded">{{curText}} {{days}}天{{hours}}时{{minutes}}分{{seconds}}秒</span>
</template>

<script>
export default {
    data() {
        return {
            curText: "",
            loaded: true,
            timer: 'true',
            iseTime: false,
            days: '',
            hours: '',
            minutes: '',
            seconds: ''
        };
    },
    props: {
        sTime: {
            type: Number,
            default: ''
        },
        eTime: {
            type: Number,
            default: ''
        },
        callback: {
            type: Function,
            default: ''
        }
    },
    mounted() {
        if (this.sTime > 0 && this.eTime > 0) {
            this.initializeClock(this.sTime);
            // this.curText = "即将开始";
        } else if (this.sTime == 0 && this.eTime > 0) {
            this.initializeClock(this.eTime);
            // this.curText = '距结束';
        } else {
        	
        }
    },

    methods: {
        initializeClock: function (n) {
            if (n < 1) return;
            this.getCountdownValues(n);//解决了延迟显示时间
            this.timer = setInterval(() => {
                // this.loaded = true;
                n--;
                this.getCountdownValues(n);
            }, 1000)
        },
        getCountdownValues: function (secondTimes) {
            const allSecondTimes = parseInt(secondTimes);
            
            let day = 0;
            let hour = 0;
            let min = 0;
            let second = 0;
            /* 总的秒数 */
            if (allSecondTimes > 60) {
                day = parseInt(parseInt(parseInt(allSecondTimes / 60) / 60) / 24);
                hour = parseInt(parseInt(allSecondTimes / 60) / 60) % 24;
                min = parseInt(allSecondTimes / 60);
                second = parseInt(allSecondTimes) % 60;

                if (min > 60) {
                    min = parseInt(allSecondTimes / 60) % 60;
                    hour = parseInt(parseInt(allSecondTimes / 60) / 60);
                    if (hour > 24) {
                        hour = parseInt(parseInt(allSecondTimes / 60) / 60) % 24;
                        day = parseInt(parseInt(parseInt(allSecondTimes / 60) / 60) / 24);
                    }
                }
            } else {
                day = 0;
                hour = 0;
                min = 0;
                second = parseInt(allSecondTimes) % 60;
                if (allSecondTimes <= 0) {
                    clearInterval(this.timer);
                    this._callback();
                }
            }
            this.days = this.setNumberTen(day);
            this.hours = this.setNumberTen(hour);
            this.minutes = this.setNumberTen(min);
            this.seconds = this.setNumberTen(second);
            
        },
        setNumberTen(n) {
            let m = n;
            if (n < 10) {
                m = '0' + n;
            } else {
                m = n;
            }
            return m
        },
        _callback() {
            if (this.callback && this.callback instanceof Function) {
                this.callback(...this);
                // this.initializeClock(this.eTime);
                // this.curText = '距结束';
            }
        }
    },
    destroyed() {
        clearInterval(this.timer);
    }
};
</script>