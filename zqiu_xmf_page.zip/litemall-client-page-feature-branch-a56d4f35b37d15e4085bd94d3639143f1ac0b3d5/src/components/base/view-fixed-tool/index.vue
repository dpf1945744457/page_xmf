<template>
    <div class="view-fixed-tool" :style="`bottom:${bottom}px`">
        <div class="tool" @click="$router.push('/cart')" v-show="showCartBar">
            <icon name="cart-1" scale="2.5"></icon>
            <Badge class="badge" :text="goodscount"></Badge>
        </div>
        <div class="tool" v-if="scrollTop>500" @click="toScrollTop">
            <icon name="return-top" scale="3"></icon>
        </div>
    </div>
</template>

<script>

import { mapState, mapActions, mapGetters } from "vuex";
import Badge from '@src/components/base/badge'
export default {
    props: ["showCartBar", "goodscount", "bottom"],
    data() {
        return {
            scrollTop: 0
        }
    },
    components: { Badge },
    mounted() {
        window.addEventListener("scroll", this.showReturnTopBar);
    },
    destroyed() {
        window.removeEventListener("scroll", this.showReturnTopBar);
    },
    activated() {
        window.addEventListener("scroll", this.showReturnTopBar);
    },
    deactivated() {
        window.removeEventListener("scroll", this.showReturnTopBar);
    },
    methods: {
        toScrollTop() {
            document.body.scrollTop = 0
            document.documentElement.scrollTop = 0
        },
        showReturnTopBar() {
            let scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
            this.scrollTop = scrollTop;
        }
    },

}
</script>

<style lang="less" scoped>
.view-fixed-tool {
  position: fixed;
  bottom: 20px;
  right: 45px;

  .tool {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    margin: 5px 0;
    background: rgba(255, 255, 255, 0.541);
    border: 1px solid #eee;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;

    .badge {
      position: absolute;
      top: 2px;
      right: -2px;
    }
  }
}
</style>
