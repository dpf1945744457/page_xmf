<template>
    <div class="page-loading" v-show="show">
        <img src="./loading.gif" alt="">
        <!-- <icon name="loading" scale="5" fill="#FF6700"></icon> -->
    </div>
</template>

<script>
let timer = null;
export default {
    props: ["showLoading"],
    data() {
        return {
            show: false
        }
    },
    watch: {
        showLoading(val) {
            if (val) {
                this.open();
            } else {
                this.close();
            }
        }
    },
    methods: {
        open() {
            timer = setTimeout(() => {
                this.show = true;
            }, 1000);
        },
        close() {
            window.clearTimeout(timer);
            this.show = false;
        }
    }
}
</script>

<style lang="less" scoped>
.page-loading {
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  top: 0;
  margin: auto;
  width: 250px;
  height: 250px;
  z-index: 99999;
  img {
    width: 100%;
  }
}
</style>
