<template>
  <div class="common-copyright">
    Copyright © 2018-2020 小蜜蜂跨境电商 版权所有
    <p>粤ICP备18160918号-1</p>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="less" scoped>
.common-copyright {
  background: #fff;
  text-align: center;
  color: #848689;
  font-size: 10px;
  padding: 20px 0;
}
</style>
