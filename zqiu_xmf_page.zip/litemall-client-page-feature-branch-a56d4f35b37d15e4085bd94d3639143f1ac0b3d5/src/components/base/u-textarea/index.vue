<template>
  <div class="form-group" :class="{'top-line':topLine,'bootom-line':bottomLine}">
    <dl>
      <dt>
        <span>{{label}}</span>
      </dt>
      <dd>
        <div class="form-control-box">
            <textarea name="" id="" 
                    :type="type" 
                    class="textarea-style"  
                    :class="{'textarea-style-height':inputVal && inputVal.length>0}"
                    v-model="inputVal" 
                    :placeholder="placeholder" 
                    :maxLength="maxLength" 
                    autocomplete="off">
            </textarea>
          <div class="form-right">
            <slot></slot>
          </div>
        </div>
      </dd>
    </dl>
  </div>
</template>

<script>
export default {
  props: {
    label: String,
    placeholder: String,
    maxLength: String,
    width: {
      type: String,
      default: "80%"
    },
    topLine: Boolean,
    bottomLine: Boolean,
    type: {
      type: String,
      default: "text"
    },
    value: String
  },
  data() {
    return {
      inputVal: ""
    }
  },
  watch: {
    value(val) {
      this.inputVal = val;
    },
    inputVal(val) {
      this.$emit("input", val);
    }
  },
  mounted() {
    if (this.value) {
      this.inputVal = this.value;
    }
  }
}
</script>

<style lang="less" scoped>
@import "../../styles/weui/base/mixin/setOnepx.less";
.form-group {
  background: #fff;
  position: relative;

  dl {
    width: 94%;
    margin: auto;
    overflow: hidden;
    position: relative;
    box-sizing: border-box;
    display: flex;
    padding-top: 15px;
    dt {
        flex: 0 1 4.5rem;
        height: 60px;
        float: left;
        color: #222;
    }
    dd {
      flex: 1;
      position: relative;
      height: 60px;
      display: flex;
      .form-control-box {
        padding-top: 1px;
        flex: 1;
        vertical-align: middle;
        textarea {
          color: #666;
          font-size: 0.7rem!important;
          vertical-align: middle;
          display: table-cell;
        }
        .form-right {
          min-width: 20%;
          display: inline-block;
          text-align: center;
          align-items: center;
        }
      }

      input {
        display: inline-block;
        border: none;
        padding: 0.5rem 0 0.5rem;
        line-height: 1.25rem;
        font-size: 0.7rem;
        color: #666;
        height: 1.25rem;
      }
    }
  }
}

.top-line {
  &::before {
    .setTopLine();
  }
}

.bootom-line {
  &::after {
    .setBottomLine();
  }
}
.textarea-style {
  flex: 1;
  display: inline-block;
  width: 100%;
  height: 70%;
  height: 60px;
}

.textarea-style-height {
    // line-height:20px !important;
}
</style>
