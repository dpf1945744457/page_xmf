import CitysPicker from './citys-picker.vue'
export default CitysPicker

window.citysPicker = CitysPicker
