<template>
    <div class="vux-popup-header" :class="showBottomBorder ? 'vux-1px-b' : ''">
        <div class="vux-popup-header-left" @click="$emit('on-click-left')">
            <slot name="left-text">{{ leftText }}</slot>
        </div>
        <div class="vux-popup-header-title">
            <slot name="title">{{ title }}</slot>
        </div>
        <div class="vux-popup-header-right" @click="$emit('on-click-right')">
            <slot name="right-text">{{ rightText }}</slot>
        </div>
    </div>
</template>

<script>
export default {
    name: 'popup-header',
    props: {
        leftText: String,
        rightText: String,
        title: String,
        showBottomBorder: {
            type: Boolean,
            default: true
        }
    }
}
</script>

<style lang="less">
@import "../../styles/1px.less";
@import "../../styles/variable.less";

.vux-popup-header {
  //   display: flex;
  position: relative;
  height: @popup-header-height;
  line-height: @popup-header-height;
  font-size: @popup-header-font-size;
  background-color: @popup-header-bg-color;
}
.vux-popup-header-title {
  //   flex: 1;
  margin: 0 88px;
  width: auto;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  text-align: center;
  color: @popup-header-title-text-color;
}
.vux-popup-header-left {
  //   flex: 0.1;
  position: absolute;
  top: 12px;
  display: block;
  font-size: 14px;
  line-height: 21px;
  padding-left: @popup-header-left-text-padding;
  color: @popup-header-left-text-color;
}
.vux-popup-header-right {
  //   flex: 0.1;
  position: absolute;
  top: 12px;
  right: 0;
  display: block;
  font-size: 14px;
  line-height: 21px;
  padding-right: @popup-header-right-text-padding;
  color: @popup-header-right-text-color;
}
.vux-popup-header.vux-1px-b:after {
  border-color: #d9d9d9;
}
</style>
