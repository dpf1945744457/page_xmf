<template>
    <div>
        <div class="no-data-box">
            <div class="img-box">
                <img :src="imgurl" alt="">
            </div>
            <p class="text-content">{{content}}</p>
            <router-link v-if="havebut" to="/category" class="no-data-btn bg-color">逛一逛</router-link>
        </div>
    </div>
</template>
<script>
export default {
    components: {},
    props: {
        content: String,
        imgurl: String,
        havebut: Boolean
    },
    head() { return {} },
    asyncData(context) { },
    data() { return {} },
    fetch() { },
    methods: {}
}
</script>
<style lang='less' scoped>
.no-data-box {
  //   position: absolute;
  text-align: center;
  //   top: 47px;
  //   bottom: 0;
  //   left: 0;
  //   right: 0;
  //   background: #fff;
  .img-box {
    margin: 0 auto;
    width: 100px;
    margin-top: 100px;
    img {
      width: 100%;
    }
  }
  .text-content {
    margin-top: 10px;
    margin-bottom: 20px;
  }
  .no-data-btn {
    display: block !important;
    width: 80px;
    height: 30px;
    margin: 0 auto;
    font-size: 13px;
    color: #fff !important;
    line-height: 30px;
    text-align: center;
    border-radius: 3px;
  }
}
</style>
