<template>
    <div></div>
</template>

<script>
import wx from "weixin-js-sdk"
import { getWxSign } from '@src/apis/public.js'
export default {
    props: ["autoReady"],
    data() {
        return {
            signData: {}
        }
    },
    mounted() {
        this.autoReady && this.getConfig();
    },
    methods: {
        async getConfig() {
            this.$emit("on-loading", true);
            try {
                if (!(this.signData.appId && this.signData.timestamp && this.signData.noncestr && this.signData.sign)) {
                    this.signData = await getWxSign({ url: window.location.href.split("#")[0] });
                }
                wx.config({
                    debug: false,
                    appId: this.signData.appId,
                    timestamp: this.signData.timestamp,
                    nonceStr: this.signData.noncestr,
                    signature: this.signData.sign,
                    jsApiList: ['onMenuShareTimeline', 'onMenuShareAppMessage', 'onMenuShareQQ', 'onMenuShareWeibo', 'onMenuShareQZone']
                });
                wx.ready(() => { this.$emit("on-ready") });
            } catch (error) { }
            this.$emit("on-loading", false);
        },

        // 收货地址
        openAddress(callBack) {
            wx.openAddress({
                success: function (data) {
                    // 用户成功拉出地址
                    if (data.errMsg == "openAddress:ok") {
                        callBack(data);
                    } else {
                        this.$toast(data.errMsg);
                    }
                },
                cancel: function () {
                    // 用户取消拉出地址
                }
            });
        }

    }
}
</script>

<style>
</style>
