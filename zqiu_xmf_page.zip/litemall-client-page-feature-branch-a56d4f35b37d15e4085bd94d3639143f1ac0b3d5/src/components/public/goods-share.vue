<template>
    <div class="share-box">
        <XMask v-model="mask" class="qr-mask" @once-visible="maskOnceVisible" :show-loading="!qrSrc">
            <img class="qr-code" :style="`width:85%`" v-if="qrSrc" :src="qrSrc" alt="二维码无法显示" />
        </XMask>
        <!-- <Popup v-model="mask" position="left" is-transparent>
            <img class="qr-code" :style="`width:85%`" v-if="qrSrc" :src="qrSrc" alt="二维码无法显示" />
        </Popup> -->
        <WxJssdk ref="WxJssdk" @on-ready="jssdkReady"></WxJssdk>
    </div>
</template>

<script>
import WxJssdk from '@src/components/public/wx-jssdk.vue'
import Popup from '@src/components/base/popup'
import XMask from '@src/components/base/x-mask'
import { mapState, mapActions, mapGetters } from "vuex";
import QRCode from 'qrcode';
let img = require("@src/assets/img/upload.png");
export default {
    components: { WxJssdk, XMask, Popup },
    computed: {
        ...mapState({
            info: state => state.productDetail.info
        })
    },
    data() {
        return {
            mask: false,
            qrSrc: ""
        }
    },
    methods: {
        clickShare() {
            this.mask = true;
            this.createGoodsQrcode(this.info);
            // this.$refs.WxJssdk.getConfig();
        },

        // 注册微信好友分享文案
        jssdkReady() {
        	
        },

        // 创建商品二维码
        async createGoodsQrcode(goods) {

            let headerBgColor = "#ff6800"; //header背景颜色
            let headerTextColor = "#fff";

            let canvas = document.createElement("canvas");
            let ctx = canvas.getContext("2d");
            let base64Url;
            var scale = 0.8;
            canvas.width = 500;
            canvas.height = 700;
            /* 填充背景色 */
            ctx.fillStyle = "#fff";
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            // /* 填充商品信息 */
            ctx.fillStyle = headerBgColor;
            ctx.fillRect(0, 0, canvas.width, canvas.height / 4);

            let _this = this;
			let textPrice = "售价:HK$"
            let code = new Image();
            let goodsImg = new Image();
            goodsImg.setAttribute("crossOrigin", 'Anonymous')
            goodsImg.onload = code.onload = function () {
				
                this.isLoaded = true;
                if (code.isLoaded && goodsImg.isLoaded) {
                    //绘制头像
                    ctx.drawImage(goodsImg, 20, (canvas.height / 4 - canvas.width / 4) / 2, canvas.width / 4, canvas.width / 4);

                    ctx.font = "normal normal normal 24px Arial";
                    ctx.fillStyle = headerTextColor;
                    // ctx.fillText(goods.name, 20 + canvas.width / 4, (canvas.height / 4 - canvas.width / 4) / 2 + 40);
                    writeTextOnCanvas(ctx, 30, 28, goods.name.length > 30 ? goods.name.slice(0, 30) + "..." : goods.name, canvas.width / 4 + 30, (canvas.height / 4 - canvas.width / 4) / 2 + 30);
                    ctx.font = "normal normal normal 30px Arial";
                    ctx.fillStyle = "yellow";
                    writeTextOnCanvas(ctx, 30, 20, textPrice + goods.retailPrice.toFixed(2), canvas.width / 4 + 30, 135);
                    // ctx.globalCompositeOperation = "destination-over";
                    // ctx.drawImage(background, 0, 0, oC.width, oC.height);
                    // document.getElementById("cc").innerHTML(canvas);
                    ctx.font = "normal normal normal 20px Arial";
                    ctx.fillStyle = "#ccc";
                    ctx.textAlign = "center";
                    writeTextOnCanvas(ctx, 30, 200, `扫一扫识别二维码查看商品详情`, canvas.width / 2, canvas.height - 30);


                    let codeW = canvas.width / 1.2;
                    ctx.drawImage(code, (canvas.width - codeW) / 2, 200, codeW, codeW);

                    base64Url = canvas.toDataURL();
                    _this.qrSrc = base64Url;

                }
            }
            var timeStamp = new Date().getTime();
            goodsImg.src = goods.picUrl+'?'+timeStamp;
            code.src = await QRCode.toDataURL(location.href, { width: 250, });

            //ctx_2d        getContext("2d") 对象  
            //lineheight    段落文本行高  
            //bytelength    设置单字节文字一行内的数量  
            //text          写入画面的段落文本  
            //startleft     开始绘制文本的 x 坐标位置（相对于画布）  
            //starttop      开始绘制文本的 y 坐标位置（相对于画布）  
            function writeTextOnCanvas(ctx_2d, lineheight, bytelength, text, startleft, starttop) {
                function getTrueLength(str) {//获取字符串的真实长度（字节长度）  
                    var len = str.length, truelen = 0;
                    for (var x = 0; x < len; x++) {
                        if (str.charCodeAt(x) > 128) {
                            truelen += 2;
                        } else {
                            truelen += 1;
                        }
                    }
                    return truelen;
                }
                function cutString(str, leng) {//按字节长度截取字符串，返回substr截取位置  
                    var len = str.length, tlen = len, nlen = 0;
                    for (var x = 0; x < len; x++) {
                        if (str.charCodeAt(x) > 128) {
                            if (nlen + 2 < leng) {
                                nlen += 2;
                            } else {
                                tlen = x;
                                break;
                            }
                        } else {
                            if (nlen + 1 < leng) {
                                nlen += 1;
                            } else {
                                tlen = x;
                                break;
                            }
                        }
                    }
                    return tlen;
                }
                for (var i = 1; getTrueLength(text) > 0; i++) {
                    var tl = cutString(text, bytelength);
                    ctx_2d.fillText(text.substr(0, tl).replace(/^\s+|\s+$/, ""), startleft, (i - 1) * lineheight + starttop);
                    text = text.substr(tl);
                }
            }

        },
        maskOnceVisible() {

        }
    }
}
</script>

<style lang="less" scoped>
.share-box {
}
</style>
