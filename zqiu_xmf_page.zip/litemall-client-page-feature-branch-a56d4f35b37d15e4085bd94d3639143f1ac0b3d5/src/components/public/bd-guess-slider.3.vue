<template>
    <div class="bd-guess-slider m-t-10" v-if="listTemp.length > 0">
        <Ucell title="猜你喜欢" :borderLine="true" :topLine="true"></Ucell>

        <div class="clearfix">
            <!-- 配置slider组件 -->
            <slider ref="slider" :options="options">
                <!-- 直接使用slideritem slot -->
                <slideritem class="m-slider-item" v-for="(Temp,i) in listTemp" :key="i">
                    <!-- <div v-for="(item,index) in Temp" @click.self="$router.push({ path: `/product/${item.goodsId}` })" style="font-size:12px;background:#fff; color:red; border-bottom:1px solid red;padding:10px 0;" :key="index">{{item.name}}</div> -->
                    <GoodsItem class="slider-goods-item" :isShowBrief="false" v-for="(item,index) in Temp" :key="index" :item='{name:item.name,picUrl:item.picUrl,retailPrice:item.retailPrice,brief:item.brief,id:item.goodsId}'></GoodsItem>
                </slideritem>
                <!-- 设置loading,可自定义 -->
                <!-- <div slot="loading">loading...</div> -->
            </slider>
        </div>
    </div>
</template>

<script>

import Ucell from '@src/components/base/u-cell'
import GoodsItem from '@src/components/base/goodsItem'
import { slider, slideritem } from 'vue-concise-slider'
import { getUserBrowseHistory } from '@src/apis/user.js'
import { mapState, mapActions, mapGetters } from "vuex"
export default {
    components: { Ucell, GoodsItem, slider, slideritem },
    computed: {
        ...mapGetters(["isLogin"]),
        listTemp: function () {
            let list = this.list;
            let arrTemp = [];
            let index = 0;
            let sectionCount = 6;
            for (var i = 0; i < list.length; i++) {
                index = parseInt(i / sectionCount);
                if (arrTemp.length <= index) {
                    arrTemp.push([]);
                }
                arrTemp[index].push(list[i]);
            }
            return arrTemp;
        }
    },
    data() {
        return {
            list: [],
            options: {
                // currentPage: 0,
                // thresholdDistance: 500,
                // thresholdTime: 100,
                // autoplay: 5000,
                // loop: true,
                // directi

                on: 'vertical',
                // loopedSlides: 1,
                // slidesToScroll: 1,
                // timingFunction: 'ease',
                // speed: 300
            }
        }
    },
    async mounted() {
        if (this.isLogin) {
            let data = await getUserBrowseHistory({ page: 1, size: 12 });
            this.list = data.footprintList;
        }
    },
    methods: {
        // Listener event
        slide(data) {
        	
        },
        onTap(data) {
        	
        },
        onInit(data) {
        	
        }
    }

}
</script>

<style lang="less" scoped>
.slider {
  float: left;
}
.m-slider-item {
  display: block;
}
.slider-goods-item {
  width: 33.3333% !important;
  padding: 1px !important;
}
.vux-swiper{
	height: 220px;
}
</style>
