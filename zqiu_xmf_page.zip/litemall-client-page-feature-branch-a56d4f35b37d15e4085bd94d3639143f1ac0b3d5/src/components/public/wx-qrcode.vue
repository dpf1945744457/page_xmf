<template>
    <XMask v-model="wxQrShow" class="qr-mask" @once-visible="maskOnceVisible" :show-loading="false">
        <img class="qr-code" :style="`width:${APP.winH / 4}px`" v-if="wxQrSrc" :src="wxQrSrc" alt="二维码无法显示" />
        <span>长按图片【识别二维码】关注公众号</span>
        <h3>你还可以</h3>
        <div class="text-cont">
            <p>1.打开微信，点击‘添加朋友’</p>
            <p>2.点击‘公众号’</p>
            <p>3.搜索公众号：小蜜蜂电商</p>
            <p>4.点击‘关注’，完成</p>
        </div>
    </XMask>
</template>

<script>
import XMask from '@src/components/base/x-mask';
import base from '@src/apis/base.js';
export default {
    components: { XMask },
    data() {
        return {
            wxQrSrc: '',
            wxQrShow: false
        };
    },
    methods: {
        open() {
            this.wxQrShow = true;
        },
        maskOnceVisible() {
            this.wxQrSrc = `${base.staticIp}/resources/wxQr.jpg`;
        }
    }
};
</script>

<style lang="less" scoped>
.qr-mask {
    color: #fff;
    //   font-size: 12px;
    span {
        padding: 15px;
        display: block;
        border-bottom: 1px solid #888;
    }
    img {
        width: 180px;
    }
    h3 {
        margin: 10px 0;
        font-size: 18px;
    }
    .text-cont {
        text-align: left;
        width: 70%;
        margin: 0 auto;
        background: #17171787;
        color: #fff;
        border-radius: 4px;
        padding: 10px 43px;
        line-height: 27px;
        border: 1px solid #888888;
    }
    /deep/ .box-content{
        position: absolute;
        bottom: 140px;
        left: 0;
        right: 0;
    }
    /deep/ .boxClose{
        position: absolute;
        bottom: 0px;
        left: 0;
        right: 0;
    }
}
</style>
