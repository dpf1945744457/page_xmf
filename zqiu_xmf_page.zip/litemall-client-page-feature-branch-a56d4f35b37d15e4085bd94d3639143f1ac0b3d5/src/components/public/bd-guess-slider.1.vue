<template>
    <div class="bd-guess-slider" v-if="listTemp.length > 0">
        <Ucell title="猜你喜欢" :borderLine="true" :topLine="true"></Ucell>
        <Swiper ref="swiper" :show-dots="false" @on-index-change="indexChange">
            <SwiperItem class="black" v-for="(Temp,i) in listTemp" :key="i">
                <GoodsItem ref="GoodsItem" class="slider-goods-item" :isShowBrief="false" v-for="(item,index) in Temp" :key="index" :item='{name:item.name,picUrl:item.picUrl,retailPrice:item.retailPrice,brief:item.brief,id:item.goodsId}'></GoodsItem>
            </SwiperItem>
            <ul slot="dots" class="dots clearfix">
                <li v-for="(Temp,i) in listTemp" :class="{active:i==swiperCurrent}" :key="i"></li>
            </ul>
        </Swiper>
    </div>
</template>

<script>

import Ucell from '@src/components/base/u-cell'
import GoodsItem from '@src/components/base/goodsItem'
import { Swiper, SwiperItem } from '@src/components/base/swiper'
import { getUserBrowseHistory } from '@src/apis/user.js'
import { mapState, mapActions, mapGetters } from "vuex"
export default {
    components: { Ucell, GoodsItem, Swiper, SwiperItem },
    computed: {
        ...mapGetters(["isLogin"]),
        listTemp: function () {
            let list = this.list;
            let arrTemp = [];
            let index = 0;
            let sectionCount = 3;
            for (var i = 0; i < list.length; i++) {
                index = parseInt(i / sectionCount);
                if (arrTemp.length <= index) {
                    arrTemp.push([]);
                }
                arrTemp[index].push(list[i]);
            }
            return arrTemp;
        }

    },
    data() {
        return {
            swiperH: 0,
            swiperCurrent: 0,
            list: []
        }
    },
    async mounted() {
        let _this =this;
        if (this.isLogin) {
            let data = await getUserBrowseHistory({ page: 1, size: 12 });
            this.list = data.footprintList;
            this.$nextTick(() => {
                setTimeout(() => {
//                  debugger
                    this.swiperH = this.$refs.GoodsItem[0].$el.clientHeight;
                    this.$refs.swiper.xheight = `${this.swiperH + 0}px`;
                }, 0);
            })
        }
    },
    methods: {
        indexChange(i) {
            this.swiperCurrent = i;
        }
    }

}
</script>

<style lang="less" scoped>
.bd-guess-slider {
  //   background: #fff;

  .dots {
    display: flex;
    justify-content: center;
    li {
      width: 10px;
      height: 3px;
      margin: 5px 2px;
      float: left;
      border-radius: 500px;
      background: #ccc;
    }

    .active {
      background: #ff9700;
    }
  }
}
.slider-goods-item {
  width: 33.3333% !important;
  padding: 1px !important;
}
.vux-swiper{
	height: 220px;
}
</style>
