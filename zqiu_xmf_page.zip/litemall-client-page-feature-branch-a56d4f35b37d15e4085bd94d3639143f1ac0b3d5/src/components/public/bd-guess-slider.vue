<template>
    <div class="bd-guess-slider">
        <Ucell title="人气推荐"></Ucell>
        <div class="box">
            <div class="scroll clearfix" :style="`width:${APP.winW/scale*list.length+30}px`">
                <GoodsItem class="slider-goods-item" :isShowBrief="false" :style="`width:${APP.winW/scale}px`" v-for="(item,index) in list" :key="index" :item='item'>
                    <!-- <span slot="actionIcon">新品</span> -->
                </GoodsItem>
                <div class="show-all slider-goods-item">
                    <span class="show-all-title">点击查看全部</span>
                </div>
            </div>
        </div>
    </div>
</template>

<script>

import Ucell from '@src/components/base/u-cell'
import GoodsItem from '@src/components/base/goodsItem'
export default {
    components: { Ucell, GoodsItem },
    data() {
        return {
            list: [],
            scale: 3.3

        }
    },
    computed: {
        listTemp: function () {
            let list = this.list;
            let arrTemp = [];
            let index = 0;
            let sectionCount = 3;
            for (var i = 0; i < list.length; i++) {
                index = parseInt(i / sectionCount);
                if (arrTemp.length <= index) {
                    arrTemp.push([]);
                }
                arrTemp[index].push(list[i]);
            }
            return arrTemp;
        }
    },
    mounted() {

        for (let index = 0; index < 10; index++) {
            let goods = { id: 1181062, name: "许留山菲律宾吕宋芒果干", brief: "", picUrl: "http://test19.qtopay.cn/wx/storage/fetch/n89mkecwd33jwy8hq0av.jpg", retailPrice: 42.00 };
            let i = 0;
            i++;
            goods.name = `${index}${goods.name}`
            this.list.push(goods)
        }
    },
    methods: {
    }

}
</script>

<style lang="less" scoped>
.box {
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
}
.scroll {
  position: relative;
  transition: all 0.3s ease 0s;
  transform: translate3d(0px, 0px, 0px);

  .show-all {
    position: absolute;
    right: 0;
    top: 0%;
    width: 30px;
    height: 100%;
    background-color: #ffffff;
    color: #666;
    font-size: 11px;
    padding: 8px;
    .show-all-title {
      position: absolute;
      right: 0;
      top: 50%;
      transform: translateY(-50%);
      margin: 0 5px;
      display: block;
    }
  }
}

.slider-goods-item {
  float: left;
  //   width: 33.3333% !important;
  padding: 1px !important;
  box-sizing: border-box;
}
</style>
