import Vue from 'vue'
import Router from 'vue-router'
const _import = require('./_import_' + process.env.NODE_ENV)
// import HelloWorld from '@src/views/index.vue'

Vue.use(Router)

import TabbarLayout from "@src/layouts/tabbar.vue"
import DefaultLayout from "@src/layouts/default.vue"
import ErrorPage from "@src/layouts/error.vue"

export default new Router({
    // mode: 'history', // require service support
    scrollBehavior: () => ({
        y: 0
    }),
    routes: [{
            path: '',
            component: TabbarLayout,
            redirect: 'index',
            children: [{
                    name: 'index',
                    path: 'index',
                    component: _import('index'),
                    meta: {
                        title: '首页',
                        keepAlive: true
                    }
                },
                {
                    name: 'category',
                    path: 'category',
                    component: _import('category'),
                    meta: {
                        title: '分类',
                        keepAlive: true
                    }
                },
                {
                    name: 'cart',
                    path: 'cart',
                    component: _import('cart'),
                    meta: {
                        title: '购物车'
                    }
                },
                {
                    name: 'user',
                    path: 'user',
                    component: _import('user'),
                    meta: {
                        title: '个人中心',
                        keepAlive: true,
                        requiresAuth: true
                    }
                },
            ]
        },

        // 用户模块

        {
            path: '',
            component: DefaultLayout,
            redirect: 'index',
            children: [{
                    name: 'login',
                    path: 'login',
                    component: _import('user/login'),
                    meta: {
                        title: '用户登录'
                    }
                },
                {
                    name: 'register',
                    path: 'register',
                    component: _import('user/register'),
                    meta: {
                        title: '找回密码'
                    }
                },
                {
                    name: 'find-password',
                    path: 'find-password',
                    component: _import('user/find-password'),
                    meta: {
                        title: '用户注册'
                    }
                }
            ]
        },

        //地址管理

        {
            path: '',
            component: DefaultLayout,
            redirect: 'index',
            children: [{
                    name: 'address',
                    path: 'address',
                    component: _import('address/index'),
                    meta: {
                        title: '收货地址',
                        requiresAuth: true
                    }
                },
                {
                    name: 'address-add',
                    path: 'address/:id',
                    component: _import('address/add'),
                    meta: {
                        title: '新增收货地址',
                        requiresAuth: true
                    }
                }
            ]
        },

        // 付款结果
        {
            path: '',
            component: DefaultLayout,
            redirect: 'index',
            children: [{
                name: 'payresult',
                path: 'payresult',
                component: _import('pay-result/index'),
                meta: {
                    title: '付款结果',
                    requiresAuth: true
                }
            }]
        },

        //订单管理
        {
            path: '',
            component: DefaultLayout,
            redirect: 'index',
            children: [{
                    name: 'order',
                    path: 'order',
                    component: _import('order/index'),
                    meta: {
                        title: '我的订单',
                        requiresAuth: true,
                        keepAlive: true
                    }
                },
                {
                    name: 'order-id',
                    path: 'order/:id',
                    component: _import('order/detail'),
                    meta: {
                        title: '订单详情',
                        requiresAuth: true
                    }
                }
            ]
        },

        // 购物车下单
        {
            path: '',
            component: DefaultLayout,
            redirect: 'index',
            children: [{
                name: 'cartConfirm',
                path: 'cart/confirm',
                component: _import('cart/order-confirm'),
                meta: {
                    title: '订单确认',
                    requiresAuth: true
                }
            }]
        },

        //产品模块
        {
            path: '',
            component: DefaultLayout,
            redirect: 'index',
            children: [{
                    name: 'product',
                    path: 'product',
                    component: _import('product/product-list'),
                    meta: {
                        title: '商品列表',
                        keepAlive: true
                    }
                },
                {
                    name: 'product-detail',
                    path: 'product/:id',
                    component: _import('product/index'),
                    meta: {
                        title: '商品详情'
                    }
                }
            ]
        },

        {
            path: '*',
            component: DefaultLayout,
            redirect: 'error',
            children: [{
                name: 'error',
                path: 'error',
                component: ErrorPage,
                meta: {
                    title: '错误'
                }
            }, ]
        }
    ]
})
