import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

import ErrorPage from "@src/layouts/error.vue"
//const routerPush = Router.prototype.push
//Router.prototype.push = function push(location) {
//return routerPush.call(this, location).catch(error=> error)
//}
export default new Router({
    // mode: 'history', // require service support
    scrollBehavior: () => ({ y: 0 }),

    routes: [
        {
            name: 'index',
            path: '/',
            // component: require('@src/views/home/index.vue').default,
            component: require('@src/views/home/index2.vue').default,
            meta: { title: '首页', keepAlive: true }
        },
        {
            name: 'category',
            path: '/category',
            // 关闭类目页面
            // redirect: "/",
            component: () => import(/* webpackChunkName: "category" */ '@src/views/category/index.vue'),
            meta: { title: '分类', keepAlive: false }
        },
        {
            name: 'cart',
            path: '/cart',
            component: () => import(/* webpackChunkName: "cart" */ '@src/views/cart/index.vue'),
            meta: { title: '购物车', keepAlive: false, }
        },
        {
            name: 'user',
            path: '/user',
            component: () => import(/* webpackChunkName: "user" */ '@src/views/user/index.vue'),
            meta: { title: '个人中心', keepAlive: true, }
        },
        {
            name: 'iframes',
            path: '/iframes',
            component: () => import(/* webpackChunkName: "user" */ '@src/views/iframe/index.vue'),
            meta: { title: '小蜜蜂餐饮', keepAlive: true, }
        },
        {
          name: 'bind',
          path: '/bind',
          component: () => import(/* webpackChunkName: "bind" */ '@src/views/user-login/bind.vue'),
          meta: { title: '绑定'}
        },
        // {
        //     name: 'test',
        //     path: '/test',
        //     component: () => import(/* webpackChunkName: "test" */ '@src/views/test.vue'),
        //     meta: { title: '测试' }
        // },
        {
            name: 'search',
            path: '/search',
            component: () => import(/* webpackChunkName: "user-setting" */ '@src/views/search/index.vue'),
            meta: { title: '搜索', }
        },
        {
            name: 'search',
            path: '/searchList',
            component: () => import(/* webpackChunkName: "user-setting" */ '@src/views/search/search.vue'),
            meta: { title: '搜索结果',keepAlive: false }
        },
        {
            name: 'user-setting',
            path: '/user/setting',
            component: () => import(/* webpackChunkName: "user-setting" */ '@src/views/user-setting/index.vue'),
            meta: { title: '个人资料', requiresAuth: true, }
        },

        {
            name: 'danglood',
            path: '/danglood',
            component: () => import(/* webpackChunkName: "user-setting" */ '@src/views/Aboutus/danglood.vue'),
            meta: { title: '下载app' }
        },
        {
            name: 'About-us',
            path: '/Aboutus',
            component: () => import(/* webpackChunkName: "user-setting" */ '@src/views/Aboutus/index.vue'),
            meta: { title: '关于我们' }
        },
        {
            name: 'Privacy',
            path: '/Privacy',
            component: () => import(/* webpackChunkName: "user-setting" */ '@src/views/Aboutus/Privacy.vue'),
            meta: { title: '隐私协议' }
        },
        {
            name: 'Serviceagreement',
            path: '/Serviceagreement',
            component: () => import(/* webpackChunkName: "user-setting" */ '@src/views/Aboutus/Serviceagreement.vue'),
            meta: { title: '服务协议' }
        },
        
        
        {
            name: 'user-change',
            path: '/user/changePassword',
            component: () => import(/* webpackChunkName: "user-setting" */ '@src/views/user-login/changePassword.vue'),
            meta: { title: '修改密码', requiresAuth: true, }
        },
        {
            name: 'user-browse-history',
            path: '/user/browseHistory',
            component: () => import(/* webpackChunkName: "user-browse-history" */ '@src/views/user-browse-history/index.vue'),
            meta: { title: '我的足迹', requiresAuth: true, keepAlive: true }
        },
        {
            name: 'user-collect',
            path: '/user/collect',
            component: () => import(/* webpackChunkName: "user-collect" */ '@src/views/user-collect/index.vue'),
            meta: { title: '我的收藏', requiresAuth: true, keepAlive: true }
        },
//      {
//          name: 'user-login',
//          path: '/login',
//          component: () => import(/* webpackChunkName: "user-login" */ '@src/views/user-login/index.vue'),
//          meta: { title: '用户登录' }
//      },
        {
            name: 'user-login',
            path: '/phoneLogin',
            component: () => import(/* webpackChunkName: "user-login" */ '@src/views/user-login/phone_index.vue'),
            meta: { title: '手机号登录' }
        },
        {
            name: 'user-establish',
            path: '/establish',
            component: () => import(/* webpackChunkName: "user-login" */ '@src/views/user-login/establish.vue'),
            meta: { title: '用户注册' }
        },
        {
            name: 'user-forget',
            path: '/forgetIndex',
            component: () => import(/* webpackChunkName: "user-login" */ '@src/views/user-login/forget_index.vue'),
            meta: { title: '忘记密码' }
        },
        {
            name: 'user-modify',
            path: '/modify',
            component: () => import(/* webpackChunkName: "user-login" */ '@src/views/user-login/modify.vue'),
            meta: { title: '修改密码' }
        },
        {
            name: 'WX-password',
            path: '/WXpassword',
            component: () => import(/* webpackChunkName: "user-login" */ '@src/views/user-login/WXpassword.vue'),
            meta: { title: '设置密码' }
        },
        {
            name: 'user-register',
            path: '/register',
            component: () => import(/* webpackChunkName: "user-login" */ '@src/views/user-login/register.vue'),
            meta: { title: '用户注册' }
        },
        {
            name: 'bind-mobile',
            path: '/bind-mobile',
            component: () => import(/* webpackChunkName: "bind-mobile" */ '@src/views/bind-mobile/index.vue'),
            meta: { title: '绑定手机号' }
        },
        {
            name: 'user-address',
            path: '/address',
            component: () => import(/* webpackChunkName: "user-address" */ '@src/views/user-address/index.vue'),
            meta: { title: '地址管理', requiresAuth: true }
        },
        {
            name: 'user-address-add',
            path: '/address/:id',
            component: () => import(/* webpackChunkName: "user-address-add" */ '@src/views/user-address/add.vue'),
            meta: { title: '填写收货地址', requiresAuth: true }
        },
        {
            name: 'user-bank',
            path: '/bank',
            component: () => import(/* webpackChunkName: "user-address" */ '@src/views/user-bank/index.vue'),
            meta: { title: '我的钱包', requiresAuth: true }
        },
        {
            name: 'bank-add',
            path: '/addCard',
            component: () => import(/* webpackChunkName: "user-address" */ '@src/views/user-bank/bank-add.vue'),
            meta: { title: '添加银行卡', requiresAuth: true }
        },
        {
            name: 'bank-unbind',
            path: '/unbindCard',
            component: () => import(/* webpackChunkName: "user-address" */ '@src/views/user-bank/bank-unbind.vue'),
            meta: { title: '我的钱包', requiresAuth: true }
        },
        {
            name: 'bank-unbindCode',
            path: '/unbindCardCode',
            component: () => import(/* webpackChunkName: "user-address" */ '@src/views/user-bank/bank-unbindCode.vue'),
            meta: { title: '解绑银行卡', requiresAuth: true }
        },
        {
            name: 'bank-modifyCode',
            path: '/bankModifyCode',
            component: () => import(/* webpackChunkName: "user-address" */ '@src/views/user-bank/bank-modifyCode.vue'),
            meta: { title: '安全验证', requiresAuth: true }
        },
        {
            name: 'bank-password',
            path: '/bankSetCode',
            component: () => import(/* webpackChunkName: "user-address" */ '@src/views/user-bank/bank-password.vue'),
            meta: { title: '安全验证', requiresAuth: true }
        },
        {
            name: 'bank-checkCode',
            path: '/bankCheckCode',
            component: () => import(/* webpackChunkName: "user-address" */ '@src/views/user-bank/bank-checkCode.vue'),
            meta: { title: '安全验证', requiresAuth: true }
        },
        {
            name: 'bank-change',
            path: '/bankChange',
            component: () => import(/* webpackChunkName: "user-address" */ '@src/views/user-bank/bank-change.vue'),
            meta: { title: '忘记密码', requiresAuth: true }
        },
        {
            name: 'bank-forget',
            path: '/bankForget',
            component: () => import(/* webpackChunkName: "user-address" */ '@src/views/user-bank/bank-forget.vue'),
            meta: { title: '忘记密码', requiresAuth: true }
        },
        {
            name: 'bank-forget',
            path: '/bankCheckForget',
            component: () => import(/* webpackChunkName: "user-address" */ '@src/views/user-bank/bank-checkForget.vue'),
            meta: { title: '忘记密码', requiresAuth: true }
        },
        {
            name: 'bank-info',
            path: '/bankInfo',
            component: () => import(/* webpackChunkName: "user-address" */ '@src/views/user-bank/bank-info.vue'),
            meta: { title: '添加银行卡', requiresAuth: true }
        },
        {
            name: 'bankCode',
            path: '/bankCode',
            component: () => import(/* webpackChunkName: "user-address" */ '@src/views/user-bank/bank-code.vue'),
            meta: { title: '安全认证', requiresAuth: true }
        },
        {
            name: 'bank-remove',
            path: '/bankRemove',
            component: () => import(/* webpackChunkName: "user-address" */ '@src/views/user-bank/bank-remove.vue'),
            meta: { title: '解绑银行卡', requiresAuth: true }
        },
        {
            name: 'payresult',
            path: '/payresult',
            component: () => import(/* webpackChunkName: "payresult" */ '@src/views/pay-result/index.vue'),
            meta: { title: '付款结果', requiresAuth: true }
        },
        {
            name: 'order',
            path: '/order',
            component: () => import(/* webpackChunkName: "order" */ '@src/views/order/index.vue'),
            meta: { title: '我的订单', requiresAuth: true, keepAlive: false }
        },
        {
            name: 'order-detail',
            path: '/order/:id',
            component: () => import(/* webpackChunkName: "order-detail" */ '@src/views/order-detail/index.vue'),
            meta: { title: '订单详情', requiresAuth: true }
        },
        {
            name: 'logisticsProcess',
            path: '/logisticsProcess/:id',
            component: () => import(/* webpackChunkName: "logisticsProcess" */ '@src/views/order-detail/logisticsProcess.vue'),
            meta: { title: '物流进度', requiresAuth: true }
        },
        {
            name: 'order-comment',
            path: '/order/:id/comment',
            component: () => import(/* webpackChunkName: "order-comment" */ '@src/views/order-comment/index.vue'),
            meta: { title: '发表评价', requiresAuth: true }
        },
        {
            name: 'huodonglist',
            path: '/huodonglist',
            component: () => import(/* webpackChunkName: "order-comment" */ '@src/views/home/module/huodonglist.vue'),
            meta: { title: '活动', requiresAuth: false }
        },
        
        {
            name: 'cartConfirm',
            path: '/cart/confirm',
            component: () => import(/* webpackChunkName: "cartConfirm" */ '@src/views/order-confirm/index.vue'),
            meta: { title: '订单确认', requiresAuth: true }
        },
        {
            name: 'product',
            path: '/product',
            component: () => import(/* webpackChunkName: "product" */ '@src/views/product/index.vue'),
            meta: { title: '商品列表', keepAlive: false }
        },
        {
            name: 'goods',
            path: '/goods',
            component: () => import(/* webpackChunkName: "goods" */ '@src/views/product/goods.vue'),
            meta: { title: '商品列表', keepAlive: true }
        },
        {
            name: 'product-detail',
            path: '/product/:id',
            component: () => import(/* webpackChunkName: "product-detail" */ '@src/views/product-detail/index.vue'),
            meta: { title: '商品详情' }
        },
        {
            name: 'error',
            path: '/error',
            component: ErrorPage,
            meta: { title: '错误' }
        },

        {
          name: 'apply-in',
          path: '/apply',
          component: () => import('@src/components/apply/apply-in'),
          meta: { title: '申请入驻' }
        },
        {
            path: '*',
            redirect: "/error",
            meta: { title: '404' }
        },
		//      商品规格
		{
          name: 'goods-specifications',
          path: '/goodsSpecifications/:id',
          component: () => import('@src/views/goods-specifications/index.vue'),
          meta: { title: '商品规格' }
       },

    ]
})
