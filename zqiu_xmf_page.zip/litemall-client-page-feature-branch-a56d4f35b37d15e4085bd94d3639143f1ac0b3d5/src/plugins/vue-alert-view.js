

import Vue from 'vue'
import vueAlertView from '@src/components/base/vue-alert-view/iosAlertview.js'
Vue.use(vueAlertView);
