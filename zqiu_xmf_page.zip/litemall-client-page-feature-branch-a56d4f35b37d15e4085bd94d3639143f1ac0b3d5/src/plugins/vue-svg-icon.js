import Vue from 'vue'
import Icon from 'vue-svg-icon/Icon.vue';
Vue.component('icon', Icon);
