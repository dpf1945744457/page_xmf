import FastClick from 'fastclick'
console.log("引入fastclick支持！")
const str= navigator.userAgent.toLowerCase()
const ver=str.match(/cpu iphone os (.*?) like mac os/)
if (process.env.NODE_ENV == "production") {
//  FastClick.attach(document.body);
    if (!ver) { // 非IOS系统
	  // 引入fastclick 做相关处理
	  FastClick.attach(document.body)
	} else {
	  if (parseInt(ver[1])< 11) {
	    // 引入fastclick 做相关处理
	    FastClick.attach(document.body)
	  }
	}
}


