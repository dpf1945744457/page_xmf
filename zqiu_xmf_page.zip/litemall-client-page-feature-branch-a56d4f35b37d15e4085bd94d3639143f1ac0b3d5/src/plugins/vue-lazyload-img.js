import Vue from 'vue'
import Lazyload from "vue-lazyload-img"
Vue.use(Lazyload, {
    fade: true,
})
//v-lazyload