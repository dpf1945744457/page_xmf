import base from '@src/apis/base.js'
import http from '@src/apis/http.js'

//用户绑卡列表
export const postBankList = (params) => { return http.post(base.oaIp, "/wx/wallet/queryBindCard", params, true) }

//检测卡片类型
export const postCheckCard = (params) => { return http.post(base.oaIp, "/wx/wallet/checkCardType", params, true) }

//校验支付密码
export const checkPayPwd = (params) => { return http.post(base.oaIp, "/wx/wallet/checkPayPwd", params, true) }

//获取绑卡验证码 验证银行卡
export const postCheckBind = (params) => { return http.post(base.oaIp, "/wx/wallet/sendBindCardSms", params, true) }

//校验绑卡验证码
export const checkBindCardSms = (params) => { return http.post(base.oaIp, "/wx/wallet/checkBindCardSms", params, true) }

//设置支付密码
export const setPayPwd = (params) => { return http.post(base.oaIp, "/wx/wallet/setPayPwd", params, true) }

//发送忘记密码验证码
export const sendForgetPwdSms = (params) => { return http.post(base.oaIp, "/wx/wallet/sendForgetPwdSms", params, true) }

//验证忘记密码验证码
export const checkForgetPwdSms = (params) => { return http.post(base.oaIp, "/wx/wallet/checkForgetPwdSms", params, true) }

//忘记密码修改密码
export const changeAccountPwd = (params) => { return http.post(base.oaIp, "/wx/wallet/changeAccountPwd", params, true) }

//解绑银行卡
export const unbindBankCard = (params) => { return http.post(base.oaIp, "/wx/wallet/unbindBankCard", params, true) }

//获取我的钱包页面地址
export const getBankURL = (params) => { return http.post(base.oaIp, "/wx/wallet/toWallet", params, true) }
