import base from '@src/apis/base.js'
import http from '@src/apis/http.js'

// 获取待评价订单
export const getCommentOrder = (params) => {
    return http.get(base.oaIp, "/wx/comment/orderDetail", params)
}

// 订单评价
export const postComment = (params) => {
    return http.post(base.oaIp, "/wx/comment/addComment", params)
}

// 获取商品评价列表
export const getGoodsCommentList = (params) => {
    return http.get(base.oaIp, "wx/goods/commentList", params, false)
}
