import base from '@src/apis/base.js'
import http from '@src/apis/http.js'

// 购物车商品总数
export const getCartGoodscount = (params) => {
    return http.get(base.oaIp, "/wx/cart/goodscount", params)
}

// 购物车查询
export const getCartIndex = (params) => {
    return http.get(base.oaIp, "/wx/cart/index", params, true)
}

// 购物车商品选中或取消
export const postCartChecked = (params) => {
    return http.post(base.oaIp, "/wx/cart/checked", params)
}

// 删除购物车商品
export const postCartDelete = (params) => {
    return http.post(base.oaIp, "/wx/cart/delete", params)
}

// 修改购物车商品
export const postCartUpdate = (params) => {
    return http.post(base.oaIp, "/wx/cart/update", params)
}

// 加入购物车
export const postCart = (params) => {
    return http.post(base.oaIp, "/wx/cart/add", params, true, true)
}

// 立即购买
export const postBuyGoods = (params) => {
    return http.post(base.oaIp, "/wx/cart/fastadd", params, true, true)
}
