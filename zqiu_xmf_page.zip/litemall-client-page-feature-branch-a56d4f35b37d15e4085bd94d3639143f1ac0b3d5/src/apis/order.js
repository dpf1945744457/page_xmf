import base from '@src/apis/base.js'
import http from '@src/apis/http.js'
import {
    formSubmit
} from '@src/utils/create-form.js'

// 获取确认付款信息
export const getConfirmOrder = (params) => {
    return http.get(base.oaIp, "/wx/cart/checkout", params, true)
}
// 订单提交
export const postSubmitOrder = (params) => {
    return http.post(base.oaIp, "/wx/order/submit", params, true, false)
}
// 支付
export const postPrepayOrder = (params) => {
    return http.post(base.oaIp, "/wx/order/prepay", params, true, false)
}
export const cancelRefund = (params) => {
    return http.post(base.oaIp, "/wx/order/cancelRefund", params, true, false)
}

export const formSubmitOrder = (params) => {
    formSubmit(base.oaIp + "/wx/order/submit", "post", params)
}

export const demo = (params) => {
    formSubmit("http://test13.qtopay.cn/ChinaPayment/AggregatePayRouteServlet", "post", params)
}

// 获取订单信息
export const getOrderList = (params) => {
    return http.get(base.oaIp, "/wx/order/list", params, )
}
// 获取订单详情
export const getOrderDetail = (params) => {
    return http.get(base.oaIp, "/wx/order/detail", params, true)
}
// 取消订单
export const postOrderCancel = (params) => {
    return http.post(base.oaIp, "/wx/order/cancel", params, true, true)
}
// 申请退款
export const postOrderRefund = (params) => {
    return http.post(base.oaIp, "/wx/order/refund", params, true)
}
// 确认收货
export const postOrderConfirm = (params) => {
    return http.post(base.oaIp, "/wx/order/confirm", params, true)
}


//物流轨迹(快递100)
export const orderQueryTrack = (params) => {
    return http.post(base.oaIp, "/wx/order/queryTrack", params, true)
}