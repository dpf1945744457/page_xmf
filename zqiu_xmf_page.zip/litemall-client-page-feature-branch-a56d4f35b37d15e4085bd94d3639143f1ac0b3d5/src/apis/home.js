import base from '@src/apis/base.js'
import http from '@src/apis/http.js'


export const getHomeData = (params) => { return http.get(base.oaIp, "/wx/home/index", params, true) } 

//首页商品列表
export const getGoodsList = (params) => { return http.get(base.oaIp, "/wx/goods/list", params, true) } 

//首页商品分类
export const getAllListData = (params) => { return http.get(base.oaIp, "/wx/classify/all", params) }
export const goodsevent = (params) => { return http.get(base.oaIp, "/wx/goods/event", params) }
