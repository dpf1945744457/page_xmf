import base from '@src/apis/base.js'
import http from '@src/apis/http.js'

//获取主页分类列表
export const getWxSign = (params) => { return http.get(base.oaIp, "/wx/oauth/jsApi", params) }

