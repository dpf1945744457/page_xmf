import base from '@src/apis/base.js'
import http from '@src/apis/http.js'

// 图片上传
export const upload = (params) => { return http.post(base.oaIp, "/wx/storage/save-img", params) }