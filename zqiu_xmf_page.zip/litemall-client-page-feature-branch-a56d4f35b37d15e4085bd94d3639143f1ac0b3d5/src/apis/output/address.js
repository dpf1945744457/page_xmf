import base from '@src/apis/base.js'
import http from '@src/apis/http.js'

// 得到地区 接口地址要与服务器访问地址保持对应
export const getAddressData = async (params) => {
    try {
        let citydata = JSON.parse(localStorage.getItem("citydata"));
        // 如果有缓存 返回缓存数据
        if (citydata instanceof Array)
            return Promise.resolve(citydata);

        // 否则去请求数据
        let data = await http.get(base.staticIp, "/data/citydata.json?t=" + Date.now(), params, true, true);
        localStorage.setItem("citydata", JSON.stringify(data));
        if (data instanceof Array)
            return Promise.resolve(data);
    } catch (error) {
        return Promise.reject(error);
    }
}
// 地址列表
export const getAddressList = (params) => { return http.get(base.oaIp, "/wx/address/list", params, true, false) }
// 地址详情
export const getAddressDetail = (params) => { return http.get(base.oaIp, "/wx/address/detail", params, true) }
// 新增与编辑地址
export const postAddressSave = (params) => { return http.post(base.oaIp, "/wx/address/save", params, true) }
// 地址删除
export const postAddressDelete = (params) => { return http.post(base.oaIp, "/wx/address/delete", params, true) }