import base from '@src/apis/base.js'
import http from '@src/apis/http.js'

//获取主页分类列表
export const getCategoryData = (params) => { return http.get(base.oaIp, "/wx/catalog/index", params) }
//获取当前分类的下级分类
export const getCurrentCategoryData = (params) => { return http.get(base.oaIp, "/wx/catalog/current", params) }

// 右侧推荐分类
export const getListLftData = (params) => { return http.get(base.oaIp, "/wx/classify/pop", params) }
// 左侧单独所有分类
export const getListAllData = (params) => { return http.get(base.oaIp, "/wx/classify/all", params) }



//获取商品列表
export const getCategoryTabs = (params) => { return http.get(base.oaIp, "/wx/goods/category", params) }
export const getClassifyTabs = (params) => { return http.get(base.oaIp, "/wx/goods/classify", params) }
export const getProductList = (params) => { return http.get(base.oaIp, "/wx/goods/list", params, true) }

//获取商品详情
export const getProductDetailById = (params) => { return http.get(base.oaIp, "/wx/goods/detail", params, true) }

// 收藏商品
export const postCollect = (params) => { return http.post(base.oaIp, "/wx/collect/addordelete", params, true) }

