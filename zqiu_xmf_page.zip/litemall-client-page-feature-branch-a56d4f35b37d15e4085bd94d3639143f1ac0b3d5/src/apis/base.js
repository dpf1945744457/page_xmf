export default {
    NODE_ENV: process.env.NODE_ENV,
    // oaIp: process.env.NODE_ENV == "development" ? location.protocol + "//test19.qtopay.cn" : "/",
    //  oaIp:'http://192.168.3.107:8082',
    oaIp: "http://test19.qtopay.cn/",
    //  oaIp: "http://192.168.3.192:8082/",
    // 	oaIp: "https://www.xmfstore.com/",
    // oaIp: "https://www.bmall.com.hk/", /*香港正式域名*/
    staticIp: process.env.NODE_ENV == "development" ? "/static" : "/client/static"
}
