/**
* 检测是否微信环境 isWeiXin true | false
*/
export function isWeixin() {
    var ua = window.navigator.userAgent.toLowerCase();
    if (ua.match(/MicroMessenger/i) == 'micromessenger') {
        return true;
    } else {
        return false;
    }
};

/**
 * 检测是微信还是支付宝环境
 */
export function isWeixinOrAlipay() {
    var ua = window.navigator.userAgent.toLowerCase();
    //判断是不是微信
    if (ua.match(/MicroMessenger/i) == 'micromessenger') {
        return "WeiXIN";
    }
    //判断是不是支付宝
    if (ua.match(/AlipayClient/i) == 'alipayclient') {
        return "Alipay";
    }
    return false;
}

/**
 * 检测是安卓，ios或其他
 */
export function isAPPOrOther() {
    var ua = window.navigator.userAgent.toLowerCase();
    //android终端
    var isAndroid = ua.indexOf('Android') > -1 || ua.indexOf('Adr') > -1;  
　　//ios终端
    var isiOS = !!ua.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); 
    if (isiOS) {
		//ios
		return true;
	} else if (isAndroid) {
		//android
		return true;
	}else{
		return false;
	}
}