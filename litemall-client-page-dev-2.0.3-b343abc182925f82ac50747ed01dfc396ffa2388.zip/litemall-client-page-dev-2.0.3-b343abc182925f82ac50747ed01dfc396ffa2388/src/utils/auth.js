import Cookies from 'js-cookie'

const TokenKey = 'X-Litemall-Token'
const wxTokenKey = 'X-Litemall-Woken'

export function getToken() {
    return Cookies.get(TokenKey)
}

export function setToken(token, options) {
    return Cookies.set(TokenKey, token, options)
}

export function removeToken() {
    return Cookies.remove(TokenKey)
}

//微信绑定标识
export function getWxToken() {
    return Cookies.get(wxTokenKey)
}

