import { Toast,Dialog  } from 'vant'
function scanCode(){
	var timeStamp = "scanCodeText";
	window.location.href = "https://www.xmfstore.com/client#/scanCode?scanCodeText="+timeStamp;
}

/*
* @params url  // 扫码成功返回地址
*/
 window.scanCodeResult = function(url){
    let  getUrl;
    if(url.indexOf("#") != -1){
        getUrl = url.split("#")[0];
    }
    // 判断是否是小蜜蜂链接
    let test = 'http://test19.qtopay.cn/client',
        prod = 'https://www.xmfstore.com/client';
    if(getUrl === test || getUrl === prod) {
        window.location.href = url;
    } else {
        Dialog.confirm({
            title: '提示',
            message: '跳转链接不是小蜜蜂链接，可能存在安全隐患，确认跳转吗？'
        }).then(() => {
            window.location.href = url;
        }).catch(() => {
            // this.$router.go(-1)
        });
    }
}

export {
	scanCode,
	scanCodeResult
}
