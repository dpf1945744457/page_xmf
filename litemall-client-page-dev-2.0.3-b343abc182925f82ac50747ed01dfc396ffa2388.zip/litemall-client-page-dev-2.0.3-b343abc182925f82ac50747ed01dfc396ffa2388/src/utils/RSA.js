import Vue from 'vue'
import { JSEncrypt } from 'jsencrypt'

Vue.prototype.$getRSA = function(password){
    let encrypt = new JSEncrypt()
    encrypt.setPublicKey('MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDq2xlXIehEB5Qpw+uRPvFzsJWQATQza4gAyDEhUAgdPzMujSRp7ky9fXeu/8O+yRJbRfVj2yqjFv+QTOlYeTMCSPJ5GMrhfVf/H2GqXam/FU/jok5Z8Ko5Fur1MZDtnLZQeJg0C8D0ItJ1oJA9sfOtU+NVC9WC8iZLFeYz+uPAOwIDAQAB')
    return encrypt.encrypt(password)
}

