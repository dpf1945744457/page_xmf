<template>
    <section>
      <div class="out" id="roll">
        <div v-for="item in list" @click="handleRouter(item.id)"><span>热门</span><a class="itemName"> {{item.name}}</a></div>
      </div>
    </section>
</template>

<script>
  import axios from 'axios'
  import base from '@src/apis/base.js'
  export default {
    name: "index",
    data(){
      return{
        speed:3000,
        list:[]
      }
    },
    mounted(){
      this.goods();
      var area = document.getElementById("roll");

      if(this.$route.path == '/'){
        this.$nextTick(function () {
          let _self = this;
          function scroll(){
            for(let i = 0;i < _self.list.length;i++){

              if(document.getElementsByClassName('itemName').length == 0){
                clearInterval(scroll);
                return false;

              }else {
                // if(filtersLength.innerHTML.length > 25){
                //   document.getElementsByClassName('itemName')[i].innerHTML = document.getElementsByClassName('itemName')[i].innerHTML.substr(0,30) + '...' ;
                // }
                document.getElementsByClassName('itemName')[i].innerHTML = document.getElementsByClassName('itemName')[i].innerHTML.substr(0,30) + '...' ;
              }
            }

            let k = _self.list.length;
            let q = _self.list.length - 1;
            let a = q/k;

            if(area.scrollTop >= (area.scrollHeight-20)*a){
              area.scrollTop = 0;
            }else{
              area.scrollTop += 20;
            }
          }

          setInterval(scroll,this.speed);
        });
      }
    },
    methods:{
      goods(){
        axios.get(base.oaIp + '/wx/goods/topGoods').then((response) => {
          let length = response.length;
          for(let i = 0;i < length;i++){
            this.list.push(response[i])
          }
        });
      },
      handleRouter(id){
        this.$router.push({path:'/product/' + id})
      }
    }
  }
</script>

<style scoped>
  .out{
    overflow: hidden;
    height: 20px;
    font-size: 13px;
    line-height: 20px;
  }
  span{
    color: red;
    padding-left: 10px;
    padding-right: 5px;
  }
  .itemName{
    color: black;
  }
</style>
