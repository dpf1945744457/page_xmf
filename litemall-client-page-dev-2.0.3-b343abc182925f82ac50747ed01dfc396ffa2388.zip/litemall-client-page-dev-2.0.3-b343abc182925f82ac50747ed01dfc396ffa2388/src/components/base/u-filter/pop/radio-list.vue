<template>
    <div class="radio-list">
        <Ucell :title="item.name" :class="{selected:value.name == item.name}" @click.native="clickItem(item,index)" :borderLine="true" v-for="(item,index) in data.data" :key="index"></Ucell>
    </div>
</template>

<script>
import Ucell from '@src/components/base/u-cell'
export default {
    props: {
        data: {
            type: Object,
            default: () => {
                return {};
            }
        },
        value: {
            type: Object,
            default: () => {
                return {};
            }
        },
    },
    components: { Ucell },
    data() {
        return {
            currIndex: 0
        }
    },
    mounted() {
        this.setDefault(this.value);
    },
    methods: {
        setDefault(value) {
            // this.data.find(item => item == value)
        },
        clickItem(item, index) {
            this.currIndex = index;
            this.data.barMenuValue = item;
            this.$emit("change", this.data, item);
        }
    }


}
</script>

<style lang="less" scoped>
.selected {
  color: #e0443b;
  // border-color: red;
  background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAUCAMAAACgaw2xAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAA8UExURUdwTOQ6OtQqKuQ4O/8AAOM4O+Q4POI4OuM4O+Q4O+M4O+M5POQ4O+M4O+U4OuU2POQ4POQ4O+Q5O+Q5POG6XjYAAAATdFJOUwAvBl4BstwRzseW9XvrRR2+iVGqKQ+qAAAAaUlEQVQY023PSQ6AIBBEUSZpBhGTuv9dnRAiVq869VdPKXZmj3RXCTxYlMp2nbGxXTxWtrsFi2NhhRe2b8ia7bXAUllEam+M8pWZNyAIlUkY5SsbZZa95S9rhcjuQmVX4bKzdNlcuuy5A/z7BLUpU+pnAAAAAElFTkSuQmCC);
  background-size: 12px auto;
  background-position: right 10px bottom 15px;
  background-repeat: no-repeat;
  span {
    color: #e0443b;
  }
}
</style>
