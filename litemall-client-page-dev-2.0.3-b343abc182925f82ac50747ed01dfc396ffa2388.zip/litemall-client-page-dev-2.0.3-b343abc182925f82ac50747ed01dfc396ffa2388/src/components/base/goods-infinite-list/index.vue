<template>
    <div class="goods-infinite-list">
        <!-- 商品为空 -->
        <Nodata v-if="list.length == 0" :imgurl="require('@src/assets/img/bg_empty_data.png')" content='暂无足迹'></Nodata>

        <!-- 商品列表 -->
        <div class="clearfix">
            <GoodsItem v-for="(item,index) in list" :key="index" :item="{name:item.name,picUrl:item.picUrl,retailPrice:item.retailPrice,brief:item.brief,id:item.goodsId}" :cartBtn="false"></GoodsItem>
        </div>

        <!-- 滚动到底监听组件 -->
        <InfiniteScroll ref="InfiniteScroll" @infinite="$emit('infinite',$refs.InfiniteScroll)"></InfiniteScroll>
    </div>
</template>

<script>
import Nodata from "@src/components/base/no-data"
import GoodsItem from '@src/components/base/goodsItem/index.vue'
import InfiniteScroll from "@src/components/base/infinite-scroll"
export default {
    props: ["list"],
    components: { Nodata, GoodsItem, InfiniteScroll },
}
</script>

<style>
</style>
