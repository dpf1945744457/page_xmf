<template>
	<div class="vux-header">
		<div class="vux-header-left">
			<slot name="overwrite-left">
				<transition :name="transition">
					<a class="vux-header-back" href="javascript:void(0)" v-show="_leftOptions.showBack" @click="onClickBack">{{ typeof _leftOptions.backText === 'undefined' ? '返回' : _leftOptions.backText}}</a>
				</transition>
				<transition :name="transition">
					<div class="left-arrow" @click="onClickBack" v-show="_leftOptions.showBack"></div>
				</transition>
			</slot>
			<slot name="left"></slot>
		</div>
		<h1 class="vux-header-title" :class="{'wxHeaderTitle':isWeixin()}" @click="$emit('on-click-title')" v-if="!shouldOverWriteTitle" :style="headerStyle">
            <i class="weui-loading" style="margin-bottom: 3px;" v-show="showLoading && !!!noLoading"></i>
            <slot>
                <transition :name="transition">
                    <span v-show="title">{{title}}</span>
                </transition>
            </slot>
        </h1>
		<div class="vux-header-title-area" v-if="shouldOverWriteTitle">
			<slot name="overwrite-title"></slot>
		</div>
		<div class="vux-header-right">
			<a class="vux-header-more" href="javascript:void(0)" @click="$emit('on-click-more')" v-if="rightOptions.showMore"></a>
			<slot name="right"></slot>
		</div>
	</div>
</template>

<script>
	import objectAssign from 'object-assign'
	import { mapState, mapActions, mapGetters } from "vuex"
	import base from "@src/apis/base";
	export default {
		name: 'x-header',
		props: {
			headerStyle: String,
			leftOptions: Object,
			title: String,
			transition: String,
			noLoading: Boolean,
			shouldOverWriteTitle: '',
			rightOptions: {
				type: Object,
				default() {
					return {
						showMore: false
					}
				}
			}
		},
		beforeMount() {
			if(this.$slots['overwrite-title']) {
				this.shouldOverWriteTitle = true
			}
		},
		computed: {
			...mapGetters(["showLoading"]),
			_leftOptions() {
				return objectAssign({
					showBack: true,
					preventGoBack: false
				}, this.leftOptions || {})
			}
		},
		methods: {
			onClickBack() {
				this.$nextTick(() => {
					// let referrer = document.referrer;
					// let Reg = ""; //检测是否是从当前域名下点击的返回
					// if (base.NODE_ENV == 'development') {
					//     // 填写本地的ip地址
					//     Reg = /^http:\/\/0.0.0.0:8080/g;
					// }
					// if (base.NODE_ENV == 'production') {
					//     // 线上的地址
					//     Reg = /^http:\/\/test19\.qtopay\.cn\/client/g;
					// }
					// if (referrer && !(Reg.test(referrer))) {
					//     this.$router.replace('/')
					// } else {
					if(this._leftOptions.preventGoBack) {
						this.$emit('on-click-back')
					} else {
						this.$router ? this.$router.back() : window.history.back()
					}
					// }
                })
                
                // 收货地址管理
                this.$emit('isBack')

			},
			isWeixin() {
			    var ua = window.navigator.userAgent.toLowerCase();
			    if (ua.match(/MicroMessenger/i) == 'micromessenger') {
			        return true;
			    } else {
			        return false;
			    }
			}
		},
	}
</script>

<style lang="less">
	// @import '../../styles/variable.less';
	@import "../../styles/weui/widget/weui-loading/weui-loading.less";
	a:link {
		color: #999;
		text-decoration: none;
	}
	.vux-header {
		position: relative;
		padding: 3px 0;
		box-sizing: border-box;
		background: #fafafa;
		// background-color: red;
	}

	.vux-header .vux-header-title {
		line-height: 40px;
		text-align: center;
		font-size: 18px;
		font-weight: 400;
		// color: red;
	}

	.vux-header-title-area,
	.vux-header .vux-header-title {
		/*margin: 0 88px;*/
		height: 40px;
		width: auto;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}
	.wxHeaderTitle{
		margin-left: 15px!important;
	}
	.vux-header .vux-header-title>span {
		display: inline-block;
	}

	.vux-header .vux-header-left,
	.vux-header .vux-header-right {
		position: absolute;
		top: 13px;
		display: block;
		font-size: 14px;
		line-height: 21px;
		// color: red;
	}

	.vux-header .vux-header-left a,
	.vux-header .vux-header-left button,
	.vux-header .vux-header-right a,
	.vux-header .vux-header-right button {
		float: left;
		margin-right: 8px;
		// color: red;
	}

	.vux-header .vux-header-right img{
		width: 24px;
	}

	.vux-header .vux-header-left a:active,
	.vux-header .vux-header-left button:active,
	.vux-header .vux-header-right a:active,
	.vux-header .vux-header-right button:active {
		opacity: 0.5;
	}

	.vux-header .vux-header-left {
		left: 18px;
	}

	.vux-header .vux-header-left img{
		width: 24px;
	}

	.vux-header .vux-header-left .vux-header-back {
		padding-left: 16px;
	}

	.vux-header .vux-header-left .left-arrow {
		position: absolute;
		width: 30px;
		height: 30px;
		top: -5px;
		left: -5px;
		&:before {
			content: "";
			position: absolute;
			width: 12px;
			height: 12px;
			border: 1px solid #ccc;
			border-width: 1px 0 0 1px;
			transform: rotate(315deg);
			top: 8px;
			left: 7px;
		}
	}

	.vux-header .vux-header-right {
		right: 15px;
	}

	.vux-header .vux-header-right a,
	.vux-header .vux-header-right button {
		margin-left: 8px;
		margin-right: 0;
	}

	.vux-header .vux-header-right .vux-header-more:after {
		content: "\2022\0020\2022\0020\2022\0020";
		font-size: 16px;
	}

	.vux-header-fade-in-right-enter-active {
		animation: fadeinR 0.5s;
	}

	.vux-header-fade-in-left-enter-active {
		animation: fadeinL 0.5s;
	}

	@keyframes fadeinR {
		0% {
			opacity: 0;
			transform: translateX(150px);
		}
		100% {
			opacity: 1;
			transform: translateX(0);
		}
	}

	@keyframes fadeinL {
		0% {
			opacity: 0;
			transform: translateX(-150px);
		}
		100% {
			opacity: 1;
			transform: translateX(0);
		}
	}
</style>
