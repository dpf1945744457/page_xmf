<template>
	<div class="through">
		<div class="form-group" :class="{'top-line':topLine,'bootom-line':bottomLine}">
			<dl>
				<dt>
	                <span>{{label}}</span>
	            </dt>
				<dd>
					<div class="areaCode" v-if="phoneShow">
						<div :class="{check:istrue==1} " @click='changeCheck(1)'>中国大陆</div>
						<div :class="{check:istrue==2} " @click='changeCheck(2)'>香港</div>
						<div :class="{check:istrue==3}" @click="openArea('')">其他</div>
					</div>
                    <!-- 支付人姓名 -->
					<div class="form-control-box" v-if="!phoneShow">
						<input :readonly="disabled" ref="input" :type="type"  class="form-control" :style="`width:${width}`" v-model="inputVal" :placeholder="placeholder" :maxLength="maxLength" autocomplete="off" @blur="onBlur">
						<div class="form-right">
							<slot></slot>
						</div>
					</div>
				</dd>
			</dl>
			<div class="fix_popBox" v-if="areaShow" ></div>
			<div class="popBox" v-if="areaShow" >
				<!--@click="clearArea"-->
				<div class="pop_top" >
					<form action="/">
						<van-search v-model="searchValue" placeholder="可输入地区或区号进行快速查询" show-action @search="onSearch" @cancel="onCancel" />
					</form>
				</div>
				<ul>
					<li @click.stop="checkArea(item.areaCode)" v-for="(item,index) in areaArr">{{item.country}} {{item.areaCode}}</li>
				</ul>
			</div>
		</div>
	</div>
</template>

<script>
	import { getPhoneAreaCode } from '@src/apis/user.js'
	//	import { Picker } from 'vux'
	import { Search } from 'vant';
	export default {
		props: {
			label: String,
			placeholder: String,
			maxLength: String,
			width: {
				type: String,
				default: "80%"
			},
			topLine: Boolean,
			bottomLine: Boolean,
			type: {
				type: String,
				default: "text"
			},
			value: String,
			disabled: Boolean,
			phoneShow: Boolean,
		},
		data() {
			return {
				inputVal: "",
				areaShow: false,
				istrue: 1,
				areaArr: [],
				areaArrs: ['+1'],
				idNum: '',
				searchValue: '',
			}
		},
		components: {
			Search
		},
		watch: {
			value(val) {
				this.inputVal = val;
			},
			inputVal(val) {
				this.$emit("input", val);
			},
			searchValue(val){
				getPhoneAreaCode({condition: val}).then((res) => {
//					this.areaShow = true
					this.areaArr = res
				})
			},
		},
		mounted() {
			if(this.value) {
				this.inputVal = this.value;
			}
			this.$emit("getAreaId", "+86");
		},
		methods: {
            onBlur() {
                this.$emit('blur')
            },

			focus() {
				this.$refs.input.focus();
			},

			openArea(val) {
				//this.areaArr = value
				//获取手机区号
				this.searchValue = val
				getPhoneAreaCode({condition: val}).then((res) => {
					this.areaShow = true
					this.areaArr = res
					this.$emit('showBacks',false)
				})
			},
			clearArea() {
				this.areaShow = false
			},
			changeCheck(index) {
				if(index == 1) {
					this.$emit("getAreaId", "+86");
				} else if(index == 2) {
					this.$emit("getAreaId", "+852");
				}
				this.istrue = index
			},
			checkArea(id) {
				this.$emit("getAreaId", id);
				this.$emit('showBacks',true)
				
				this.istrue = 3;
				this.areaShow = false
				
			},
			onSearch(){
				this.openArea(this.searchValue)
			},
			onCancel(){
				this.areaShow = false
				
				this.$emit('showBacks',true)
				
			}

		},
	}
</script>

<style lang="less" scoped>
	@import "../../styles/weui/base/mixin/setOnepx.less";
	.fix_popBox{
		position: fixed;
		top: 0;
		left: 0;
		height: 2.1rem;
		width: 100%;
	}
	.through /deep/.van-field__control{
		line-height: 1.05rem;
	}
	
	.through .pop_top /deep/form{
		width: 15rem;
	}
	
	.form-group {
		background: #fff;
		position: relative;
		-webkit-tap-highlight-color: rgba(0, 0, 0, 0);
		dl {
			width: 94%;
			margin: auto;
			overflow: hidden;
			position: relative;
			box-sizing: border-box;
			dt {
				width: 4.5rem;
				height: 2.25rem;
				line-height: 2.25rem;
				float: left;
				// font-size: 0.7rem;
				color: #222;
			}
			dd {
				position: relative;
				padding-left: 4.5rem;
				line-height: 2.25rem;
				.form-control-box {
					// display: flex;
					.form-right {
						//   min-width: 20%;
						display: inline-block;
						// display: flex;
						text-align: center;
						align-items: center;
					}
				}
				input {
					display: inline-block;
					border: none;
					// padding: 0.3rem 0;
					line-height: 1.25rem;
					// width: 190px;
					color: #666;
					font-size: 15px;
					height: 40px;
				}
			}
		}
	}
	
	.areaCode {
		display: inline-block;
		display: flex;
		height: 1.25rem;
		padding: 0.5rem 0;
		div {
			flex: 1;
			margin: 0 .2rem;
			line-height: 1.25rem;
			text-align: center;
			border-radius: 4px;
		}
		.check {
			background: #ffdf00;
			color: #fff;
		}
	}
	
	.areaPop {
		position: fixed;
		left: 0;
		right: 0;
		top: 2rem;
		bottom: 0;
		z-index: 9999;
	}
	
	.popBox {
		position: fixed;
		bottom: 0;
		left: 0;
		right: 0;
		top: 2.1rem;
		background: #fff;
		z-index: 9999;
	}
	
	.pop_top {
		height: 2rem;
		display: flex;
		padding: 0 .5rem;
		
	}
	
	.popBox {
		ul {
			height: 100%;
			width: 100%;
			overflow: auto;
			-webkit-overflow-scrolling: touch;
			li {
				line-height: 2rem;
				text-align: left;
				padding: 0 1.2rem;
				border-bottom: 1px solid #eeee;
			}
		}
	}
	
	.top-line {
		&::before {
			.setTopLine();
		}
	}
	
	.bootom-line {
		&::after {
			.setBottomLine();
		}
	}
</style>