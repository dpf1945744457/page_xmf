<template>
    <div class="skeleton">
        <div class="skeleton-head"></div>
        <div class="skeleton-body">
            <div class="skeleton-title"></div>
            <div class="skeleton-content"></div>
        </div>
    </div>
</template>

<script>
export default {

}
</script>

<style lang="less" scoped>
.skeleton {
  padding: 10px;
}

.skeleton .skeleton-head,
.skeleton .skeleton-title,
.skeleton .skeleton-content {
  background: #e6e6e6;
}

.skeleton-head {
  width: 100px;
  height: 100px;
  float: left;
}

.skeleton-body {
  margin-left: 110px;
}

.skeleton-title {
  width: 100%;
  height: 60px;
}

.skeleton-content {
  width: 80%;
  height: 30px;
  margin-top: 10px;
}
.skeleton .skeleton-head,
.skeleton .skeleton-title,
.skeleton .skeleton-content {
  background-image: linear-gradient(
    90deg,
    rgba(255, 255, 255, 0.15) 25%,
    transparent 25%
  );
  background-size: 20rem 20rem;
  animation: skeleton-stripes 1s linear infinite;
}

@keyframes skeleton-stripes {
  from {
    background-position: 0 0;
  }
  to {
    background-position: 20rem 0;
  }
}
</style>
