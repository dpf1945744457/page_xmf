<template>
    <div class="box-example" :class="{'box-example-bg':mask}" v-show="visible" @click="visible = false">
        <div class="box-content">
            <icon v-if="showLoading" name="loading2" scale="3" spin color="#eee">loading</icon>
            <slot v-else></slot>
        </div>

        <div class="boxClose" @click="visible = false"></div>
    </div>
</template>

<script>
export default {
    props: {
        value: {
            type: Boolean,
            default: false
        },
        mask: {
            type: Boolean,
            default: true
        },
        showLoading: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            visible: false,
            key: true,
        };
    },
    watch: {
        value(val) {
            this.visible = val;
        },
        visible(val) {
            this.$emit("input", val);
            if (val && this.key) {
                this.key = false;
                this.$emit("once-visible", val);
            }

        }
    },
    created() {
        this.visible = this.value;
    }
};
</script>

<style lang="less" scoped>
@keyframes fideIn {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}
.box-example {
  width: 100%;
  height: 100%;
  position: fixed;
  z-index: 1001;
  left: 0;
  top: 0;
  display: flex;
  flex-direction: column;
  animation: fideIn 0.2s linear;
}
.box-example-bg {
  background: rgba(0, 0, 0, 0.6);
}
.box-content {
  max-width: 300px;
  text-align: center;
  margin: auto;
}
.boxClose {
  //   background: url("../../assets/images/close.png") no-repeat;
  background-size: 100%;
  width: 35px;
  height: 35px;
  margin: 8vw auto;
  &::after {
    content: "";
    display: block;
    width: 100%;
    height: 1px;
    background: #fff;
    border-radius: 500px;
    transform: rotate(45deg);
    transform-origin: center center;
  }
  &::before {
    content: "";
    display: block;
    width: 100%;
    height: 1px;
    background: #fff;
    border-radius: 500px;
    transform: rotate(-45deg);
    transform-origin: center center;
  }
}
</style>
