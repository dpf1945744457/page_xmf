<template>
  <a
    href="javascript:;"
    class="weui-tabbar__item"
    :class="{'weui-bar__item_on': isActive, 'vux-tabbar-simple': simple,'home':tabName=='home','cart':tabName=='cart','wanqu':tabName=='wanqu','food':tabName=='food','charge':tabName=='charge','product':tabName=='product','user':tabName=='user'}"
    @click.capture="onItemClick(tabName)"
  >
    <div
      class="weui-tabbar__icon"
      :class="[iconClass || $parent.iconClass, {'vux-reddot': showDot}]"
      v-if="!simple"
    >
      <slot name="icon" v-if="!simple && !(hasActiveIcon && isActive)"></slot>
      <slot name="icon-active" v-if="!simple && hasActiveIcon && isActive"></slot>
      <sup v-if="badge">
        <badge :text="badge"></badge>
      </sup>
    </div>
    <p class="weui-tabbar__label">
      <slot name="label"></slot>
    </p>

    <p class="weui-tabbar__label munidemo"  v-if="mune && isActive">
      <slot name="mune" v-if="mune"></slot>
    </p>
  </a>
</template>

<script>
import { childMixin } from "./multi-items";
import Badge from "../badge";

export default {
  name: "tabbar-item",
  components: {
    Badge
  },
  mounted() {
    if (!this.$slots.icon) {
      this.simple = true;
    }
    if (this.$slots["icon-active"]) {
      this.hasActiveIcon = true;
    }
    if (this.$slots["mune"]) {
      this.mune = true;
    }
  },
  mixins: [childMixin],
  props: {
    showDot: {
      type: Boolean,
      default: false
    },
    badge: Number,
    link: [String, Object],
    iconClass: String,
    tabName: String
  },
  computed: {
    isActive() {
      return this.$parent.index === this.currentIndex;
    }
  },
  data() {
    return {
      simple: false,
      hasActiveIcon: false,
      mune: false,
      munex: false
    };
  }
};
</script>
<style type="text/css">
.munidemo {
  position: absolute;
  top: -52px;
  background: rgba(84, 78, 78, 0.7);
  width: 100%;
  height: 30px;
  padding: 4px 0;
  line-height: 30px;
  border-radius: 4px;
  color: #fff !important  ;
}
.munidemo :before {
  width: 0;
  height: 0;
  border: 10px solid transparent;
  border-top-color: rgba(84, 78, 78, 0.7);
  position: absolute;
  content: "";
  bottom: -20px;
  left: 0;
  right: 0;
  margin: auto;
}
.weui-tabbar__item.home {
  background: url(../../../svg/icon_lhome_ine.png) no-repeat center 8px;
  background-size: 24px;
}
.weui-bar__item_on.home {
  background: url(../../../svg/icon_lhome_fill.png) no-repeat center 8px;
  background-size: 24px;
}
.weui-tabbar__item {
  position: relative;
}
.weui-tabbar__item.wanqu {
  background: url(../../../svg/icon_icon_dawanqu@2x.png) no-repeat center 8px;
  background-size: 24px;
}
.weui-bar__item_on.wanqu {
  background: url(../../../svg/icon_icon_dawanqu_red@2x.png) no-repeat center
    8px;
  background-size: 24px;
}
.weui-tabbar__item.cart {
  background: url(../../../svg/icon_gouwuche_line.png) no-repeat center 8px;
  background-size: 24px;
}
.weui-bar__item_on.cart {
  background: url(../../../svg/icon_gouwuche_fill.png) no-repeat center 8px;
  background-size: 24px;
}
.weui-tabbar__item.food {
  background: url(../../../svg/icon_food@2x.png) no-repeat center 8px;
  background-size: 24px;
}
.weui-bar__item_on.food {
  background: url(../../../svg/icon_food_red@2x.png) no-repeat center 8px;
  background-size: 24px;
}
.weui-tabbar__item.charge {
  background: url(../../../svg/icon_chongdianbao.svg) no-repeat center 8px;
  background-size: 24px;
}
.weui-bar__item_on.charge {
  background: url(../../../svg/icon_chongdianbao_red.svg) no-repeat center 8px;
  background-size: 24px;
}
.weui-tabbar__item.product {
  background: url(../../../svg/icon_xmf.png) no-repeat center 6px;
  background-size: 27px;
}
.weui-bar__item_on.product {
  background: url(../../../svg/icon_xmf_fill.png) no-repeat center 6px;
  background-size: 27px;
}
.weui-tabbar__item.user {
  background: url(../../../svg/icon_gr.png) no-repeat center 8px;
  background-size: 24px;
}
.weui-bar__item_on.user {
  background: url(../../../svg/icon_gr_fill.png) no-repeat center 8px;
  background-size: 24px;
}
</style>