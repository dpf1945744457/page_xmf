<template>
    <div class="goods-item">
        <a class="picUrl" target="_blank" href="javascript:void(0);">
            <img v-lazy="item.picUrl" />
        </a>
        <a class="content" target="_blank" href="javascript:void(0);">
            <div class="title">
                <!-- <i class="ico13">
                    <img src="./img/sdj.png">
                </i> -->
                {{item.name}}
            </div>
            <small class="brief">{{item.brief || item.name}}</small>
            <div class="list-price buy">
                <span class="price-new">HK${{item.retailPrice}}</span>
                <!-- <i class="del">/HK${{item.delMoney}}</i> -->
                <span class="good-btn">
                    <i class="ico15">
                        <img src="./img/sts.png" />
                    </i>
                    去抢购
                </span>
            </div>
        </a>
    </div>

</template>

<script>
export default {
    props: ["item"]
}
</script>

<style lang="less" scoped>
/*reset end*/

.ico15 {
  display: inline-block;
  width: 11px;
  height: 11px;
}

.goods-item {
  float: left;
  width: 48.05%;
  position: relative;
  margin: 0.935% 0.935% 1.135%;

  background: rgba(255, 255, 255, 1);
  //   border-radius: 3px;
  //   border-bottom: 1px solid rgba(207, 201, 193, 1);

  img[lazy="error"] {
    width: 100px;
  }
}

.goods-item a {
  display: block;
  padding: 0 10px;
}

.goods-item .picUrl {
  height: 165px;
  line-height: 165px;
  text-align: center;
  overflow: hidden;
}

.goods-item img {
  width: 100%;
  //   height: 100%;
  position: relative;
  border-radius: 3px 3px 0 0;
}

.goods-item .content {
}

.goods-item .title {
  //   height: 33px;
  //   width: 94.6%;
  font-size: 13px;
  font-weight: 500;
  color: rgba(94, 94, 94, 1);
  //   padding: 2% 2.7%;
  overflow: hidden;
  text-overflow: ellipsis;
  display: flex;
  display: -webkit-box;
  // 留着以下注释，否则wenpack打包不上
  /*! autoprefixer: off */
  -webkit-box-orient: vertical;
  /* autoprefixer: on */
  -webkit-line-clamp: 2;
}

.goods-item .brief {
  display: block;
  padding: 5px 0;
  overflow: hidden; //超出的文本隐藏

  text-overflow: ellipsis; //溢出用省略号显示

  white-space: nowrap; //溢出不换行
}

.goods-item .title .ico13 {
  display: inline-block;
  margin-bottom: 0px;
  width: 24px;
  height: 11px;
}

.list-price {
  //   width: 94.6%;
  height: 34px;
  line-height: 35px;
  //   border-top: 1px dotted #d0d0d0;
  position: relative;
  bottom: 0;
  //   padding: 0 2.7%;
  color: red;
  font-size: 18px;
}

.del {
  text-decoration: line-through;
}

.good-btn {
  display: block;
  position: absolute;
  width: 52px;
  height: 18px;
  line-height: 18px;
  background: rgba(255, 102, 0, 1);
  color: rgba(255, 255, 255, 1);
  font-size: 12px;
  text-align: right;
  top: 8px;
  right: 5px;
  padding-right: 4px;
  border-radius: 9px 0 0 9px;
}
</style>
