<template>
    <div class="goods-item">
        <a class="picUrl" target="_blank" href="javascript:void(0);" @click="$router.push(`/product/${item.id}`)">
            <img v-lazy="item.picUrl" :key="item.picUrl" />
        </a>
        <a target="_blank" href="javascript:void(0);" @click="$router.push(`/product/${item.id}`)">
            <div class="title">
                {{item.name}}
            </div>
            <small class="brief">{{item.brief || item.name}}</small>
        </a>
        <div class="list-price buy">
            <div class="price">
                <i>HK$</i>
                <span class="price-new">{{item.retailPrice}}</span>
                <!-- <i class="del">/HK${{item.delMoney}}</i> -->
            </div>
            <icon v-if="cartBtn" name="cart" scale="3" @click.native="$emit('clickCartBtn')"></icon>
        </div>
    </div>

</template>

<script>
export default {
    props: {
        item: Object,
        cartBtn: {
            type: Boolean,
            default: true
        }
    }
}
</script>

<style lang="less" scoped>
/*reset end*/

.ico15 {
  display: inline-block;
  width: 11px;
  height: 11px;
}

.goods-item {
  float: left;
  width: 48.05%;
  position: relative;
  margin: 0.935% 0.935% 1.135%;

  background: rgba(255, 255, 255, 1);
  //   border-radius: 3px;
  //   border-bottom: 1px solid rgba(207, 201, 193, 1);
}

.goods-item a {
  display: block;
}

.goods-item .picUrl {
  height: 165px;
  line-height: 165px;
  text-align: center;
  overflow: hidden;
}

.goods-item img {
  width: 100%;
  //   height: 100%;
  position: relative;
  border-radius: 3px 3px 0 0;
}

.goods-item .title {
  height: 33px;
  width: 94.6%;
  font-size: 13px;
  font-weight: 500;
  color: rgba(94, 94, 94, 1);
  padding: 2% 2.7%;
  overflow: hidden;

  text-overflow: ellipsis;

  display: -webkit-box;
  // 留着以下注释，否则wenpack打包不上
  /*! autoprefixer: off */
  -webkit-box-orient: vertical;
  /* autoprefixer: on */

  -webkit-line-clamp: 2;
}

.goods-item .brief {
  display: block;
  padding: 5px 0;
  overflow: hidden; //超出的文本隐藏

  text-overflow: ellipsis; //溢出用省略号显示

  white-space: nowrap; //溢出不换行
}

.goods-item .title .ico13 {
  display: inline-block;
  margin-bottom: 0px;
  width: 24px;
  height: 11px;
}

.list-price {
  width: 94.6%;
  height: 34px;
  line-height: 35px;
  //   border-top: 1px dotted #d0d0d0;
  position: relative;
  bottom: 0;
  padding: 0 2.7%;
  display: flex;
  align-items: center;
  font-size: 18px;
  .price {
    flex: 1;
    color: red;
  }
  .buy .price-new {
  }
}

.del {
  text-decoration: line-through;
}

.good-btn {
}
</style>
