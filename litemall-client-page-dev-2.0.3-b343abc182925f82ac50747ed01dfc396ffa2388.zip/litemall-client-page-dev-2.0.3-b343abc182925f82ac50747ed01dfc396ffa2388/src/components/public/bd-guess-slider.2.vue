<template>
    <div class="bd-guess-slider">
        <Ucell title="相关推荐"></Ucell>

        <div class="clearfix">
            <!-- 配置slider组件 -->
            <slider ref="slider" :options="options" @slide='slide' @tap='onTap' @init='onInit'>
                <!-- 直接使用slideritem slot -->
                <slideritem class="m-slider-item" v-for="(Temp,i) in listTemp" :key="i">
                    <GoodsItem class="slider-goods-item" v-for="(item,index) in Temp" :key="index" :item='item'></GoodsItem>
                </slideritem>
                <!-- 设置loading,可自定义 -->
                <!-- <div slot="loading">loading...</div> -->
            </slider>
        </div>

        <!-- <div class="slider clearfix" v-for="(Temp,i) in listTemp" :key="i">
            <GoodsItem class="slider-goods-item" v-for="(item,index) in Temp" :key="index" :item='item'></GoodsItem>
        </div> -->
    </div>
</template>

<script>

import Ucell from '@src/components/base/u-cell'
import GoodsItem from '@src/components/base/goodsItem'
import { slider, slideritem } from 'vue-concise-slider'
export default {
    components: { Ucell, GoodsItem, slider, slideritem },
    data() {
        return {
            list: [],
            options: {
                // currentPage: 0,
                // thresholdDistance: 500,
                // thresholdTime: 100,
                autoplay: 3000,
                // loop: true,
                // directi
                on: 'vertical',
                // loopedSlides: 1,
                // slidesToScroll: 1,
                // timingFunction: 'ease',
                // speed: 300
            }
        }
    },
    computed: {
        listTemp: function () {
            let list = this.list;
            let arrTemp = [];
            let index = 0;
            let sectionCount = 3;
            for (var i = 0; i < list.length; i++) {
                index = parseInt(i / sectionCount);
                if (arrTemp.length <= index) {
                    arrTemp.push([]);
                }
                arrTemp[index].push(list[i]);
            }
            return arrTemp;
        }
    },
    mounted() {

        for (let index = 0; index < 12; index++) {
            let goods = { id: 1181062, name: "许留山菲律宾吕宋芒果干", brief: "", picUrl: "http://test19.qtopay.cn/wx/storage/fetch/gv1jer5vcs6ciedha1cw.jpg", retailPrice: 42.00 };
            let i = 0;
            i++;
            goods.name = `${index}${goods.name}`
            this.list.push(goods)
        }
    },
    methods: {
        // Listener event
        slide(data) {
        	
        },
        onTap(data) {
        	
        },
        onInit(data) {
        	
        }
    }

}
</script>

<style lang="less" scoped>
.slider {
  float: left;
}
.m-slider-item {
  display: block;
}
.slider-goods-item {
  width: 33.3333% !important;
  //   padding: 3px !important;
}
</style>
