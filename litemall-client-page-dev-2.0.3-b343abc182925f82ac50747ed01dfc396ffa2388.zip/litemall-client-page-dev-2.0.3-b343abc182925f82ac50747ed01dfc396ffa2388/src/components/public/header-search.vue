<template>
    <HeaderLayout class="search-page">

        <Xheader class="header-search header-fix" :noLoading="true" :headerStyle="headerStyle" :style="`background-color:rgba(255,255,255,${1});`" :left-options="{showBack:searchPageShow,preventGoBack:false}">
            <div class="search-box ub" @click="clickInput">
                <icon name="search" class="submit" scale="2"></icon>
                <input name="keyword" v-model="keyword" type="text" placeholder="搜索你想要的商品" class="text" value="">
                <icon name="close" class="submit" v-show="keyword" scale="2" @click.native="keyword = ''"></icon>
            </div>
            <Xbutton slot="right" mini v-show="searchPageShow" class="search-btn" type="warn" :show-loading="false" @click.native="$router.push({path:'/goods',query:{keyword,categoryId:1036009}})">搜索</Xbutton>
        </Xheader>

        <div class="search-container" v-show="searchPageShow">
            <div class="recent-search">
                <Ucell title="最近搜索">
                    <icon slot="desc" name="delete" scale="1.5"></icon>
                </Ucell>
                <ul class="content clearfix">
                    <li>
                        <a href="#">对讲机</a>
                    </li>
                </ul>
            </div>
            <div class="hot-search">
                <Ucell title="热门搜索"></Ucell>
                <ul class="content clearfix">
                    <li>
                        <a href="#">对讲机</a>
                    </li>
                </ul>
            </div>
        </div>
    </HeaderLayout>
</template>
<script>

import HeaderLayout from "@src/layouts/headerLayout.vue"
import Xheader from "@src/components/base/x-header"
import Xbutton from "@src/components/base/x-button"
import Ucell from '@src/components/base/u-cell'
import scrollOpacity from '@src/mixins/scroll-opacity.js'
import historyReplaceState from '@src/utils/history-replace-state.js'
export default {
    components: { HeaderLayout, Xheader, Xbutton, Ucell },
    data() {
        return {
            hotKeys: [],
            searchPageShow: false,
            headerStyle: "margin:0 15px;",
            keyword: "",
            searchPageShow: 0,
        }
    },
    mixins: [scrollOpacity],
    methods: {
        // open
        clickInput() {
            this.searchPageShow = true;
            this.cacheScroll = document.documentElement.scrollTop || document.body.scrollTop;
            document.documentElement.scrollTop = document.body.scrollTop = 0;
            this.headerStyle = "margin:0 70px;";
            // 增加历史
            historyReplaceState({ s: "1" }, "push");
            // 点击返回按钮时 关闭
            window.onpopstate = () => {
            	
                this.clickBack();
            }

            this.$emit("on-show-change", this.searchPageShow);
        },
        // close
        clickBack() {
            this.searchPageShow = false;
            this.keyword = "";
            this.headerStyle = "margin:0 15px;";
            this.$nextTick(() => {
                document.documentElement.scrollTop = document.body.scrollTop = this.cacheScroll;
            });
            // 关闭后清除事件
            window.onpopstate = null;

            this.$emit("on-show-change", this.searchPageShow);
        }
    }
}
</script>
<style lang='less' scoped>
.search-page {
  background: #fff;
  .header-search {
    .search-box {
      width: 100%;
      margin: 7px auto;
      height: 30px;
      background: #f6f6f6;
      border-radius: 15px;
      position: relative;
      display: flex;
      align-items: center;
      .text {
        display: block;
        width: 100%;
        -webkit-appearance: none;
        -webkit-box-flex: 1;
        -webkit-flex: 1;
        flex: 1;
        border-radius: 0;
        -webkit-rtl-ordering: logical;
        -webkit-user-select: text;
        height: 30px;
        background: none;
        border: 0;
        font-size: 14px;
        line-height: 30px;
        color: #666;
      }
      .submit {
        padding: 2px 5px 2px;
      }
    }
    .search-btn {
      margin-top: -5px;
    }
  }
  .search-container {
    background: #fff;
    color: #000;
    .content {
      padding: 10px;
      // display: flex;
      li {
        display: block;
        max-width: 100%;
        overflow: hidden;
        padding-right: 10px;
        padding-bottom: 10px;
        float: left;
        a {
          height: 23px;
          line-height: 24px;
          border-radius: 3px;
          display: block;
          width: 100%;
          color: #686868;
          white-space: nowrap;
          text-overflow: ellipsis;
          background-color: #f0f2f5;
          padding-left: 13px;
          padding-right: 13px;
          overflow: hidden;
          box-sizing: border-box;
          font-size: 12px;
        }
      }
    }
  }
}
</style>