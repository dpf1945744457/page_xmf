export default {
    beforeRouteLeave(to, from, next) {
        //如果当前是缓存路由的话
        if (from.meta.keepAlive) {
            console.warn("handle mixins：routeLeaveByisRoutePush function, keepAlive:true 缓存已开启！");
            to.meta.isRouterPush = true;
        }
        next();
    }
}