module.exports = file => () => import('@src/views/' + file + '.vue')
