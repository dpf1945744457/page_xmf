import Vue from 'vue'
import Toast from '@src/components/base/vue-toast-mobile'
Vue.prototype.$toast = Toast;