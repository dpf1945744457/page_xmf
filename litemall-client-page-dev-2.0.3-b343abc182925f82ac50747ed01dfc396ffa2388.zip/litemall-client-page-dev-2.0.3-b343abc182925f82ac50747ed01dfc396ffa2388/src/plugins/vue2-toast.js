import Vue from 'vue'
import '@src/components/base/toast/toast.css'
import Toast from '@src/components/base/toast/index.js'
Vue.use(Toast);
export default Toast;