

import wx from "weixin-js-sdk"
import { getWxSign } from '@src/apis/public.js'

console.log("加载wx-jssdk")