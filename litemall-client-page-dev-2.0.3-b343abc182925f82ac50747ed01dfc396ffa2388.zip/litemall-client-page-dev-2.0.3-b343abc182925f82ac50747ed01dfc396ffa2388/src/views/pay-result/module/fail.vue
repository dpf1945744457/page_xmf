<template>
    <div>
        <div class="payment-page">
            <div class="content-box">
                <p class="title fail">付款失败</p>
                <p>请在半小时内完成付款</p>
                <p> 否则订单将会被系统销毁</p>
            </div>
            <div class="button-group">
                <a class="button" @click="toOrder">
                    查看订单
                </a>
                <a class="button" @click="toPay">
                    重新付款
                </a>
            </div>
        </div>
    </div>

</template>
<script>
import "@src/assets/less/butcommon.less"
export default {
    components: {

    },
    props: [],
    head() { return {} },
    asyncData(context) { },
    data() { return {} },
    fetch() { },
    methods: {
        toOrder() {
            this.$router.replace('/order')
        },
        toPay() {
            this.$router.replace('/order/confirm')
        }
    }
}
</script>
<style lang='less' scoped>
.payment-page {
  background: #fff;
  padding: 40px 15px 10px;
  .content-box {
    text-align: center;
    p {
      line-height: 25px;
    }
    .title {
      font-size: 18px;
      // font-weight: bold;
      padding: 10px 0;
      &.fail {
        color: #e0443b;
      }
    }
  }
  .button-group {
    display: flex;
    flex-direction: row;
    height: 36px;
    justify-content: space-around;
    align-items: center;
    margin-top: 36px;
    .button {
      border: 1px solid #868686;
      border-radius: 5px;
      padding: 0 30px;
      height: 36px;
      line-height: 36px;
    }
  }
}
</style>