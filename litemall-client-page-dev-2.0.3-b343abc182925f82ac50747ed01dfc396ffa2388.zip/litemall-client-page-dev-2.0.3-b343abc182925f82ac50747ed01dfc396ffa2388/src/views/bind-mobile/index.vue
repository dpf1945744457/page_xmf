<template>
  <HeaderLayout>
    <Xheader class="header header-fix">{{$route.meta.title}}</Xheader>
    <Uinput phoneShow label="手机区域" v-on:getAreaId="getId" v-on:showBacks="getBack"></Uinput>
    <Uinput
      class="m-t-5"
      ref="mobileIpt"
      label="手机号"
      type="tel"
      v-model="mobile"
      placeholder="请输入手机号"
      :topLine="true"
      :maxLength="11"
    ></Uinput>
    <Uinput
      label="验证码"
      type="tel"
      v-model="code"
      placeholder="请输入验证码"
      :topLine="true"
      :maxLength="6"
      width="50%"
    >
      <TimerBtn ref="TimerBtn" :text="'发送验证码'" :time="60" :cb="sendCode"></TimerBtn>
    </Uinput>
    <Xbutton class="btn" type="warn" @click.native="login">绑定手机</Xbutton>
  </HeaderLayout>
</template>

<script>
import HeaderLayout from "@src/layouts/headerLayout.vue";
import Xheader from "@src/components/base/x-header";
import Xbutton from "@src/components/base/x-button";

import Uinput from "@src/components/base/u-input";
import TimerBtn from "@src/components/base/timer-btn";
import { getRegCode } from "@src/apis/user.js";
import { mapState, mapActions, mapGetters } from "vuex";
import regExp from "@src/utils/regExp.js";
import { setStorage, getStorage, removeStorage } from "@src/utils/storage.js";

export default {
  components: { HeaderLayout, Xheader, Xbutton, Uinput, TimerBtn },
  data() {
    return {
      redirectUrl: this.$route.query["redirect"],
      mobile: "",
      code: "",
      areaId: "",
    };
  },
  mounted() {
    setTimeout(() => {
      this.$iosAlert({
        title: "安全认证",
        text: "为了您的账户安全，请先绑定手机号",
        okText: "好的",
        appendChildClass: "#page",
      }).then(() => {
        this.$refs.mobileIpt.focus();
      });
    }, 500);
  },
  methods: {
    ...mapActions(["bindMobile"]),
    sendCode() {
      //          if (!regExp.mobile.reg.test(this.mobile)) {
      //              this.$toast(regExp.mobile.errMsg);
      //              return false;
      //          }

      getRegCode({ areaCode: this.areaId, phone: this.mobile }).then((res) => {
        if (res.data.errno == 401) {
          this.$toast(res.data.errmsg);
        } else {
          this.$refs.TimerBtn.disabled = true;
          this.$refs.TimerBtn.timer();
          this.$toast({
            message: "发送验证码成功",
            iconClass: "icon-success_black",
          });
        }
      });
    },
    async login() {
      //          if (!regExp.mobile.reg.test(this.mobile)) {
      //              this.$toast(regExp.mobile.errMsg);
      //              return false;
      //          }
      if (!this.code) {
        this.$toast("请输入验证码");
        return false;
      }
      console.log( this.areaId);
      let isSuccess = await this.bindMobile({
        phone: this.mobile,
        code: this.code,
        areaCode: this.areaId,
      });
      if (isSuccess) {
       this.$router.go(-1)
      }
    },
    getId(data) {
      console.log(data);
      this.areaId = data;
      this.mobile = "";
    },
    getBack(data) {
      this.back = data;
    },
  },
};
</script>

<style lang="less" scoped>
.btn {
  width: 95%;
  margin: 30px auto;
  background: #ffdf00;
  color: #000;
}
</style>
