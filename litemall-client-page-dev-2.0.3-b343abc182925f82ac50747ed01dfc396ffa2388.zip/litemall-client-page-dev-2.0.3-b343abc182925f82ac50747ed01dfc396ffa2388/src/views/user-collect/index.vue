<template>
    <HeaderLayout v-infinite-scroll="loadMore" infinite-scroll-immediate-check="false" infinite-scroll-disabled="infiniteDisabled" infinite-scroll-distance="80">
        <Xheader class="header-fix" :title="$route.meta.title"></Xheader>

        <div class="product-list clearfix">
            <GoodsItem style="top: 0" v-for="(item,index) in list" :key="index" :item="{name:item.name,picUrl:item.picUrl,retailPrice:item.retailPrice,brief:item.brief,id:item.valueId,merName:item.merName}"></GoodsItem>
        </div>

        <div>
            <LoadMore v-if="status=='请求中'" tip="正在加载" :showLoading="true"></LoadMore>
            <LoadMore v-if="status=='没有更多'" tip="没有更多了" :showLoading="false"></LoadMore>
            <LoadMore v-if="status=='请求失败'" tip="加载失败，点我重试" :showLoading="false" @click.native="loadMore"></LoadMore>
            <Nodata v-if="status=='暂无数据'" :imgurl="require('@src/assets/img/bg_empty_data.png')" content='暂无收藏记录'></Nodata>
        </div>
    </HeaderLayout>
</template>

<script>
import HeaderLayout from "@src/layouts/headerLayout.vue"
import Xheader from "@src/components/base/x-header"
import Nodata from "@src/components/base/no-data"
import GoodsItem from '@src/components/base/goodsItem/index.vue'
import LoadMore from "@src/components/base/load-more"
import Xbutton from "@src/components/base/x-button"
import { getUserCollectList } from '@src/apis/user.js'
import routeLeaveByisRoutePush from '@src/mixins/routeLeaveByisRoutePush.js'
import infiniteScroll from '@src/directives/vue-infinite-scroll'
export default {
    directives: { infiniteScroll },
    components: { HeaderLayout, Xheader, Nodata, GoodsItem, LoadMore, Xbutton },
    mixins: [routeLeaveByisRoutePush],
    async beforeRouteEnter(to, from, next) {
//      if (['product-detail'].indexOf(from.name) !== -1 && from.meta.isRouterPush) {
//          next();
//      } else {
            let query = { type: 0, page: 1, size: 10 };
            let data = await getUserCollectList(query);
            next(vm => {
                vm.list = [];
                vm.query = query;
                vm.setData(data)
            })
//      }
    },
    computed: {
        infiniteDisabled() {
            return this.status == '请求中' || this.status == '没有更多' || this.status == '暂无数据' || this.status == '请求失败';
        }
    },
    data() {
        return {
            status: "",
            list: [],
        }
    },
    methods: {
        async loadMore($state) {
            this.status = "请求中";
            try {
                let data = await getUserCollectList(this.query);
                this.setData(data);
            } catch (error) {
                this.status = "请求失败";
            }
        },
        setData(data) {
            this.list = this.list.concat(data.collectList);
            // 是否有更多数据
            if (this.list.length === 0) {
                this.status = "暂无数据";
            } else if (this.query.page >= data.totalPages) {
                this.status = "没有更多";
            } else {
                this.status = "请求更多";
                this.query.page++;

            }
        },
        // 筛选收藏的商品：0 或者 专题：1
        filterByType(type) {

        },
    }
}
</script>

<style lang="less" scoped>
</style>
