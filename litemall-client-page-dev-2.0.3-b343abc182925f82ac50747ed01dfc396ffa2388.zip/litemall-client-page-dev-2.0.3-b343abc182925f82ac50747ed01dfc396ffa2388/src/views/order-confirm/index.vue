<template>
  <HeaderLayout>
    <!-- <Xheader class="top-fixed" :left-options="{preventGoBack:isBack}" @on-click-back="preventGoBack"> -->
    <Xheader class="top-fixed">订单确认</Xheader>
    <!-- <Nodata v-if="noDataVisible" :imgurl="require('@src/assets/img/cart/bg_empty_data.png')" content='还没有未付款的订单'></Nodata> -->
    <div class="order-confirm-page">
      <div class="bottom-50">
        <!-- 地址选择 -->
        <addAdressBut @click.native="addAddress" v-if="!addressVisible"></addAdressBut>
        <address-check
          @click.native="selectAddress"
          v-if="addressVisible"
          :address="addressData"
          :isLink="true"
        ></address-check>
        <div class="img-line-back"></div>
        <!-- 优惠券 -->
        <linkbutton
          v-if="false"
          class="m-t-10 bottom-10"
          lable="请选择优惠券"
          :content="allData.checkedCoupon+'张'"
          :icon="true"
        ></linkbutton>
        <!-- 商品列表 -->
        <productList :list="prolist"></productList>
        <!-- <priceDetail class="m-t-10" :allData="allData"></priceDetail> -->
        <!--<Uinput class="m-t-10 name" 
                        label="支付人姓名" 
                        v-model="allData.realName"  
                        :bottomLine="true" 
                        placeholder="必填" 
                        maxLength="20"
                        @blur="onBlur"
                        >
                </Uinput>
                <Uinput label="支付人身份证" v-model="allData.personId" :bottomLine="true" placeholder="必填" maxLength="18"></Uinput>
        <p class="tips">请填写真实姓名和身份证用于进口商品清关，信息将被加密保存</p>-->
        <!-- 用户留言 -->
        
        <message label="买家留言" v-model="payPersonInfo.leavingMessage" class="m-t-0" placeholder="选填"></message>
       
      </div>
      <!-- <footerBut :label="'应付款：'" :buttext="'去付款'" :btnLoading="btnLoading" @submitHandle="submitHandle1" :price="allData.actualPrice+''"></footerBut> -->
      <footerBut
        :label="'应付款：'"
        :buttext="'去付款'"
        :btnLoading="btnLoading"
        @submitHandle="submitHandle"
        :price="allData.actualPrice+''"
      ></footerBut>
    </div>
    <div id="form-box"></div>
  </HeaderLayout>
</template>
<script>
import HeaderLayout from "@src/layouts/headerLayout.vue";
import Xheader from "@src/components/base/x-header-slot";
import Nodata from "@src/components/base/no-data";
import Xbutton from "@src/components/base/x-button";
import footerBut from "./module/footerBut";
import addAdressBut from "./module/addAdressBut";
import productList from "./module/productList";
import addressCheck from "./module/addressCheck";
import message from "./module/message";
import priceDetail from "./module/priceDetail";
import linkbutton from "@src/components/base/linkbutton";
import Uinput from "@src/components/base/u-input";
import $ from "jquery";
import {
  getConfirmOrder,
  postSubmitOrder,
  postPrepayOrder,
  formSubmitOrder
} from "@src/apis/order.js";
import { getAddressData } from "@src/apis/address.js";
import "@src/assets/less/butcommon.less";
import { getToken, setToken, removeToken } from "@src/utils/auth.js";
import { cityCode } from "@src/utils/cityCode.js";
import { getStorage, setStorage, removeStorage } from "@src/utils/storage.js";
import regExp from "@src/utils/regExp.js";
export default {
  name: "order-confirm",
  components: {
    HeaderLayout,
    Xheader,
    Xbutton,
    Nodata,
    footerBut,
    addAdressBut,
    productList,
    addressCheck,
    message,
    linkbutton,
    priceDetail,
    Uinput
  },
  data() {
    return {
      routerPath: "",
      isReload: false,
      isBack: true,
      cityJson: [], // 省市区数据
      getToken: getToken(),
      orderId: 0,
      noDataVisible: false,
      haveDataVisible: false,
      addressVisible: false,
      addressData: {
        name: "",
        address: "",
        mobile: ""
      },
      prolist: [
        {
          storename: "",
          goodsName: "",
          price: "",
          number: ""
        }
      ],
      // 获取购物车ID 0代表默认购物车
      cartId: this.$route.query["cartId"] || 0,
      addressId: this.$route.query["addressId"] || 0,
      allData: {
        goodsTotalPrice: 0.0, //商品总价
        freightPrice: 0.0, //快递费
        tariffPrice: 0.0, //快递费
        couponPrice: 0.0, //优惠券的价格
        grouponPrice: 0.0, //团购优惠价格
        orderTotalPrice: 0.0, //订单总价
        actualPrice: 0.0, //实际需要支付的总价
        couponId: 0,
        grouponLinkId: 0, //参与的团购，如果是发起则为0
        grouponRulesId: 0, //团购规则ID,
        realName: "", //支付人姓名
        personId: "" /*支付人身份证*/
      },
      btnLoading: false, // 按钮loading

      // 支付人信息
      // payPersonInfo: getStorage("payPersonInfo")
      payPersonInfo: {}
    };
  },
  async beforeRouteEnter(to, from, next) {
    let that = this;
    let cartId = to.query.cartId || 0;
    let addressId = to.query.addressId || 0;
    let data = await getConfirmOrder({
      cartId: cartId,
      addressId: addressId,
      couponId: 0,
      grouponRulesId: 0,
      redirect: to.fullPath
    });

    let cityJson = await getAddressData();
    next(vm => {
      vm.routerPath = to.path;
      vm.cityJson = cityJson;
    });
    if (!data.errno) {
      next(vm => {
        vm.setData(data);
      });
    } else {
      next(vm => {
        vm.$toast(data.errmsg);
      });
    }
  },
  // async created() {
  //     let cartId = this.$route.query.cartId || 0;
  //     let addressId = this.$route.query.addressId || 0;
  //     let data = await getConfirmOrder({ cartId: cartId, addressId: addressId, couponId: 0, grouponRulesId: 0 })
  //     let cityJson = await getAddressData();
  //     this.routerPath = this.$route.path;
  //     this.cityJson = cityJson;
  //     this.setData(data)
  // },
  mounted() {
    window.addEventListener("pageshow", this.pageshowHandle);
  },
  methods: {
    pageshowHandle() {
      if (this.isReload && this.routerPath == "/cart/confirm") {
        window.location.reload();
      }
    },
    // submitHandle1() {
    //     window.location.href = "http://192.168.253.1:8070/test1.html"
    // },

    // 权限验证（支付人姓名）
    formRules() {
      return new Promise((resolve, reject) => {
        if (!this.addressVisible) {
          return reject("请先选择收货地址");
        }
        //              if(!this.allData.realName) {
        //                  return reject(`支付人姓名不能为空`)
        //
        //              } else {
        ////                  if (!regExp.name.reg.test(this.allData.realName)) {
        ////                      return reject(regExp.name.errMsg)
        ////                  }
        //              }
        //              if(!this.allData.personId) {
        //                  return reject(`支付人身份证不能为空`)
        //              } else {
        //                  if (!regExp.personId.reg.test(this.allData.personId)) {
        //                      return reject(regExp.personId.errMsg)
        //                  }
        //              }
        resolve("符合表单输入规则");
      });
    },

    // 失焦
    onBlur() {
      // 校验支付人姓名信息
      if (!this.allData.realName) {
        this.$toast(`支付人姓名不能为空`);
      } else {
        //              if (!regExp.name.reg.test(this.allData.realName)) {
        //                  this.$toast(regExp.name.errMsg)
        //              }
      }
    },

    // 表单提交
    async submitHandle() {
      // 校验支付人信息

      // if(this.allData.realName){
      // 	if (!regExp.name.reg.test(this.allData.realName)) {
      //         this.$toast(regExp.name.errMsg);
      //         return;
      //     }
      // }

      // else{
      // 	if (!regExp.name.reg.test(this.payPersonInfo.realName) && this.payPersonInfo.realName == '') {
      //         this.$toast(regExp.name.errMsg);
      //         return;
      //     }
      // }

      // if(this.allData.personId){
      // 	if (!regExp.personId.reg.test(this.allData.personId)) {
      //         this.$toast(regExp.personId.errMsg);
      //         return;
      //     }
      // }
      // else{
      // 	if (!regExp.personId.reg.test(this.payPersonInfo.personId)) {
      //         this.$toast(regExp.personId.errMsg);
      //         return;
      //     }
      // }

      // 缓存支付人信息
      // setStorage("payPersonInfo", {
      //     realName: this.allData.realName || this.payPersonInfo.realName,
      //     personId: this.allData.personId || this.payPersonInfo.personId,
      // });

      // if (!this.addressVisible) {
      //     this.$toast("请先选择收货地址");
      //     return false
      // }

      let sendData = {
        cartId: this.cartId,
        addressId: this.addressData.id,
        couponId: this.allData.couponId,
        detailAddress: this.addressData.address,
        leavingMessage:this.payPersonInfo.leavingMessage,
        // 导入支付人信息
        // ...this.payPersonInfo
        realName: this.allData.realName,
        personId: this.allData.personId
      };

      // if (this.allData.actualPrice > 5000) {
      //   this.$iosAlert({
      //     title: "提示",
      //     text: "根据相关政策，购买跨境商品，单次金额不能大于5000元。",
      //     okText: "知道了",
      //     appendChildClass: "#page"
      //   });
      //   return;
      // }
      this.btnLoading = true;
      try {
        await this.formRules();

        this.isReload = true;
        let data = await postSubmitOrder(sendData);

        if (
          data.errno != undefined &&
          (data.errno == "403" || data.errno == "401")
        ) {
          this.$toast(data.errmsg);
          this.btnLoading = false;
        }

        if (data.shipmentRegion) {
          window.location.href = data.url;
        } else {
          $("#form-box").html(data);
        }

        if (this.routerPath == "/cart/confirm") {
          // 点击回退按钮返回则跳转到订单未付款页面
          history.replaceState(
            null,
            null,
            location.origin + location.pathname + "#/order?showType=1"
          );
        }
      } catch (error) {
        this.$toast(error);
        this.btnLoading = false;
        this.isReload = true;
      }
    },
    //地址管理
    selectAddress() {
      this.$router.push({
        path: "/address",
        query: {
          canSelect: "TRUE",
          backPath: "/cart/confirm",
          ...this.$route.query
        }
      });
    },
    // 新增地址
    addAddress() {
      this.selectAddress();
    },
    // 初始化数据
    setData(data) {
      if (data) {
        let key = parseInt(this.$route.query.key);
        //              if(key === 1){
        //                for(let i in { ...data.checkedGoodsList }){
        //                  if(data.checkedGoodsList[i].shipmentRegion === 1){
        //                    this.prolist.push({ ...data.checkedGoodsList[i] }) ;
        //                  }
        //                }
        //              }else if(key === 0){
        //                for(let i in { ...data.checkedGoodsList }){
        //
        //                  if(data.checkedGoodsList[i].shipmentRegion === 0){
        //                    this.prolist.push({ ...data.checkedGoodsList[i] }) ;
        //                  }
        //                }
        //              }
        //				this.prolist.push({ ...data.checkedGoodsList}) ;
        this.prolist.shift();
        this.prolist = { ...data.checkedGoodsList };

        this.$set(this.$data, "allData", data);
        if (data.checkedGoodsList && data.checkedGoodsList.length > 0) {
          // this.noDataVisible = false;
          // this.haveDataVisible = true;
          this.initAddressData(data.checkedAddress);
        } else {
          // this.noDataVisible = true;
          // this.haveDataVisible = false;
          // this.$router.replace({ path: "/order", query: { showType: 1 } })
        }
      }
    },
    // 初始化地址
    initAddressData(checkedAddress) {
      this.addressData = { ...checkedAddress };
      if (this.addressData.id == 0) {
        this.$iosConfirm({
          title: "提示",
          text: "您还没有选择收货地址，现在去选择收货地址吗？",
          appendChildClass: "#page"
        }).then(this.addAddress);
        return;
      }
      this.addressVisible = true;
      let provinceName = cityCode(this.cityJson, this.addressData.provinceId);
      let cityName = cityCode(this.cityJson, this.addressData.cityId);
      let areaName = cityCode(this.cityJson, this.addressData.areaId);
      this.addressData.address =
        provinceName + cityName + areaName + this.addressData.address;
    }
  }
};
</script>
<style lang='less' scoped>
.order-confirm-page {
  padding-bottom: 30px;
  .tips {
    font-size: 12px;
    color: #e64340;
    background: #fff;
    padding: 10px;
  }
}
.order-confirm-page /deep/ .form-group dl dd {
}
.name {
  border-top: 1px solid #eee;
}
</style>
