<template>
    <div class="pro-list-page com-top-1px com-bottom-1px side-distance m-t-10">
        <ul class="pro-list">
            <li class="list com-bottom-1px" v-for="(item,index) in list" :key="index">
                <!-- <div class="storename">
                    {{item.name}}
                </div> -->
                <div class="pro-box">
                    <div class="pic-back">
                        <img :src="item.picUrl" alt="">
                    </div>
                    <div class="product">
                        <div class="intro-box">
                            <p class="intro">
                                {{item.goodsName}}
                            </p>
                        </div>

                        <p class="sale">
                            <span class="money red-text">HK${{item.price | filterPrice}}</span>
                            <span class="count">x{{item.number}} </span>
                        </p>
                        <div class="tip-box">
                            <span v-for="(tip,index) in item.specifications" class="tip" :key="index">{{tip}}</span>
                            <span v-if="item.freeShipping == 1" class="tip c">包邮</span>
                        </div>
                    </div>
                </div>
                <priceDetail class="m-t-10" :allData="item"></priceDetail>
            </li>
        </ul>
    </div>
</template>
<script>
import priceDetail from "./priceDetail";
export default {
    props: ["list", "specifications"],
    components: {priceDetail},
    head() { return {} },
    asyncData(context) { },
    data() { return {} },
    fetch() { },
    methods: {},
    filters: {
		filterPrice: function(num) {
			return Number(num).toFixed(2);
		}
	},
}
</script>
<style lang='less' scoped>
.pro-list-page {
  background: #fff;

  .pro-list {
    position: relative;

    .list {
      padding: 15px 0;
      .storename {
        padding: 10px 0px;
      }
      .pro-box {
        display: flex;
        flex-direction: row;
        .pic-back {
          width: 80px;
          height: 80px;
          //   flex: 0 0 100px;
          //   background: #f3f5f7;
          text-align: center;
          &:after {
            content: " ";
            display: inline-block;
            height: 100%;
            vertical-align: middle;
          }
          img {
            vertical-align: middle;
            max-width: 100%;
            max-height: 100%;
          }
        }
        .product {
          flex: 1;
          display: flex;
          flex-direction: column;
          justify-content: flex-end;
          overflow: hidden;
          padding: 0 10px;
          .intro-box {
            flex: 1;
            .intro {
              display: -webkit-box;
              -webkit-box-orient: vertical;
              -webkit-line-clamp: 2;
              overflow: hidden;
              color: #222;
            }
          }
          .sale {
            flex: 0 0 30px;
            // align-self: flex-end;
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
            .red-text {
              color: #e0443b;
            }
          }
          .tip-box {
            display: flex;
            flex-direction: row;
            .tip {
            	display: inline-block;
              border: 1px solid #e0443b;
              font-size: 10px;
              color: #e0443b;
              border-radius: 5px;
              padding: 0 5px;
              flex: 0 0 1;
              white-space: normal;
              text-align: center;
              margin-right: 2px;
              height: 20px;
				line-height: 20px;
				box-sizing: border-box;
            }

            .c {
              border: 1px solid #ff5d02;
              color: #ffffff;
              background: #ff5d02;
            }
          }
        }
      }
    }
  }
}
</style>