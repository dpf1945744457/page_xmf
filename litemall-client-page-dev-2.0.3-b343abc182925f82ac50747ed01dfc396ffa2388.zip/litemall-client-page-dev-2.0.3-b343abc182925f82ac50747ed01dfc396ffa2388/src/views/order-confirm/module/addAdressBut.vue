<template>
    <div @click="addAdressHandle" class="add-bar-but side-distance">
        <div class="text-box">
            <icon class="plugcircle" scale="1.8" name="plugcircle"></icon>
            选择收货地址
        </div>
        <icon scale="2" name="linkright"></icon>
    </div>
</template>

<script>
import Xheader from "@src/components/base/x-header"
import Uinput from "@src/components/base/u-input"
import Xbutton from "@src/components/base/x-button"
import "@src/assets/less/butcommon.less"
export default {

    components: { Xheader, Uinput, Xbutton },
    props: ["list"],
    methods: {
        addAdressHandle() {
            this.$emit("addAdressHandle")
        }
    }
}
</script>

<style lang="less" scoped>
.add-bar-but {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  background: #fff;
  height: 46px;
  .text-box {
    flex: 1;
    .plugcircle {
      transform: translateY(2px);
    }
  }
}
</style>
