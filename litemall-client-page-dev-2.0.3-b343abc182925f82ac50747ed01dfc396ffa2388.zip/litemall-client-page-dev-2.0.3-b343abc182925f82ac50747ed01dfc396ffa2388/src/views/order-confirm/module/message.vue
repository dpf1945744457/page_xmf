<template>
  <div class="top-10">
    <Utextarea v-model="currentValue" :label="label" :placeholder="placeholder" :topLine="true" maxLength="200"></Utextarea>
  </div>
</template>
<script>
import "@src/assets/less/butcommon.less"
import Utextarea from "@src/components/base/u-textarea"
export default {
  props: [
    "label",
    "placeholder",
    "value"
  ],
  data() {
    return {
      currentValue: ""
    }
  },
  mounted() {
    if (this.value) {
      this.currentValue = this.value;
    }
  },
  components: { Utextarea },
  head() { return {} },
  asyncData(context) { },
  fetch() { },
  watch: {
    currentValue(val) {
      this.$emit('input', val);
    }
  },
  methods: {}
}
</script>
<style lang='less' scoped>
</style>