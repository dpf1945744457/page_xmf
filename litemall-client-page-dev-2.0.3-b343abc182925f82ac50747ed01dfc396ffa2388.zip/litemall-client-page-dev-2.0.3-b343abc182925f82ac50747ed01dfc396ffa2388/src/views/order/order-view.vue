<template>
    <HeaderLayout v-infinite-scroll="loadMore" infinite-scroll-immediate-check="true" infinite-scroll-disabled="infiniteDisabled" infinite-scroll-distance="50">
        <OrderList :list="orderList"></OrderList>
        <div style="min-height:100px; overflow: hidden;">
            <LoadMore v-if="status=='请求中'" tip="努力加载中" :showLoading="true"></LoadMore>
            <LoadMore v-if="status=='没有更多'" tip="没有更多了" :showLoading="false"></LoadMore>
            <LoadMore v-if="status=='请求失败'" tip="加载失败，点我重试" :showLoading="false" @click.native="loadMore"></LoadMore>
            <Nodata v-if="status=='暂无数据'" :imgurl="require('@src/assets/img/bg_empty_data.png')" content='您还没有相关的订单'></Nodata>
        </div>
    </HeaderLayout>
</template>
<script>
import HeaderLayout from "@src/layouts/headerLayout.vue"
import Nodata from '@src/components/base/no-data'
import OrderList from './module/order-list'
import { getOrderList } from '@src/apis/order.js'
import infiniteScroll from '@src/directives/vue-infinite-scroll'
import LoadMore from "@src/components/base/load-more"

export default {
    directives: { infiniteScroll },
    components: { HeaderLayout, OrderList, Nodata, LoadMore },
    props: ["showType"],
    data() {
        return {
            status: "",
            orderList: [],
            // showType: this.$route.query["showType"] || 0,
            query: { page: 1, size: 5 },
            scroll: {}
        }
    },
    computed: {
        infiniteDisabled() {
            return this.status == '请求中' || this.status == '没有更多' || this.status == '暂无数据' || this.status == '请求失败';
        }
    },
    methods: {
        async loadMore(append = true) {
            try {
                if (append) this.status = "请求中";// 滚动加载时使用显示loadMore的loading
                else this.$store.dispatch('openGlobalLoading');// 点击tab 显示全局loading
                let data = await getOrderList({ showType: this.showType, ...this.query });
                this.setData(data, { append });
            } catch (error) {
                this.status = "请求失败";
            }
        },
        setData(data, options = {}) {
            if (options.append) this.orderList = this.orderList.concat(data.data);
            else this.orderList = data.data;
            if (this.orderList.length === 0) {
                this.status = "暂无数据";
            } else if (this.query.page >= data.totalPages) {
                this.status = "没有更多";
            } else {
                this.status = "请求更多";
                this.query.page++;
            }
        },
        handleScroll() {
            let scrollTop = document.body.scrollTop || document.documentElement.scrollTop;
            this.scroll[this.showType] = scrollTop;
        }
    },
    activated() {
        window.scrollTo(0, this.scroll[this.showType]);
        window.addEventListener('scroll', this.handleScroll);
    },
    deactivated() {
        window.removeEventListener('scroll', this.handleScroll);
    }

}
</script>
<style lang='less' scoped>
</style>