<template>
  <div class="order-list">
    <div
      class="m-t-10 item com-top-1px com-bottom-1px"
      v-for="(item, index) in list"
      :key="index"
      @click="$router.push(`/order/${item.id}`)"
    >
      <p class="row">
        <span class="title">订单编号：{{ item.orderSn }}</span>
        <span class="f-r" :class="{ red: item.orderStatusText == '未付款' }">{{ item.orderStatusText }}</span>
      </p>
      <a
        href="javascript:void(0);"
        class="product-box com-bottom-1px"
        v-for="(item1, index) in item.goodsList"
        :key="index"
      >
        <div class="pic">
          <img :src="item1.picUrl" alt />
        </div>
        <div class="left">
          <p>
            {{ item1.goodsName }}
            <span
              class="f-r"
              v-if="item1.status"
              style="color:red;float: right;"
            >缺货</span>
          </p>
          <small>共{{ item1.number }}件商品</small>
          <p v-if="item1.status " style="color:red;">缺货说明:{{item1.remark}}</p>
        </div>
      </a>
      <p style="color:red" v-if="item.orderStatusText == '缺货'">*缺货说明：{{ item.remark }}</p>
      <p style="color:red" v-if="item.remark">*拒绝退款原因：{{ item.remark }}</p>
      
      <div class="row">
        <span class="title">实付：HK${{ item.actualPrice | filterPrice}}</span>
        <Xbutton
          mini
          v-if="item.orderStatusText == '已发货'"
          :show-loading="false"
          class="d-btn weui-btn_inline weui_btn_nopay"
          @click.native.stop="postOrderConfirm(item.id)"
          type="warn"
        >确认收货</Xbutton>
        <Xbutton
          mini
          v-if="(item.orderStatusText == '已付款'||item.orderStatusText == '缺货') && item.handleOption.refund == true"
          :show-loading="false"
          class="d-btn weui-btn_inline"
          @click.native.stop="postOrderRefund(item.id)"
        >申请退款</Xbutton>
        <Xbutton
          mini
          v-if="item.orderStatusText == '已申请退款'&& item.handleOption.cancelRefund == true "
          :show-loading="false"
          class="d-btn weui-btn_inline"
          @click.native.stop="noOrderRefund(item.id)"
        >取消退款</Xbutton>
        <Xbutton
          mini
          v-if="item.orderStatusText == '未付款'"
          :show-loading="false"
          class="d-btn weui-btn_inline"
          @click.native.stop="postOrderCancel(item.id)"
        >取消订单</Xbutton>
        <Xbutton
          mini
          v-if="item.orderStatusText == '未付款'"
          :show-loading="false"
          class="d-btn weui-btn_inline weui_btn_nopay"
          @click.native.stop="postPrepayOrder(item.id)"
          type="warn"
        >去付款</Xbutton>
        <Xbutton
          mini
          v-if="item.orderStatusText == '待评价'"
          class="d-btn weui-btn_inline weui_btn_nopay"
          @click.native.stop="$router.push({ path: `/order/${item.id}/comment` })"
          type="warn"
        >去评价</Xbutton>
      </div>
    </div>
    <div id="form-box"></div>
  </div>
</template>
<script>
import Xbutton from "@src/components/base/x-button";
import $ from "jquery";

import {
  getOrderDetail,
  postPrepayOrder,
  postOrderCancel,
  postOrderRefund,
  postOrderConfirm,
  cancelRefund,
} from "@src/apis/order.js";
import { mapState, mapActions, mapGetters } from "vuex";
export default {
  name: "order-list",
  components: { Xbutton },
  props: ["list"],
  data() {
    return {
      btnLoading: false,
    };
  },
  filters: {
    filterPrice: function (num) {
      return Number(num).toFixed(2);
    },
  },
  computed: {
    ...mapGetters(["showLoading"]),
  },
  methods: {
    // 用户点击去付款
    async postPrepayOrder(orderId) {
      //      	alert("orderId: "+orderId)
      try {
        this.btnLoading = true;
        let data = await postPrepayOrder({ orderId });
        if (data.shipmentRegion) {
          //window.location.href = data.url + "?urlPath=" + this.$route.fullPath;
          window.location.href = data.url;
          // window.open(data.url )
        } else {
          $("#form-box").html(data);
        }
      } catch (error) {
        this.btnLoading = false;
      }
    },
    // 用户点击取消订单
    postOrderCancel(orderId) {
      this.$iosConfirm({
        title: "取消订单",
        text: "确定要取消此订单吗？",
        cancelText: "再想想",
        okText: "确定",
        appendChildClass: "#page",
      }).then(async () => {
        let res = await postOrderCancel({ orderId });
        if (res.errno == 0) {
          let order = this.list.find((item) => item.id == orderId);
          order.orderStatusText = "已取消";
          window.location.reload();
        } else {
          this.$toast(res.errmsg);
        }
      });
    },
    // 用户点击申请退款
    postOrderRefund(orderId) {
      this.$iosConfirm({
        title: "退款确认",
        text: "好货不等人，您确定要申请退款吗？",
        cancelText: "再想想",
        okText: "确定",
        appendChildClass: "#page",
      }).then(async () => {
        let res = await postOrderRefund({ orderId });
        if (res.errno == 0) {
          let order = this.list.find((item) => item.id == orderId);
          order.orderStatusText = "已申请退款";
          order.handleOption.cancelRefund=true
          this.$iosAlert({
            title: "提交成功",
            text:
              "退款申请成功，我们会在2个工作日内为您办理退款程序，请您保持电话畅通",
            okText: "知道了",
            appendChildClass: "#page",
          });
        } else {
          this.$toast(res.errmsg);
        }
      });
    },
    noOrderRefund(orderId) {
      cancelRefund({ orderId })
        .then((res) => {
          if (res.errno == 0) {
            let order = this.list.find((item) => item.id == orderId);
            order.handleOption.refund=true
            order.orderStatusText = "已付款";
             this.$iosAlert({
            title: "提交成功",
            text:
              "已取消退款",
            okText: "知道了",
            appendChildClass: "#page",
          });
          } else {
            this.$toast(res.errmsg);
          }
        })
        .catch((error) => {
          Message({
            message: error.errmsg,
            type: "error",
          });
        });
    },
    // 用户点击确认收货
    async postOrderConfirm(orderId) {
      let res = await postOrderConfirm({ orderId });
      this.$router.push({ path: `/order/${orderId}/comment` });
    },
  },
};
</script>
<style lang="less" scoped>
.order-list {
  .item {
    background: #fff;
    padding: 0 10px;
    box-sizing: border-box;
  }

  .row {
    padding: 10px 0;
    display: flex;
    align-items: center;
    .title {
      flex: 1;
    }
    .f-r {
      float: right;
    }
    .red {
      color: #f23030;
    }
  }

  .product-box {
    padding: 10px 0;
    display: flex;
    .pic {
      width: 50px;
      height: 50px;
      img {
        width: 100%;
        height: 100%;
      }
    }

    .left {
      margin-left: 10px;
      flex: 1;
      p {
        color: #000;
      }
    }
  }

  .d-btn {
    // float: right;
    // padding: 4px 13px;
    // margin-left: 10px;
    // color: #131313;
    // font-size: 12px;
    // border: 1px solid #9a9a9a;
    // border-radius: 2000px;
  }
  .d-red {
    // color: #ff0000;
    // border: 1px solid #ff0505;
  }

  /deep/ .weui-btn_disabled.weui-btn_warn {
    /*background-color: #f6662e !important;*/
    color: rgba(255, 255, 255, 1);
  }
  .weui_btn_nopay {
    background-color: #f7cf20 !important;
  }
}
</style>
