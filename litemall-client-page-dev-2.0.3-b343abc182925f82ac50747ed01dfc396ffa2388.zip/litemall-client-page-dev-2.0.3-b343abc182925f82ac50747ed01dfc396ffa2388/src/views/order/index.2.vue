<template>
    <HeaderLayout v-infinite-scroll="loadMore" infinite-scroll-immediate-check="true" infinite-scroll-disabled="infiniteDisabled" infinite-scroll-distance="50">
        <Xheader class="header-fix" :title="$route.meta.title" :left-options="{preventGoBack:true}" @on-click-back="$router.replace('/user')"></Xheader>

        <tab class="header-fix" style="top: 47px;">
            <tab-item @click.native="getOrderList(0)" :selected="showType == 0">全部</tab-item>
            <tab-item @click.native="getOrderList(1)" :selected="showType == 1">待付款</tab-item>
            <tab-item @click.native="getOrderList(2)" :selected="showType == 2">待发货</tab-item>
            <tab-item @click.native="getOrderList(3)" :selected="showType == 3">待收货</tab-item>
            <tab-item @click.native="getOrderList(4)" :selected="showType == 4">待评价</tab-item>
        </tab>

        <OrderList style="margin-top:47px;" :list="orderList"></OrderList>

        <div style="min-height:100px; overflow: hidden;">
            <LoadMore v-if="status=='请求中'" tip="努力加载中" :showLoading="true"></LoadMore>
            <LoadMore v-if="status=='没有更多'" tip="没有更多了" :showLoading="false"></LoadMore>
            <LoadMore v-if="status=='请求失败'" tip="加载失败，点我重试" :showLoading="false" @click.native="loadMore"></LoadMore>
            <Nodata v-if="status=='暂无数据'" :imgurl="require('@src/assets/img/bg_empty_data.png')" content='您还没有相关的订单'></Nodata>
        </div>
    </HeaderLayout>
</template>
<script>
import HeaderLayout from "@src/layouts/headerLayout.vue"
import Xheader from "@src/components/base/x-header"
import { Tab, TabItem } from '@src/components/base/tab'
import Nodata from '@src/components/base/no-data'
import OrderList from './module/order-list.vue'
import { getOrderList } from '@src/apis/order.js'
import historyReplaceState from '@src/utils/history-replace-state.js'
import infiniteScroll from '@src/directives/vue-infinite-scroll'
import LoadMore from "@src/components/base/load-more"

export default {
    directives: { infiniteScroll },
    components: { HeaderLayout, Xheader, Tab, TabItem, OrderList, Nodata, LoadMore },
    data() {
        return {
            status: "",
            orderList: [],
            showType: this.$route.query["showType"] || 0,
            query: { page: 1, size: 20 }
        }
    },
    computed: {
        infiniteDisabled() {
            return this.status == '请求中' || this.status == '没有更多' || this.status == '暂无数据' || this.status == '请求失败';
        }
    },
    methods: {
        async getOrderList(showType) {
            if (this.showType == showType) return;
            this.query.page = 1;
            this.showType = showType;
            this.loadMore(false);
            historyReplaceState({ showType: showType });
        },
        async loadMore(append = true) {
            try {
                if (append) this.status = "请求中";// 滚动加载时使用显示loadMore的loading
                else this.$store.dispatch('openGlobalLoading');// 点击tab 显示全局loading
                let data = await getOrderList({ showType: this.showType, ...this.query });
                this.setData(data, { append });
            } catch (error) {
                this.status = "请求失败";
            }
        },
        setData(data, options = {}) {
            if (options.append) this.orderList = this.orderList.concat(data.data);
            else this.orderList = data.data;
            if (this.orderList.length === 0) {
                this.status = "暂无数据";
            } else if (this.query.page >= data.totalPages) {
                this.status = "没有更多";
            } else {
                this.status = "请求更多";
                this.query.page++;
            }
        }
    },

}
</script>
<style lang='less' scoped>
</style>