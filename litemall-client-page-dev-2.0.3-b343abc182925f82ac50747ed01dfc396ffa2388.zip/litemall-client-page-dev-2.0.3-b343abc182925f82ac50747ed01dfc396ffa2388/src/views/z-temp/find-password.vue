<template>
    <FindPassword></FindPassword>
</template>

<script>
import FindPassword from "@src/components/user/find-password.vue";
export default {
    components: { FindPassword }
}
</script>

<style>
</style>
