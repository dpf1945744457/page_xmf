<template>
    <div>
        <Uinput label="手机号" type="tel" v-model="mobile" placeholder="请输入手机号" :topLine="true" maxLength="11"></Uinput>
        <Uinput label="验证码" type="tel" v-model="code" placeholder="请输入验证码" :topLine="true" maxLength="6" width="50%">
            <TimerBtn ref="TimerBtn" :text="'发送验证码'" :time="60" :cb="sendCode"></TimerBtn>
        </Uinput>
    </div>
</template>

<script>
import Uinput from "@src/components/base/u-input"
import TimerBtn from "@src/components/base/timer-btn"
import { getRegCode } from '@src/apis/user.js'
export default {

    components: { Uinput, TimerBtn },
    data() {
        return {
            mobile: "",
            code: ""
        }
    },
    methods: {
        async sendCode() {
            if (!/^(0|86|17951)?(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/.test(this.mobile.trim())) {
                this.$toast("请输入正确的手机号");
                return;
            }
            let data = await getRegCode({ mobile: this.mobile });
            if (data.errno == 0) {
                this.$refs.TimerBtn.disabled = true;
                this.$refs.TimerBtn.timer();
                this.$toast("验证码发送成功");
            }
        }
    }
}
</script>

<style>
</style>
