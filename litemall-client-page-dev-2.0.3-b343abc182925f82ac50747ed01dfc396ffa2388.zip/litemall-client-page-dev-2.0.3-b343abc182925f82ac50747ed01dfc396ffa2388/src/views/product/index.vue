<!--  -->
<template>
	<HeaderLayout class="product-list-page">
		<header class="header-fix ">
			{{ $route.meta.title }}
			<div @click="gobacks" class="left-arrow"></div>
		</header>
		<!--<Xheader class="header-fix" :title="$route.meta.title"></Xheader>-->
		<!-- <ProductListFilter></ProductListFilter> -->
		<!-- 分类 -->
		<tab class="tabs" :animate="false">
			<tab-item v-if="isCategory" @click.native="loadData(item.id)" :selected="categoryId == item.id" v-for="(item, index) in brotherCategory" :key="index">
				{{ item.name }}
			</tab-item>
			<tab-item v-if="!isCategory" @click.native="loadClassData(item.id)" :selected="classifyId == item.id" v-for="(item, index) in ClassCategory" :key="index">
				{{ item.name }}
			</tab-item>
		</tab>

		<!-- 商品列表 -->
		<ProductList :list="goodsList" @clickCartBtn="clickCartBtn"></ProductList>

		<!-- 商品为空 -->
		<Nodata v-if="noData" :imgurl="require('@src/assets/img/bg_empty_data.png')" content="暂无相关记录"></Nodata>

		<!-- Sku模块 -->
		<SkuModule ref="SkuModule"></SkuModule>

		<ViewFixedTool :showCartBar="true" :goodscount="goodscount"></ViewFixedTool>
	</HeaderLayout>
</template>

<script>
	import HeaderLayout from '@src/layouts/headerLayout.vue';
	import Xheader from '@src/components/base/x-header';
	import { Tab, TabItem } from '@src/components/base/tab';
	import Nodata from '@src/components/base/no-data';
	import ViewFixedTool from '@src/components/base/view-fixed-tool';
	// import ProductListFilter from './module/product-list-filter.vue'
	import ProductList from './module/product-list.vue';
	import { getCategoryTabs, getProductList, getClassifyTabs } from '@src/apis/product.js';
	import routeLeaveByisRoutePush from '@src/mixins/routeLeaveByisRoutePush.js';
	import historyReplaceState from '@src/utils/history-replace-state.js';
	import SkuModule from '@src/views/product-detail/module/skuModule/index.vue';
	import { mapState, mapActions, mapGetters } from 'vuex';
	export default {
		components: {
			HeaderLayout,
			Xheader,
			Tab,
			TabItem,
			ViewFixedTool,
			ProductList,
			Nodata,
			SkuModule
		},
		mixins: [routeLeaveByisRoutePush],
		async beforeRouteEnter(to, from, next) {
			if(['product-detail', 'cart', 'user-login'].indexOf(from.name) !== -1 && from.meta.isRouterPush) {
				next();
			} else {
				if(to.query.categoryId) {
					let categoryId = to.query['categoryId'];
					var data = await getCategoryTabs({
						id: categoryId
					});
					next(vm => {
						vm.setData(data);
					});
				} else {
					let classifyId = to.query['classifyId'];
					var data = await getClassifyTabs({
						id: classifyId
					});
					next(vm => {
						vm.setClassData(data);
					});
				}
			}
		},
		beforeRouteLeave(to, from, next) {
			
			this.isOpenSkuModule({
				open: false
			});
			next();
		},
		computed: {
			...mapState({
				goodscount: state => state.productDetail.goodscount
			})
		},
		data() {
			return {
				categoryId: '',
				classifyId: '',
				//当前父级总类
				parentCategory: {},
				//所有分类
				brotherCategory: [],
				ClassCategory: [],
				//当前选中分类
				currentCategory: {},
				goodsList: [],
				noData: false,
				isCategory: true
			};
		},
		mounted() {
			// 获取购物车数量
			this.getCartGoodscount();
		},
		methods: {
			// 列表中点击购物车按钮
			...mapActions(['getProductDetailById', 'isOpenSkuModule', 'addCart', 'getCartGoodscount']),
			gobacks() {
				// this.$router.push('/');
				history.go(-1);
			},
			// 初始化数据
			setData(data) {
				this.parentCategory = data.parentCategory;
				this.brotherCategory = data.brotherCategory;
				this.goodsList = [];
				this.noData = false;

				// 处理tab-item默认不选中的问题
				setTimeout(() => {
					this.currentCategory = data.currentCategory;
					this.loadData(this.currentCategory.id);
				}, 100);
			},
			// 初始化商品数据
			setClassData(data) {
				this.isCategory = false;
				this.parentCategory = data.cuurClassify;
				this.ClassCategory = data.brotClassify;
				
				this.goodsList = [];
				this.noData = false;
				// 处理tab-item默认不选中的问题
				setTimeout(() => {
					this.currentCategory = data.cuurClassify;
					this.loadClassData(this.currentCategory.id);
				}, 100);
			},
			// 根据馆id加载商品列表
			async loadData(categoryId) {
				this.categoryId = categoryId;
				let data = await getProductList({
					categoryId: categoryId
				});
				this.goodsList = data.goodsList;
				this.noData = this.goodsList.length === 0;
				historyReplaceState({
					categoryId: categoryId
				});
			},

			// 根据商品id加载商品列表
			async loadClassData(classifyId) {
				this.classifyId = classifyId;
				let data = await getProductList({
					classifyId: classifyId
				});
				this.goodsList = data.goodsList;
				this.noData = this.goodsList.length === 0;
				historyReplaceState({
					classifyId: classifyId
				});
			},

			async clickCartBtn(goods) {
				await this.getProductDetailById(goods.id);
				this.isOpenSkuModule({
					open: true,
					skuBtnType: 'confirm'
				});
			}
		}
	};
</script>
<style lang="less" scoped>
	//@import url(); 引入公共css类
	.product-list-page {
		margin-top: 47px;
		.tabs {
			position: fixed;
			left: 0;
			top: 46px;
			width: 100%;
			z-index: 99;
		}
	}
	
	header {
		text-align: center;
		position: fixed;
		top: 0;
		line-height: 2rem;
		padding: 3px 0;
		box-sizing: border-box;
		background: #fafafa;
	}
	
	.left-arrow {
		position: absolute;
		width: 30px;
		height: 30px;
		top: 12px;
		left: 12px;
	}
	
	.left-arrow:before {
		content: '';
		position: absolute;
		width: 12px;
		height: 12px;
		border: 1px solid #ccc;
		border-width: 1px 0 0 1px;
		-webkit-transform: rotate(315deg);
		transform: rotate(315deg);
		top: 8px;
		left: 7px;
	}
</style>