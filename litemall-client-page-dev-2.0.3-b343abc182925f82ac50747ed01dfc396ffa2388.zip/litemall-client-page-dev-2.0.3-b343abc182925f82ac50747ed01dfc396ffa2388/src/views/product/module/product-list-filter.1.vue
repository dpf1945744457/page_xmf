<template>
    <FilterBar top="46" :topLine="true" :bottomLine="true" :bar-menus="barMenus" @showDialog="handleShowDialog" @closeDialog="handleCloseDialog" @changeTab="handleChangeTab" @changeMainItem="handleChangeMainItem" @changeSelect="changeData">
    </FilterBar>
</template>
<script>

import FilterBar from "@src/components/base/filter/filterBar.vue"
import barMenus from './data';
export default {
    components: { FilterBar },
    head() { return {} },
    asyncData(context) { },
    data() {
        return {
            barMenus: barMenus
        }
    },
    fetch() { },
    methods: {
        handleShowDialog(v) {
        	
        },
        handleCloseDialog(v) {
        	
        },
        handleChangeTab(v) {
        	
        },
        handleChangeMainItem(v) {
        	
        },
        changeData(v) {
        	
        }
    },
}
</script>
<style lang='less' scoped>
</style>