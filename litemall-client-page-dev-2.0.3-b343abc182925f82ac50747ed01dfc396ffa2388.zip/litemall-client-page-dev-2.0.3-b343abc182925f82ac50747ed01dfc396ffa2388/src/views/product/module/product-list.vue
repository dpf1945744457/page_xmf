<template>
    <van-list v-model="loading" :finished="finished" :immediate-check='false' finished-text="没有更多了" @load="onLoad">
        <div class="product-list clearfix">
            <GoodsItem class="goods-item" v-for="(item, index) in lists" :key="index" :item="item">
                <icon slot="actionIcon" name="cart" scale="3" @click.native="$emit('clickCartBtn', item)"></icon>
            </GoodsItem>
        </div>
    </van-list>
</template>
<script>
import GoodsItem from '@src/components/base/goodsItem/index.vue';
import axios from 'axios';
import base from '@src/apis/base.js';
import { List } from 'vant';
import { getProductList } from '@src/apis/product.js';
export default {
    components: { GoodsItem,List },
    props: ['list'],
    data() {
        return {
            counter: 2, //默认已经显示出10条数据 count等于一是让从11条开始加载
            // num : 10,  // 一次显示多少条
            // pageStart : 0, // 开始页数
            // pageEnd : 0, // 结束页数
            // listdata: [], // 下拉更新数据存放数组
            lists: [], // 上拉更多的数据存放数组,
            classifyId: '',
            loading: false,
            finished: false,

            checkId: '',
        };
    },
    methods: {
        GetUrlPara: function() {
            var url = document.location.toString();
            var arrUrl = url.split('?');
            var name = arrUrl[1].split('=');
            this.checkId =  name[0];
            this.classifyId = name[1];
            
        },
        async onLoad(){
        	
            this.GetUrlPara();
            this.loading = true
            let res = ''
            if( this.checkId == 'categoryId'){
                res = await getProductList({ categoryId: this.classifyId ,page: this.counter, });
            }else{
                res = await getProductList({ classifyId: this.classifyId ,page: this.counter, });
            }
            this.lists = [...this.lists,...res.goodsList]
            
            if(res.goodsList.length < 10){
                this.finished = true
                this.loading = false
            }else{
                this.counter++
                this.loading = false
            }
        },
    },
    watch:{
        list(){
        	
            this.finished = false
            this.lists = this.list
        }
    }
};
</script>
<style lang="less" scoped>
.product-list {
    //   position: relative;
    display:flex;
    justify-content: flex-start;
    flex-wrap: wrap;
}
</style>
