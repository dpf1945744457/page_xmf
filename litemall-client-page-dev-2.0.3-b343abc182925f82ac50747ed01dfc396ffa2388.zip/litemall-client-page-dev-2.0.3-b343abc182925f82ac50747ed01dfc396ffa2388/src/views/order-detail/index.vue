<template>
  <HeaderLayout class="order-detail">
    <Xheader class="header-fix" :title="$route.meta.title"></Xheader>

    <!-- 订单状态 -->
    <OrderDetailStatus :status="orderInfo.orderStatusText">
      <!-- 代付款订单倒计时 -->
      <OrderDetailTimeDown
        v-if="orderInfo.orderStatusText == '未付款'"
        :eTime="eTime"
        :callback="countdownDateTimeCallback"
      ></OrderDetailTimeDown>
    </OrderDetailStatus>

    <Ucell title="下单时间" class="m-t-10" :desc="orderInfo.addTime"></Ucell>
    <Ucell title="订单编号" :topLine="true" :desc="orderInfo.orderSn"></Ucell>
    <Ucell
      title="订单进度"
      :topLine="true"
      desc="待拣货"
      v-if="orderInfo.allocateCargoStatus==1 && (orderInfo.orderStatus == '201' || orderInfo.orderStatus == '204')"
    ></Ucell>
    <Ucell
      title="订单进度"
      :topLine="true"
      desc="拣货完成"
      v-if="orderInfo.allocateCargoStatus==2 && (orderInfo.orderStatus == '201' || orderInfo.orderStatus == '204')"
    ></Ucell>
    <Ucell
      v-if="orderInfo.freeTaxBarCode"
      title="免税袋条码"
      :topLine="true"
      :desc="orderInfo.freeTaxBarCode"
    ></Ucell>

    <div class="order-address-box" @click="lookLogisticsProcess" v-if="orderInfo.orderStatus > 300">
      <div class="content-box">物流轨迹</div>
      <div class="icon-box">
        <icon scale="2" name="linkright"></icon>
      </div>
    </div>
    <Ucell title="快递单号" :topLine="true" v-if="orderInfo.shipSn" :desc="orderInfo.shipSn"></Ucell>
    <Ucell title="快递公司" :topLine="true" v-if="orderInfo.shipChannel" :desc="orderInfo.shipChannel"></Ucell>

    <!-- 收货地址 -->
    <addressCheck
      class="m-t-10"
      :isLink="false "
      :address="{name:orderInfo.consignee,mobile:orderInfo.mobile,address:orderInfo.address} "
    ></addressCheck>

    <!--<Ucell class="m-t-10 " title="支付人姓名" :desc="orderInfo.realName"></Ucell>
    <Ucell title="支付人身份证" :topLine="true" :desc="orderInfo.personId"></Ucell>-->
    <div class="message" v-if="orderInfo.leavingMessage">
      <span class="message-title">用户留言：</span>
      <span class="message-content">{{orderInfo.leavingMessage}}</span>
    </div>

    <!-- 商品列表 -->
    <OrderDetailGoods :orderGoods="orderGoods " :orderInfo="orderInfo "></OrderDetailGoods>
    <!-- 订单信息  -->
    <OrderDetailInfo class="m-t-10" :orderInfo="orderInfo"></OrderDetailInfo>

    <div
      class="btns"
      v-if="(orderInfo.orderStatusText == '已付款'||orderInfo.orderStatusText == '缺货') && orderInfo.handleOption.refund == true"
    >
      <Xbutton mini style="margin:0 6px;" @click.native="postOrderRefund">申请退款</Xbutton>
    </div>
    <div class="btns" v-if="orderInfo.orderStatusText == '未付款'">
      <Xbutton mini style="margin:0 5px;padding:0 15px" @click.native="postOrderCancel">取消订单</Xbutton>
      <Xbutton
        mini
        style="margin:0 5px;"
        type="warn"
        @click.native="postPrepayOrder"
        class="d-btn weui-btn_inline weui_btn_nopay"
      >去付款</Xbutton>
    </div>
    <div class="btns" v-if="orderInfo.orderStatusText == '已发货'">
      <Xbutton
        mini
        style="margin:0 5px;"
        type="warn"
        @click.native="yancheng(orderInfo)"
        class="d-btn weui-btn_inline weui_btn_nopay"
        v-if="!orderInfo.isExtendReceive"
      >延长收货</Xbutton>
      <Xbutton
        mini
        style="margin:0 5px;"
        type="warn"
        @click.native="postOrderConfirm"
        class="d-btn weui-btn_inline weui_btn_nopay"
      >确认收货</Xbutton>
    </div>
    <div class="btns" v-if="orderInfo.orderStatusText == '待评价'">
      <Xbutton
        mini
        style="margin:0 5px;"
        type="warn"
        @click.native="$router.push({path:`/order/${orderInfo.id}/comment`})"
        class="d-btn weui-btn_inline weui_btn_nopay"
      >去评价</Xbutton>
    </div>
    <div
      class="btns"
      v-if="orderInfo.orderStatusText == '已申请退款'&&orderInfo.handleOption.cancelRefund == true"
    >
      <Xbutton mini style="margin:0 6px;" @click.native="noOrderRefund(orderInfo.id)">取消退款</Xbutton>
    </div>

    <!--<CommonFooterCopyright class="m-t-10"></CommonFooterCopyright>-->
    <div id="form-box"></div>
  </HeaderLayout>
</template>

<script>
import HeaderLayout from "@src/layouts/headerLayout.vue";
import Xheader from "@src/components/base/x-header";
import Xbutton from "@src/components/base/x-button";
import Ucell from "@src/components/base/u-cell";
import CommonFooterCopyright from "@src/components/base/common-footer/footer-copyright.vue";
import OrderDetailGoods from "./module/order-detail-goods.vue";
import OrderDetailInfo from "./module/order-detail-info.vue";
import OrderDetailTimeDown from "./module/order-detail-time-down.vue";
import OrderDetailStatus from "./module/order-detail-status.vue";
import addressCheck from "@src/views/order-confirm/module/addressCheck";
import {
  getOrderDetail,
  postPrepayOrder,
  postOrderCancel,
  postOrderRefund,
  postOrderConfirm,
  cancelRefund,
  extendReceive,
} from "@src/apis/order.js";
import $ from "jquery";
export default {
  components: {
    HeaderLayout,
    Xheader,
    Xbutton,
    Ucell,
    OrderDetailTimeDown,
    OrderDetailStatus,
    OrderDetailGoods,
    OrderDetailInfo,
    addressCheck,
    CommonFooterCopyright,
  },
  data() {
    return {
      btnLoading: false,
      // 如果 true 代表返回列表页重新加载数据
      isRefreshList: false,
      // 订单商品
      orderGoods: [],
      // 订单信息
      orderInfo: [],
      // 订单ID
      orderId: this.$route.params["id"],
      // 代付款订单 倒计时时间 秒单位
      eTime: 0,
    };
  },
  async beforeRouteEnter(to, from, next) {
    let data = await getOrderDetail({ orderId: to.params["id"] });
    next((vm) => {
      vm.setData(data);
    });
  },
  beforeRouteLeave(to, from, next) {
    if (this.isRefreshList === true) {
      from.meta.isRouterPush = false;
    }
    next();
  },
  methods: {
    setData(data) {
      console.info(data);
      this.orderGoods = data.orderGoods;
      this.orderInfo = data.orderInfo;
      if (data.orderInfo.freeTaxBarCode) {
        console.log(data.orderInfo.freeTaxBarCode);
        let freeTaxBarCode = data.orderInfo.freeTaxBarCode.split(",");
        this.orderInfo.freeTaxBarCode = freeTaxBarCode;
      }

      this.orderInfo = data.orderInfo;
      this.eTime =
        (new Date(this.orderInfo.addTime.replace(/-/g, "/")).getTime() +
          1000 * 60 * 30 -
          Date.now()) /
        1000;
    },
    noOrderRefund(orderId) {
      cancelRefund({ orderId })
        .then((res) => {
          if (res.errno == 0) {
            this.orderInfo.orderStatusText = "已付款";
            this.orderInfo.handleOption.refund = true;
            this.orderInfo.orderStatus = "201";
            console.log(this.orderInfo.orderStatus);
            this.$iosAlert({
              title: "提交成功",
              text: "已取消退款",
              okText: "知道了",
              appendChildClass: "#page",
            });
          } else {
            this.$toast(res.errmsg);
          }
        })
        .catch((error) => {
          Message({
            message: error.errmsg,
            type: "error",
          });
        });
    },
    yancheng(type) {
      extendReceive({ orderId: type.id })
        .then((res) => {
          if (res.errno == 0) {
            this.orderInfo.isExtendReceive = true;
            this.$toast("延长收货成功");
          } else {
            this.$toast(res.errmsg);
          }
        })
        .catch((error) => {
          Message({
            message: error.errmsg,
            type: "error",
          });
        });
    },
    // 用户点击去付款
    async postPrepayOrder() {
      try {
        this.btnLoading = true;
        let data = await postPrepayOrder({ orderId: this.orderInfo.id });
        if (data.shipmentRegion) {
          window.location.href = data.url;
        } else {
          $("#form-box").html(data);
        }
      } catch (error) {
        this.btnLoading = false;
      }
    },

    // 用户点击取消订单
    postOrderCancel() {
      this.$iosConfirm({
        title: "取消订单",
        text: "确定要取消此订单吗？",
        cancelText: "再想想",
        okText: "确定",
        appendChildClass: "#page",
      }).then(async () => {
        let res = await postOrderCancel({ orderId: this.orderInfo.id });
        if (res.errno == 0) {
          this.orderInfo.orderStatusText = "已取消";
          this.isRefreshList = true;
          this.$router.back(-1);
        } else {
          this.$toast(res.errmsg);
        }
      });
    },
    // 用户点击申请退款
    postOrderRefund() {
      this.$iosConfirm({
        title: "退款确认",
        text: "好货不等人，您确定要申请退款吗？",
        cancelText: "再想想",
        okText: "确定",
        appendChildClass: "#page",
      }).then(async () => {
        let res = await postOrderRefund({ orderId: this.orderInfo.id });
        if (res.errno == 0) {
          this.orderInfo.orderStatusText = "已申请退款";
          this.orderInfo.handleOption.cancelRefund = true;
          this.orderInfo.orderStatus = "202";
          this.$iosAlert({
            title: "提交成功",
            text:
              "退款申请成功，我们会在2个工作日内为您办理退款程序，请您保持电话畅通",
            okText: "知道了",
            appendChildClass: "#page",
          });
        } else {
          this.$toast(res.errmsg);
        }
      });
    },
    // 用户点击确认收货
    async postOrderConfirm() {
      let res = await postOrderConfirm({ orderId: this.orderInfo.id });
      this.$router.push({ path: `/order/${this.orderInfo.id}/comment` });

      // if (res.errno == 0) {
      //     this.orderInfo.orderStatusText = "待评价";
      //     this.isRefreshList = true;
      // } else {
      //     this.$toast(res.errmsg);
      // }
    },

    // 待付款订单倒计时结束后
    async countdownDateTimeCallback() {
      let res = await postOrderCancel({ orderId: this.orderInfo.id });
      this.orderInfo.orderStatusText = "已取消";
      this.isRefreshList = true;
      // 临时自动取消
      // this.postOrderCancel();
    },
    lookLogisticsProcess() {
      this.$router.push({
        path: `/logisticsProcess/${this.$route.params["id"]}`,
      });
    },
  },
};
</script>

<style lang="less" scoped>
.order-detail {
  padding-bottom: 60px;
  .message {
    margin: 10px 0;
    width: 100%;
    background: #fff;
    .message-title {
      display: block;
      padding: 10px;
      font-size: 16px;
      color: #222;
    }
    .message-content {
      display: block;
      padding: 0 10px 10px 10px;
    }
  }
}
.btns {
  position: fixed;
  bottom: 0;
  left: 0;
  width: 100%;
  background: #fff;
  padding: 10px;
  text-align: right;
  box-sizing: border-box;
  border-top: 1px solid #eee;
}
.weui_btn_nopay {
  background-color: #f7cf20 !important;
}

.order-address-box {
  padding: 12px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  .content-box {
    flex: 1;
    display: flex;
    flex-direction: column;
  }
  .icon-box {
    flex: 0 0 20px;
    display: flex;
    justify-content: flex-end;
    align-items: center;
    text-align: right;
    svg {
      transform: translateX(8px);
      font-weight: bold;
    }
    &:first-child {
      justify-content: start;
    }
    &:last-child {
      justify-content: end;
    }
  }
}
</style>
