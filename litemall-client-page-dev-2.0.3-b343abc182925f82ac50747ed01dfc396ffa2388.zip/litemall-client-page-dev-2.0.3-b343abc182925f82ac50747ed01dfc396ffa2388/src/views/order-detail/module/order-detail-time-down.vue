<template>
    <div class="time-down">
        <!-- 倒计时结束 -->
        <p v-if="isTimeEnd">提示：超过付款时间，订单已自动关闭。</p>

        <!-- 倒计时未结束 -->
        <p class="time" v-else>
            请在
            <CountdownDateTime :sTime="0" :eTime='eTime' :callback="_callback"></CountdownDateTime>
            内付款，
            <br>超时订单将自动关闭。
        </p>
    </div>
</template>

<script>
import CountdownDateTime from '@src/components/base/countdown-date-time'
export default {
    props: ["eTime", "callback"],
    components: { CountdownDateTime },
    data() {
        return {
            // 倒计时是否结束
            isTimeEnd: false
        }
    },
    mounted() {
        if (this.eTime > 0) {
            this.isTimeEnd = false;
        } else {
            this.isTimeEnd = true;
            // 如果倒计时已经结束 手动调用结束方法
            this.callback();
        }
    },
    methods: {
        _callback() {
            this.callback();
            this.isTimeEnd = true;
        }
    }

}
</script>

<style lang="less" scoped>
.time-down {
  //   background: #fff;
  //   color: #fff;

  .time {
    font-size: 12px;
  }
}
</style>
