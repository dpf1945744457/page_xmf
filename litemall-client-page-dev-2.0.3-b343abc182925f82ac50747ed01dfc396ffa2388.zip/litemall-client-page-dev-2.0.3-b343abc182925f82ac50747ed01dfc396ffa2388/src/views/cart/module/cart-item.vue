<template>
  <div class="cart-item com-bottom-1px" v-if="item.number > 0">
    <div class="cart-checkbox">
      <CheckIcon v-if="!isEditing" :value.sync="item.checked"></CheckIcon>
      <CheckIcon v-if="isEditing" :value.sync="item.deleted"></CheckIcon>
    </div>

    <div class="inner">
      <div class="goods-pic">
        <img :src="item.picUrl" class="itempic" />
      </div>
      <dl class="goods-info">
        <!--此处商品名称需要控制显示字数-->
        <a  @click="go(item)">
        <dt class="goods-name">
          <a  class="item-title">{{item.goodsName}}</a>
          <van-icon name="cross" color="red" @click.stop="dele(item)" />
        </dt>

        <dd class="goods-attr">
          <span v-for="(item,index) in item.specifications" :key="index">{{item}}&nbsp;</span>
        </dd>
        <dd class="goods-attr">
          <span
            v-if="item.taxFlag==0"
            style="display:block;font-size: 12px; color:red"
          >税费:HK${{(item.taxes*item.number) | filterPrice}}</span>
          <span v-if="item.taxFlag==1" style="display:block;font-size: 12px; color:red">税费:商品已包税</span>
        </dd>
        </a>
        <dd class="good-info-bottom ub">
          <em class="goods-price price-color ub-f1">HK${{(item.price) | filterPrice}}</em>
          <div class="goods-num amount amount-btn">
            <xnumber class="goods-num" v-model="item.number" :min="1" :max="item.limitBuyNum" ></xnumber>
          </div>
           <!-- <div
          @click="toOrderConfirm"
          class="submit-btn check-btn bg-color SZY-CART-SUBMIT"
        >去结算</div> -->
        </dd>
      </dl>
    </div>
  </div>
</template>

<script>
import Xnumber from "@src/components/base/x-number";
import CheckIcon from "@src/components/base/check-icon";
import {
  getCartIndex,
  postCartChecked,
  postCartDelete
} from "@src/apis/cart.js";
import { mapState, mapActions, mapGetters } from "vuex";
export default {
  filters: {
    filterPrice: function(num) {
      return Number(num).toFixed(2);
    }
  },
  components: {
    Xnumber,
    CheckIcon
  },
  data() {
    return {
      foreign: [],
      fo: 0,
      domestic: [],
      do: 0
    };
  },
  computed: {
    ...mapGetters(["isLogin"])
  },
  props: {
    isEditing: {
      type: Boolean
    },
    item: {
      type: Object,
      default: {}
    }
  },
  watch: {
    "item.number"() {
     
      
      this.$emit("numberChanged", this.item);
    },
    "item.checked"() {
      this.$emit("selectChanged", this.item);
    },
    "item.deleted"() {
      this.$emit("deleteChanged", this.item);
    }
  },
  created() {
    console.log(this.item);
  },
  methods: {
    ...mapActions(["getCartGoodscount"]),
    getCartList() {
      if (!this.isLogin) {
        this.isEditing = false;
        this.show = true;
        return;
      }
      getCartIndex().then(data => {
        this.show = true;
        if (data && data.cartList) {
          this.cartList = data.cartList;
          if (this.cartList.length === 0) {
            this.showEmpty = true;
          }
          this.$nextTick(() => {
            if (this.$refs.carts != null) {
              this.isEditing = false;
              this.$refs.carts.calcTotal();
            }
          });
        }
      });
    },
    dele(item) {
      this.$dialog
        .confirm({
          title: "删除",
          message: "确认要删除这1种商品吗？"
        })
        .then(() => {
          this.$emit("dele", item);
          let productIds = [];
          productIds.push(item.productId);
          postCartDelete({
            productIds: productIds
          }).then(result => {
            item = [];
            this.getCartList();
            this.getCartGoodscount();
            location.reload();
          });
        })
        .catch(() => {
          // on cancel
        });
    },
    go(item) {
      this.$router.push({
        path: `/product/${item.goodsId}`
      });
    }
  }
};
</script>

<style lang="less" scoped>
.cart-item {
  overflow: hidden;
  width: 100%;
  height: 120px;
  /*padding: 0rem 0.2rem 0.7rem 0.5rem;*/
  padding: 16px 14px;
  padding-right: 6px;
  box-sizing: border-box;
  margin-bottom: 12px;
  background: #fff;
  .cart-checkbox {
    position: absolute;
    left: 6px;
    top: 40px;
  }
  .inner {
    display: block;
    margin-left: 22px;
    position: relative;
    border-bottom: 0.05rem solid #fff;
    .goods-pic {
      display: block;
      /*width: 4.3rem;
				height: 4.3rem;*/
      width: 106px;
      height: 62px;
      position: absolute;
      //   z-index: 1;
      top: 6px;
      left: 0;
      border: 1px solid #f8f8f8;
      box-sizing: border-box;
      .itempic {
        width: 100%;
        height: 100%;
      }
    }
    .goods-gift-name {
      display: block;
      position: absolute;
      top: 0;
      left: 0;
      padding: 0px 5px;
      color: #fff;
      border-radius: 2px;
      font-size: 12px;
      line-height: 0.85rem;
      z-index: 2;
    }
    .goods-info {
      display: block;
      margin: 0 0 0 114px;
      position: relative;
      /*padding-right: 0.2rem;*/
      height: 90px;
      .goods-name {
        font-family: PingFangSC-Regular;
        font-size: 15px;
        color: #666666;
        height: 20px;
        a {
          display: inline-block;
          width: 175px;
          height: 20px;
          color: #5e5e5e;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        display: block;
        position: relative;
        /*width: 184px;
					overflow: hidden;
					text-overflow: ellipsis;
					white-space: nowrap;*/
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 2;
        margin-bottom: 8px;
        padding-right: 5px;
      }
      .goods-attr {
        height: 0.7rem;
        line-height: 0.7rem;
        overflow: hidden;
        font-size: 0.8125em;
        color: #999;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
      .good-info-bottom {
        position: absolute;
        bottom: 0;
        width: 100%;
        height: 28px;
        line-height: 28px;
        .goods-price {
          /*line-height: 35px;
						font-size: 0.75rem;*/
          font-family: PingFang-SC-Bold;
          font-size: 15px;
          color: #f23030;
        }
        .goods-num {
          position: absolute;
          right: 0;
          bottom: 0;
          width: 150px;
          padding: 0 !important;
        }
      }
    }
  }
}
 .check-btn {
      display: block;
      float: right;
      width: 25%;
      height: 50px;
      color: #fff;
      line-height: 2.05rem;
      text-align: center;
      position: relative;
      bottom: 0;
      cursor: pointer;
    }
.goods-item {
  padding: 10px 15px;
  font-size: 16px;
}
</style>