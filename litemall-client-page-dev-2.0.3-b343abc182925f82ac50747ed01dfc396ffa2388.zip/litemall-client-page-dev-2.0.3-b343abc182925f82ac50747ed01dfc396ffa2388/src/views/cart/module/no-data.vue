<template>
    <div class="no-data">
        <!--<div class="no-login-tip" v-if="!isLogin">
            <span>登录后可以看到您选中的商品</span>
            <a href="javascript:void(0)" @click="clickHrefs" class="bg-color">登录</a> 
        </div>-->
        <div class="no-data-div m-b-50">
            <div class="no-data-img">
                <img :src="require('@src/assets/img/cart/bg_empty_data.png')" alt="暂无商品">
            </div>
            <dl>
                <dt>购物车还是空空的呢</dt>
                <dd>先去挑选自己喜欢的宝贝吧！</dd>
            </dl>
            <router-link to="/" class="no-data-btn bg-color">逛一逛</router-link>
        </div>
    </div>
</template>

<script>
import { mapState, mapActions, mapGetters } from "vuex";
export default {
    components: {
    },
    data() {
        return {
        }
    },
    computed: {
        ...mapGetters(["isLogin"])
    },
    mounted() {
        
    },
    methods: {
        clickHrefs(){
            this.$router.push({ path:'/phoneLogin' })
        },
    }
}
</script>

<style lang="less" scoped>
.no-data {
  /*   display: flex; */
  overflow: hidden;
  /*购物车未登录提示去登录*/
  .no-login-tip {
    height: 23px;
    line-height: 23px;
    padding: 11px 0px;
    text-align: center;
    background: #fff;
    border-bottom: 1px solid #eee;
    font-size: 13px;
    a {
      display: inline-block;
      height: 21px;
      line-height: 21px;
      padding: 0 12px;
      border-radius: 4px;
      margin-left: 3px;
      color: #fff;
      font-size: 0.5rem;
    }
    span {
      color: #666;
    }
  }
  /*购物车，订单列表等没有数据时提示样式*/
  .no-data-div {
    width: 90%;
    margin: 3rem auto 0;
    text-align: center;

    .no-data-icon {
      height: 5rem;
      width: 5rem;
      line-height: 12rem;
      text-align: center;
      display: block;
      background: #dfe0e8;
      border-radius: 100%;
      margin: 0 auto;
    }
    .no-data-img {
      margin: 0 auto;
    }
    .no-data-img img {
      height: 5.5rem;
    }
    .no-data-img.small-img img {
      height: 4rem;
    }
    .no-data-icon i {
      display: block;
      color: #fff;
      line-height: 5rem;
      font-size: 3rem;
    }
    dl {
      min-height: 2.75rem;
      margin: 0.75rem auto;
      text-align: center;
    }
    dl dt {
      display: block;
      min-height: 1rem;
      margin-bottom: 0.25rem;
      font-size: 0.7rem;
      line-height: 1rem;
      color: #777;
    }
    dl dd {
      display: block;
      min-height: 1rem;
      margin-bottom: 0.5rem;
      font-size: 0.55rem;
      line-height: 1rem;
      color: #999;
    }
    .no-data-btn {
      display: block !important;
      width: 6rem;
      height: 1.5rem;
      margin: 0 auto;
      font-size: 0.7rem;
      color: #fff !important;
      line-height: 1.5rem;
      text-align: center;
      border-radius: 0.15rem;
    }
  }
}
</style>
