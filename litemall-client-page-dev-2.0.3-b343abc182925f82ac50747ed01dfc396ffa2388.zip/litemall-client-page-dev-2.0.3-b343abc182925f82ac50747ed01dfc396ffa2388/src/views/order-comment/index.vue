<template>
    <HeaderLayout>
        <Xheader class="header-fix product-detail-header">{{$route.meta.title}}</Xheader>

        <Nodata v-if="list.length == 0" :imgurl="require('@src/assets/img/bg_empty_data.png')" content='暂无评价订单'></Nodata>
        <template v-else>

            <div class="post-cont">

                <div class="comment-item m-b-10" v-for="(goods,i) in list" :key="i">

                    <!-- 评价的商品信息 -->
                    <Ucell :title="goods.goodsName" :borderLine="true" class="goods">
                        <img slot="icon" class="goods-pic" data-v-6b3d1d7b="" :src="goods.picUrl" alt="">
                    </Ucell>

                    <!-- 文字评价 -->
                    <Xtextarea class="post-area m-t-10 m-b-10" v-model="goods.content" :border="true" placeholder="说点什么..."></Xtextarea>

                    <!-- 图片上传 -->
                    <ul class="upload clearfix">
                        <!-- 图片数组展示 -->
                        <li class="upload-view" v-for="(pic,index) in goods.picUrls" :key="index">
                            <img id="ssss" style="display:block;" :src="pic" width="100%" alt="">
                        </li>
                        <!-- input控件 -->
                        <li class="upload-view upload-control" v-if="goods.picUrls.length < 3">
                            <input type="file" accept="image/png,image/jpg,image/jpeg" @change="change($event,goods)">
                        </li>
                    </ul>
                </div>
            </div>
            <div class="post-bot">
                <Xbutton class="post-bot-btn" type="primary1" :disabled="showLoading" :show-loading="showLoading" @click.native="submit">发表</Xbutton>
            </div>
        </template>
    </HeaderLayout>
</template>

<script>

import HeaderLayout from "@src/layouts/headerLayout.vue"
import Xheader from "@src/components/base/x-header"
import Xbutton from "@src/components/base/x-button"
import Xtextarea from '@src/components/base/x-textarea'
import Ucell from '@src/components/base/u-cell'
import Nodata from '@src/components/base/no-data'
import regExp from '@src/utils/regExp.js'
import { mapState, mapActions, mapGetters } from "vuex"
import { getCommentOrder, postComment } from "@src/apis/comment.js"
// 裁剪插件
import imgClipper from '@src/plugins/img-clipper/index.js'
import '@src/plugins/img-clipper/index.css'
import Vue from 'vue'
Vue.use(imgClipper);

export default {
    components: { HeaderLayout, Xheader, Xbutton, Xtextarea, Ucell, Nodata },
    data() {
        return {
            list: [],
            isRefreshList: false
        }
    },
    computed: {
        ...mapGetters(["showLoading"]),
    },
    async beforeRouteEnter(to, from, next) {
        let data = await getCommentOrder({ orderId: to.params["id"] });
        next(vm => { vm.setData(data) });
    },
    beforeRouteLeave(to, from, next) {
        try {
            this.destoried();
        } catch (err) {

        }
        next();
    },
    beforeRouteLeave(to, from, next) {
        if (this.isRefreshList === true) {
            from.meta.isRouterPush = false;
        }
        next();
    },
    methods: {
        setData(data) {
            for (let index = 0; index < data.length; index++) {
                const element = data[index];
                element.content = "";
                element.picUrls = [];
            }
            this.list = data;
            
        },
        change(event, goods) {
            // let image = event.target.parentNode.querySelector("img"); //预览对象
            
            // let image = new Image();
            this.initClip(event, {
                // resultObj: image,
                aspectRatio: 1,
                callback: (url) => {
                    goods.picUrls.push(url);
                }
            })
        },
        // 评价提交
        async submit() {
            let requestArr = new Array();
            for (let index = 0; index < this.list.length; index++) {
                const goods = this.list[index];

                if (goods.content) {
                    let requestData = {};
                    requestData["orderGoodsId"] = goods.id;
                    requestData["star"] = "4";
                    requestData["content"] = goods.content;
                    requestData["type"] = "0";
                    requestData["valueId"] = goods.productId;
                    requestData["picUrls"] = goods.picUrls;
                    requestArr.push(requestData);
                }

            }
            if (requestArr.length == 0) {
                this.$toast("请填写至少一个宝贝的评论内容");
                return;
            }

            // 遍历是否有非法字符，如何查不到返回undefined，查到返回当前项
            // if (requestArr.find(request => !regExp.normal.reg.test(request.content))) {
            //     this.$toast("评论内容不得出现非法字符");
            //     return;
            // }

            let data = await postComment(requestArr);
            this.isRefreshList = true;
            this.$router.back();
        },

    },

}
</script>

<style lang="less" scoped>
.post-cont {
  //   padding: 0.306666666666667rem 0.4rem;
  //   box-sizing: border-box;
  //   position: absolute;
  top: 47px;
  bottom: 80px;
  width: 100%;
  overflow-y: scroll;
  min-width: 320px;
  max-width: 640px;
  .comment-item {
    padding: 0 10px;
    box-sizing: border-box;
    background: #fff;
    overflow: hidden;

    .goods {
      padding: 12px 0;
      .goods-pic {
        width: 35px;
        height: 35px;
        margin-right: 10px;
        border-radius: 5px;
      }
    }

    .post-area {
      height: 150px;
    }

    .upload {
      padding: 10px 0;
      .upload-view {
        overflow: hidden;
        width: 80px;
        height: 80px;
        margin: 5px;
        float: left;
        input {
          display: block;
          width: 100%;
          height: 100%;
          opacity: 0;
        }
      }

      .upload-control {
        background: url("../../assets/img/upload.png") no-repeat;
        background-size: 100%;
      }
    }
  }
}
.post-bot {
  //   position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  height: 80px;
  width: 100%;
  background: #fff;
  border-top: 1px solid #e5e5e5;
  z-index: 110;
  display: flex;
  align-items: center;
  .post-bot-btn {
    border-radius: 99px;
    background: #ff6c03;
    width: 90%;
  }
}
</style>
