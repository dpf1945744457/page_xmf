<template>
    <div style="width:100%;height:100%">
                 <!-- <Xheader class="header-fix" :title="$route.meta.title" :left-options="{preventGoBack:true}" @on-click-back="$router.replace('/')"></Xheader> -->
        <iframe :src="src" class="iframe" frameborder="0"></iframe>
    </div>
</template>

<script>
// import HeaderLayout from "@src/layouts/headerLayout.vue"
// import Xheader from "@src/components/base/x-header"
export default {
	//   components: { HeaderLayout,Xheader },
    data() {
        return {
            src:"https://dc.xmfstore.com/dingzuo-h5/#/home"
        };
    },
    methods: {
       
    }
};
</script>

<style lang="less" scoped>
.iframe{ width: 100%;height:100%;}
</style>
