<template>
    <div class="product-detail-content" :style="`min-height:${APP.winH}px`">
        <!-- <LoadMore tip="商品详情" :showLoading="false" style="margin: 1.6em auto 0em;"></LoadMore> -->
        <div class="content-html">
            <p id="video"></p>
            <!--<img v-for="(item, index) in imgs" :key="index" v-lazy="item" alt="" />-->
         	<p v-html="info.detail"></p> 
        </div>
    </div>
</template>
<script>
import LoadMore from '@src/components/base/load-more';
import { mapState, mapActions, mapGetters } from 'vuex';
export default {
    components: { LoadMore },
    data() {
        return {
            html: '',
            imgs: [],
            video: [],
            detals: '',
        };
    },
    computed: {
        ...mapState({
            info: state => state.productDetail.info
        })
    },
    mounted() {
        this.imgs = this.getimgsrc(this.info.detail);
// this.detals = this.info.detail
        //获取视频
        let video = document.getElementById('video');
        video.controls = false;
        var regex = /\<video(.+)video\>/g;
         let videohtml=regex.exec(this.info.detail.replace(/[\r\n]/g, ''))
         if(videohtml){
video.innerHTML = "'" + videohtml[0] + "'";
         }else{
             video.innerHTML = ""
         }
        
    },
    methods: {
        getimgsrc(htmlstr) {
            var reg = /<img.+?src=('|")?([^'"]+)('|")?(?:\s+|>)/gim;
            var arr = [];
            var tem = [];
            while ((tem = reg.exec(htmlstr))) {
                arr.push(tem[2]);
            }
            return arr;
        }
    }
};
</script>
<style lang="less">
.product-detail-content {
    background: #fff;
    overflow: hidden;
    .content-html {
        // padding: 5px;
        box-sizing: border-box;
        overflow: hidden;
        img {
            display: block;
            width: 100% !important;
            height: 100% !important;
        }
    }
    video {
        width: 100%;
        height: 100%;
        border-bottom: 1px solid #f6f6f6;
    }
}
</style>
