<template>
    <div class="header-info com-bottom-1px">
        <img :src="productItem.url || imgUrl">
        <div class="attribute-header-right">
            <p class="goodprice price-color">HK${{productItem.price | filterPrice}}</p>
            <p class="goodprice">库存：{{productItem.number}}{{info.unit | unit}}</p>
            <p class="goodprice">已选：{{productItem.specifications && productItem.specifications.join(" ")}}</p>
        </div>
        <a class="choose-attribute-close" href="javascript:void();" @click="closeClick" title="关闭">×</a>
    </div>
</template>
<script>
import { mapState, mapActions, mapGetters } from "vuex"
import unitJson from '@src/data/unit.json'
export default {
	data(){
		return{
			imgUrl: require('@src/assets/img/logo.png')
		}
	},
    computed: {
        ...mapState({
            info: state => state.productDetail.info,
            skuBtnType: state => state.productDetail.skuBtnType,
        }),
        ...mapGetters(["productItem"])
    },
    filters: {
        unit(unitCode) {
            let unit = unitJson.find(item => item.code == unitCode);
            if (unit) {
                return unit.name;
            } else {
                return "";
            }
        },
        filterPrice: function(num) {
			return Number(num).toFixed(2);
		}
    },
    methods: {
        ...mapActions(["isOpenSkuModule"]),
        closeClick() {
            this.isOpenSkuModule({
                open: false,
                skuBtnType: this.skuBtnType
            });
        }
    }
}
</script>
<style lang='less' scoped>
.header-info {
  height: 100px;
  /* margin-top: 24px; */
  color: #58595b;
  background: #fff;

  img {
    width: 90px;
    height: 90px;
    border: #f8f8f8 1px solid;
    border-radius: 4px;
    padding: 5px;
    background: #fff;
    margin-top: -15px;
    margin-left: 15px;
    float: left;
  }

  .attribute-header-right {
    margin-left: 10px;
    margin-top: 10px;
    float: left;
    overflow: hidden;
    width: 60%;
    .goodprice {
      display: block;
      width: 100%;
      overflow: hidden;
      color: #666;
      font-size: 12px;
      line-height: 150%;
      white-space: nowrap;
      text-overflow: ellipsis;
    }

    .price-color {
      color: #f23030;
      font-size: 18px;
    }
  }

  .choose-attribute-close {
    position: absolute;
    top: -20px !important;
    right: 8px;
    width: 38px;
    height: 38px;
    line-height: 25px;
    text-align: center;
    background-color: rgb(255, 255, 255);
    border-radius: 0px;
    border-top-right-radius: 3px;
    border-top-left-radius: 3px;
    z-index: 9999999;
    opacity: 1;
    border: 0px;
    font-size: 22px;
    color: #000;
    background-image: none;
  }
}
</style>
