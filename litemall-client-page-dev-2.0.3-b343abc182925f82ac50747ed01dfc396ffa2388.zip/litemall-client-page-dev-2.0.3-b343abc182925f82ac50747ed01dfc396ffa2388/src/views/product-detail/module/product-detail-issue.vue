<template>
    <div class="product-detail-issue vux-scrollable" :style="`height:${APP.winW}px`">
        <!-- <LoadMore tip="常见问题" :showLoading="false" style="margin: 1.6em auto 0em;"></LoadMore> -->
        <div class="issue" v-for="(item,index) in issue" :key="index">
            <b>{{index+1}}、{{item.question}}</b>
            <br/>
            <p v-html="answerHtml(item.answer)"></p>
        </div>
    </div>
</template>
<script>
import LoadMore from "@src/components/base/load-more"
import { mapState, mapActions, mapGetters } from "vuex";
export default {
    components: { LoadMore },
    computed: {
        ...mapState({
            issue: state => state.productDetail.issue
        }),
    },
    methods: {
        answerHtml(val) {
            return val.replace(/\n/g, "<br>")
        }
    }
}
</script>
<style lang='less'>
.product-detail-issue {
  background: #fff;
  overflow: hidden;
  padding-bottom: 20px;
  overflow-y: auto;
  .issue {
    padding: 10px;
    line-height: 28px;
    font-size: 13px;
    p {
      font-size: 12px;
    }
  }
}
</style>
