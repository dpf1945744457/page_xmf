<template>
    <div class="product-detail-attribute" :style="`min-height:${APP.winH}px`">
        <!-- <LoadMore tip="商品参数" :showLoading="false" style="margin: 1.6em auto 0em;"></LoadMore> -->
        <!-- 商品规格参数 -->
        <table class="attribute-table">
            <tbody>
                <tr v-for="(item,index) in attribute" :key="index">
                    <td>{{item.attribute}}</td>
                    <td>{{item.value}}</td>
                </tr>
            </tbody>
        </table>
    </div>
</template>
<script>
import LoadMore from "@src/components/base/load-more"
import { mapState, mapActions, mapGetters } from "vuex";
export default {
    components: { LoadMore },
    computed: {
        ...mapState({
            attribute: state => state.productDetail.attribute
        }),
    }
}
</script>
<style lang='less' scoped>
.product-detail-attribute {
  background: #fff;
  overflow: hidden;
}
.attribute-table {
  width: 100%;
}

.attribute-table tr:first-child {
  border-top: 1px solid #f1f1f1;
}

.attribute-table tr td:first-child {
  width: 70px;
  padding: 10px 15px;
  text-align: center;
  word-wrap: break-word;
  word-break: break-all;
  background-color: #f7f7f7;
}
.attribute-table td {
  padding: 10px;
  word-wrap: break-word;
  word-break: break-all;
  color: #3e4346;
  font-size: 12px;
  border-bottom: 1px solid #f1f1f1;
  background: #fff;
}
</style>
