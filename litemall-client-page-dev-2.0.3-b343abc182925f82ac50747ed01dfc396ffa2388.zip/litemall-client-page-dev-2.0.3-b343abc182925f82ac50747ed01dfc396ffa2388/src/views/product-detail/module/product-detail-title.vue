<template>
    <div class="product-title">
        <div class="goods-info-top">
            <h3 class="SZY-GOODS-NAME">{{ info.name }}</h3>
        </div>
        <span class="goods-depict color">{{info.brief}}</span>
         <span class="goods-depict" style="text-align: right;">月销量：{{salesNum(info.salesNum)}}</span>
        <div class="goods-price">
            <div class="now-prices">
                <!-- <em class="price-color">HK${{info.retailPrice}}元</em> -->
                <em class="price-color">HK${{ productItem.price  | filterPrice}}</em>
                <p class="price-color" v-if="productItem.taxFlag==0"  style="color: #f23030;font-size: 14px;">税费：HK${{ productItem.incomeTax  | filterPrice}}
                    <icon class="btn-share" name="share1" @click.native="$emit('on-share')" scale="3"></icon>
                </p>
                <icon class="btn-share" v-if="productItem.taxFlag==1" name="share1" @click.native="$emit('on-share')" scale="3"></icon>
                <!--<del>专柜价格：HK${{info.counterPrice | filterPrice}}</del>-->
                
            </div>
            <!-- <p>
                <span>运费</span>
                <span class="mail"> {{productItem.postage === 0 ? '免运费' : productItem.postage}} </span>
                <span class="surplus">剩余 {{productItem.number}}</span>
            </p> -->
        </div>
    </div>
</template>
<script>
import { mapState, mapActions, mapGetters } from 'vuex';
export default {
    computed: {
        ...mapState({
            info: state => state.productDetail.info
        }),
        ...mapGetters(['productItem', 'isLogin'])
    },
    filters: {
		filterPrice: function(num) {
			return Number(num).toFixed(2);
		}
    },
      methods: {
    salesNum(val) {
      console.log(val.toString());
      if (val.toString().length >= 5) {
          var s1 = val.toString().substring(0,val.toString().length-4)
          return s1+"万+"
      } else {
        return val;
      }
    },
  },
    mounted() {
//      debugger
       console.log("info",this.info);
       console.log(this.productItem);
       this.productItem.price=this.productItem.price!=0 ? this.productItem.price : this.info.retailPrice
       
    },
    
};
</script>
<style lang="less" scoped>
.product-title {
    width: 100%;
    overflow: hidden;
    background: #fff;
    padding-top: 0.5rem;
    .goods-info-top {
        width: 95%;
        margin: auto;
        font-weight: normal;
        color: #222;
        line-height: 20px;
        // height: 40px;
        display: -webkit-box !important;
        display: box !important;
        position: relative;
        h3 {
            position: relative;
            -webkit-box-flex: 1;
            box-flex: 1;
            //   height: 40px;
            overflow: hidden;
            font-weight: normal;
            font-size: 0.7rem;
            line-height: 20px;
            color: #222;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            display: -webkit-box;
        }
    }

    .goods-depict {
        display: block;
        width: 95%;
        margin: 0.3rem auto;
        line-height: 0.69rem;
        font-size: 12px;
        color: #797d82;
    }

    .goods-price {
        width: 95%;
        margin: 0.2rem auto 0.3rem;
        position: relative;
        .now-prices {
            line-height: 30px;
            font-size: 0.55rem;

            em {
                color: #f23030;
                font-size: 1rem;
                display: inline-block;
                margin-left: 0.2rem;
            }

            del {
                color: #999;
                color: #999;
            }
        }
        .mail {
            margin-left: 24px;
        }
        .surplus {
            float: right;
        }
    }

    .btn-share {
        float: right;
        color: rgba(255, 175, 0, 0.5);
        padding: 2px;
    }
}
</style>
