<!--  -->
<template>
  <div class="appIndex">
    <indexHeader v-if="isShowHeader"></indexHeader>
    <!--头部导航-->
    <headerNav></headerNav>
    <LoadingPage v-if="showPageLoading"></LoadingPage>
    <!--<div ref='tab' class="tabindex" v-show="!showPageLoading">
			<div>
    <div v-show="!isSearchStatus" class="index">-->
    <!-- banner -->
    <!--<Banner ></Banner>-->
    <!-- 商品 -->
    <!--<shop v-if="!showPageLoading"></shop>-->
    <!-- 推荐 -->
    <!--<recommend :extendList='extendList'></recommend>-->
    <!-- 商品类别 -->
    <!--<category ref='category' @getIndex='getIndex'></category>-->
    <!--商品列表-->
    <goodsList
      @isShowTabs="showTabs"
      @isHideTabs="hideTabs"
      @isHidetop="Hidetop"
      @isPageLoading="isShowPageLoading"
      ref="tab"
      :styleText="proStyle"
    ></goodsList>

    <!-- <Footer @toTop="toTop" v-if="!showPageLoading"></Footer> -->
    <!--</div>
			</div>
    </div>-->
    <!--底部导航-->
    <!--<footerNav></footerNav>-->
    <TabbarLayout></TabbarLayout>
    <!--<TabbarLayout v-if="isShowFooter"></TabbarLayout>-->
    
    <div
      style=" position: fixed;
    
     color: #fff;
    left: 10px;
     bottom: 15%;width: 40px;
    height: 40px;color: #000;"
      v-if="dlshow"
    >
      <van-image width="40" height="40"  :src="logo" @click="$router.push('/danglood')"></van-image>
      <van-icon name="close" size="16px" style="position: absolute; top: -12px;right:-12px" @click="closs" />
    </div>
  </div>
</template>

<script>
import Banner from "./module/banner";
import logo from "../../assets/img/pop_appdownload.png";

import category from "./module/shopCategory";
import shop from "./module/shop";
import recommend from "./module/recommend";
import indexHeader from "./module/header";
import headerNav from "./module/headerNav";
import goodsList from "./module/goodsList";
import footerNav from "./module/footerNav";
import LoadingPage from "@src/components/base/loadingPage";
import { getHomeData } from "@src/apis/home.js";
import { mapState, mapActions, mapGetters } from "vuex";
import TabbarLayout from "@src/layouts/tabbar.vue";
import Footer from "./module/footer";
// import routeLeaveByisRoutePush from '@src/mixins/routeLeaveByisRoutePush.js';
import BScroll from "better-scroll";
export default {
  components: {
    Banner,
    indexHeader,
    headerNav,
    logo,
    goodsList,
    footerNav,
    category,
    LoadingPage,
    TabbarLayout,
    shop,
    Footer,
    recommend
  },
  // mixins: [routeLeaveByisRoutePush],
  data() {
    return {
      showPageLoading: true,
      isSearchStatus: false,
      flag_scroll: false,
      dlshow: true,
      scroll: "",
      logo: logo,
      extendList: [] || {}, //
      isShowFooter: true,
      isShowHeader: true,
      isShowMyHeader: false,
      proStyle: false
    };
  },
  computed: {
    ...mapState({
      classifyList: state => state.home.classifyList
    }),
    ...mapState({
      hotGoodsList: state => state.home.hotGoodsList
    }),
    ...mapState({
      newGoodsList: state => state.home.newGoodsList
    })
  },
  methods: {
    ...mapActions(["setHomeData"]),
    async getData() {
      let data = await getHomeData({});
      this.showPageLoading = false;
      this.setHomeData(data);
      this.extendList = data.extendList;
    },
    getIndex(index) {
      let e = this.$refs.category.$refs.shopScroll[index];
      this.scroll.scrollToElement(e, 300);
    },
    //	       隐藏页面loading
    isShowPageLoading() {
      this.showPageLoading = false;
    },
    //	       显示导航栏
    showTabs() {
      this.isShowFooter = true;
      this.isShowHeader = true;
      this.isShowMyHeader = false;
      this.proStyle = false;
    },
    //	       隐藏导航栏
    hideTabs() {
      this.isShowFooter = false;
      this.isShowHeader = false;
      this.isShowMyHeader = true;
      this.proStyle = true;
    },
    Hidetop(scrollTop) {
      if (scrollTop > 1000) {
        this.flag_scroll = true;
      } else {
        this.flag_scroll = false;
      }
    },
    toTop() {
      document.body.scrollTop = 0;
      document.documentElement.scrollTop = 0;
    },
    closs() {
      this.dlshow = false;
    },
   
    handleScroll() {
      let scrollHeight =
        document.documentElement.scrollHeight || document.body.scrollHeight;
      // 获取页面滚动距离顶部的高度,  window.pageYOffse 兼容苹果
      let scrollTop =
        document.documentElement.scrollTop ||
        window.pageYOffset ||
        document.body.scrollTop;
      // 获取页面的可视高度
      let clientHeight =
        document.documentElement.clientHeight || document.body.clientHeight;

      if (scrollHeight - scrollTop - clientHeight < 100) {
      }
    },
    getCurrentSource() {
      let isApp = this.$route.query.isApp;
      isApp && this.$store.commit("changeCurrentSourceIsApp", isApp);
    }
  },
  mounted() {
    this.getCurrentSource();

    this.getData();
    //			this.toTop();
    window.addEventListener("scroll", this.handleScroll, true);
    //			this.$nextTick(() => {
    //				this.scroll = new BScroll(this.$refs.tab, {
    //					click: true,
    //				});
    //			})
  },
  destroyed() {
    window.removeEventListener("scroll", this.handleScroll, true);
  }
};
</script>
<style lang="less" scoped>
.backTop {
  position: fixed;
  background: rgba(1, 1, 1, 0.2);
  color: #fff;
  right: 10px;
  bottom: 15%;
}
.appIndex {
  // position: relative;
  width: 100%;
  min-height: 100%;
  background: #f2f2f2;
  /*overflow-y: scroll;*/
  .tabindex {
    height: 90%;
    overflow: hidden;
    font-size: 14px;
    // position: absolute;
    // width: 100%;
    // top: 44px;
    // bottom: 56px;
  }
}

/deep/ .weui-tabbar {
  height: 50px;
}
</style>