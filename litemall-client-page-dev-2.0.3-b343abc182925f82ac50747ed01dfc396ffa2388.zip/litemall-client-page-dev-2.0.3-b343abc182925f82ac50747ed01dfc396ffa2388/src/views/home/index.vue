<!--  -->
<template>
    <TabbarLayout :showPageLoading="showPageLoading">
        <!-- <HeaderSearch ref="HeaderSearch" @on-show-change="show=>isSearchStatus = show"></HeaderSearch> -->

        <div v-show="!isSearchStatus">
            <!-- banner -->
            <Banner ref="Banner"></Banner>

            <!--滚动播报-->
            <Rolling></Rolling>

            <!-- 分类 -->
            <GridList ref="GridList"></GridList>

            <!-- 新品首发 -->
            <FloorGoodsList :item="item" :index="index" v-for="(item,index) in floorGoodsList" :key="index"></FloorGoodsList>

            <!-- 底部导航 -->
            <Footer></Footer>

        </div>
    </TabbarLayout>
</template>

<script>
import TabbarLayout from "@src/layouts/tabbar.vue"
import Rolling from "@src/components/base/rolling/index.vue"
import Banner from './module/banner'
import GridList from './module/gridList'
import BrandList from './module/brandList'
import FloorGoodsList from './module/floorGoodsList'
import GoodList from './module/goodList'
import Footer from './module/footer'
import { getHomeData } from '@src/apis/home.js'
import { mapState, mapActions, mapGetters } from "vuex";
import routeLeaveByisRoutePush from '@src/mixins/routeLeaveByisRoutePush.js'

export default {
    components: {
        TabbarLayout, Banner, Rolling, GridList, BrandList, FloorGoodsList, GoodList, Footer,
        HeaderSearch: () => import(/* webpackChunkName: "header-search" */ '@src/components/public/header-search.vue'),
    },
    mixins: [routeLeaveByisRoutePush],
    data() {
        return {
            showPageLoading: true,
            isSearchStatus: false,
        }
    },
    async activated() {
        //判断是解决 请求失败时 发起二次请求
        if (this.floorGoodsList.length === 0) {
            this.showPageLoading = true;
            let data = await getHomeData({});

            this.showPageLoading = false;
            this.setHomeData(data);
        }
    },
    computed: {
        ...mapState({ floorGoodsList: state => state.home.floorGoodsList }),
        ...mapState({ hotGoodsList: state => state.home.hotGoodsList }),
        ...mapState({ newGoodsList: state => state.home.newGoodsList }),
    },
    methods: {
        ...mapActions(["setHomeData"])
    }
}
</script>
<style lang='less' scoped>
</style>
