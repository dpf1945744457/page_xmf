<template>
	<div class="footerNav">
		<ul>
			<li class="active">
				<div class="icon"></div>
				<div class="title">首页</div>
			</li>
			<li>
				<div class="icon"></div>
				<div class="title">购物车</div>
			</li>
			<li>
				<div class="icon"></div>
				<div class="title">餐饮</div>
			</li>
			<li>
				<div class="icon"></div>
				<div class="title">新闻</div>
			</li>
			<li>
				<div class="icon"></div>
				<div class="title">充电宝</div>
			</li>
			<li>
				<div class="icon"></div>
				<div class="title">个人中心</div>
			</li>
		</ul>
	</div>
</template>

<script>
</script>

<style lang="less" scoped="scoped">
	.footerNav{
		width: 100%;
		height: 50px;
		background: #FFFFFF;
		font-family: PingFang-SC-Medium;
		font-size: 10px;
		color: #999999;
    	overflow:hidden;
		ul{
			display: -webkit-box;
		    display: -ms-flexbox;
		    display: flex;
		    -webkit-box-align: middle;
		    -ms-flex-align: middle;
		    align-items: middle;
		    /*overflow: auto;*/
		    overflow-x: scroll;
            -webkit-overflow-scrolling:touch;
		    li{
				float: left;
				width: 62.5px;
				height: 50px;
				text-align: center;
				-ms-flex-negative: 0;
    			flex-shrink: 0;
				.icon{
					margin: 0 auto;
					width: 24px;
					height: 24px;
					background: pink;
				}
			}
			.active{
				color: #FF4A10;
			}
		}
		ul::-webkit-scrollbar {
			display: none;
		}
		
	}
</style>