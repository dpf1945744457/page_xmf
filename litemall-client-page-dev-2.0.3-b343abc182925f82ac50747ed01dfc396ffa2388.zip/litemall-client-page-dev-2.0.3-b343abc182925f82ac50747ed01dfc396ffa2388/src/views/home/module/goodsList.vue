<template>
  <div class="goodsList" :class="{'newStyle': styleText}" ref="list">
    <van-pull-refresh v-model="isDownLoading" @refresh="onRefresh">
      <van-list
        v-model="isUpLoading"
        :finished="upFinished"
        finished-text="暂无更多数据"
        :offset="offset"
        :immediate-check="false"
        @load="onLoad"
        :error.sync="error"
        error-text="请求失败，点击重新加载"
      >
        <div v-for="(item,index) in lists" :key="index" class="goods-list">
          <div @click="toUrl(item.id)">
            <img :src="item.picUrl" class="goodsPic" />
            <p class="goodsName">{{item.name}}</p>
          </div>
          <div class="otherInfo">
            <div class="priceBox">
              <span class="dollarSign">HK$</span>
              <span class="price">{{item.retailPrice | filterPrice}}</span>
            </div>

            <div class="numBox">
              <div class="titleBox">
                <p class="title">数量</p>
                <p class="icon">×</p>
              </div>
              <!--<p class="number other" v-if="currentGoodsId != item.id">{{otherNumber}}</p>-->
              <!--<p class="number current" v-if="item.id == _item.goodsId" v-for="(_item,_index) in newCartList">{{_item.number}}</p>-->
              <p class="number current">{{item.number}}</p>
              <div class="reduceBox" @click="reduceCount(item,index)">
                <span>-</span>
              </div>
              <div class="addBox" @click="addCount(item.id,index)">
                <!--<div class="addBox" @click="clickAddCart">-->
                <span>+</span>
              </div>
            </div>
          </div>
        </div>
      </van-list>
    </van-pull-refresh>
    <div class="emptyBox" v-if="isEmpty">
      <Nodata :imgurl="require('@src/assets/img/bg_empty_data.png')" content="暂无数据"></Nodata>
    </div>
    <Footer v-if="upFinished" @toTop="toTop"></Footer>
    <div class="backTop"  @click="backTop" v-show="flag_scroll"></div>
    <!-- <van-button type="default"  @click="backTop" v-show="flag_scroll">
      
    </van-button> -->
    <van-dialog
      v-model="show"
      @confirm="add"
      :showConfirmButton="false"
      :closeOnClickOverlay="true"
      style="color: rgb(137, 82, 0);font-size: 16px;line-height: 20px;overflow: initial; z-index:999999"
    >
      <div class="divcont">
        <div style="height: 350px;
    overflow: auto;">
          <p v-for="inti in desc" :key="inti">{{inti}}</p>
          <!-- <p>
            1.禁止拍下单件奶粉产品链接(已注明【请勿拍】/只能拍下两件套装奶
            粉产品);
          </p>
          <p>
            2.一个奶粉订单有且仅有一个奶粉产品链接(2件套装奶粉),最多拍两
            件,不能与其他产品合并购买;
          </p>
          <p>
            3.每个购买账号一天最多只能购买8罐奶粉,且依照中国海关规定,每个
            中国大陆身份证每年个人年度跨境购物限值26000RMB;
          </p>
          <P>4.(2件套装奶粉)均可享受店铺所有优惠活动（优惠活动解释权归产品方所有）</P>
          <p>
            5.由于香港奶粉禁令,所有奶粉均为澳门跨境发货;发货准备需要2周左
            右,如急件请谨慎下单;
          </p>
          <p>6.奶粉产品有效期均已在详情页注明,以实际到货的产品的有效期为准;</p>
          <p style="color:red">*如未能遵守以上奶粉产品购物准则,我们将做不发货退款处理，感谢理解。</p>-->
        </div>
        <span
          style="position: absolute;bottom: -45px;margin: auto;left: 0; right: 0;width: 25px; color: #fff;font-size:30px;"
          @click="add"
        >
          <van-icon name="close" />
        </span>
      </div>
    </van-dialog>
  </div>
</template>

<script>
import { getGoodsList } from "@src/apis/home.js";
import Footer from "../module/footer";
import {
  getCartIndex,
  postCartChecked,
  postCartDelete,
  postCartUpdate
} from "@src/apis/cart.js";
import Bus from "@src/apis/Bus.js";
import Nodata from "@src/components/base/no-data";
import { mapState, mapActions, mapGetters } from "vuex";
const Big = require("big.js");
export default {
  components: {
    Nodata,
    Footer
  },

  props: {
    styleText: {
      type: Boolean
    }
  },
  data() {
    return {
      page: 1,
      size: 5,
      desc: "",
      flag_scroll: false,
      isDownLoading: false,
      lists: [],
      isUpLoading: false,
      upFinished: false,
      error: false,
      offset: 100,
      classifyId: "",
      isEmpty: false,
      show: false,
      currentNumber: 0,
      otherNumber: 0,
      currentGoodsId: "",
      min: 0,
      max: 5,
      step: 1,
      startX: 0,
      startY: 0,
      moveEndX: 0,
      moveEndY: 0,
      cartList: [],
      newCartList: [],
      last: 0
    };
  },
  mounted() {
    Bus.$on("classifyId", data => {
      if (data.name == "奶粉" && data.desc) {
        this.desc = data.desc.split("||");
        this.show = true;
      }
      this.changeNav(data.id);
    });
    this.getLists();
    window.addEventListener("scroll", this.handleScroll);
  },

  watch: {
    "$store.state.productDetail.goodscount": function(a, b) {
      this.getCartList();
    }
  },

  computed: {
    ...mapState({
      productDetail: state => state.productDetail,
      info: state => state.productDetail.info,
      userHasCollect: state => state.productDetail.userHasCollect
    }),
    ...mapGetters(["productItem", "isLogin"])
  },
  // created() {
  // this.getLists();
  //      	this.getCartGoodscount();
  // },
  methods: {
    ...mapActions([
      "getProductDetailById",
      "addCart",
      "buyNow",
      "postCollectByGoods",
      "getCartGoodscount"
    ]),

    handleScroll() {
      let scrollTop =
        window.pageYOffset ||
        document.documentElement.scrollTop ||
        document.body.scrollTop; // 滚动条偏移量
      if (scrollTop >= 1) {
        this.$emit("isHideTabs");
      } else {
        this.$emit("isShowTabs");
      }

       if (scrollTop > 1000) {
        this.flag_scroll = true;
      } else {
        this.flag_scroll = false;
      }
      // this.$emit("isHidetop", scrollTop);
    },
    backTop() {
      document.documentElement.scrollTop = 0;
      document.body.scrollTop = 0;
    },
    add() {
      this.show = false;
      localStorage.setItem("Notice", true);
    },
    getCartList() {
      if (!this.isLogin) {
        return;
      }
      getCartIndex().then(data => {
        if (data && data.cartList.length > 0) {
          this.cartList = data.cartList;
          //	                    var temp = {};
          //	                    var that = this;
          //	                    for(var i in this.cartList){
          //	                    	var key = this.cartList[i].goodsId;
          //	                    	if(temp[key]){
          //	                    		temp[key].goodsId = temp[key].goodsId;
          //	                    		temp[key].number = temp[key].number + that.cartList[i].number;
          //	                    	}else{
          //	                    		temp[key] = {};
          //	                    		temp[key].goodsId = that.cartList[i].goodsId;
          //	                    		temp[key].number = that.cartList[i].number;
          //	                    	}
          //	                    }
          //	                    for(var k in temp){
          //					        this.newCartList.push(temp[k]);
          //				      	}
          //	                    const result = this.newCartList.reduce((acc, cur) => {
          //						    const ids = acc.map(item => item.goodsId);
          //						    return ids.includes(cur.goodsId) ? acc : [...acc, cur];
          //						}, []);
          //
          //						for(var i = 0; i < this.lists.length; i++) {
          //							for(var k = 0; k < result.length; k++) {
          //								if(result[k].goodsId == this.lists[i].id) {
          //									this.lists[i].number = result[k].number;
          //								}
          //							}
          //						}

          for (var i = 0; i < this.lists.length; i++) {
            this.lists[i].number = 0;
            for (var k = 0; k < this.cartList.length; k++) {
              if (this.cartList[k].goodsId == this.lists[i].id) {
                this.lists[i].number += this.cartList[k].number;
              }
            }
          }
        }
      });
    },
    toTop() {
      document.body.scrollTop = 0;
      document.documentElement.scrollTop = 0;
    },
    async reduceCount(item, index) {
      console.log(item);
      console.log(this.cartList);

      let id = item.id;
      if (item.number > 0) {
        await this.getProductDetailById(id);
        //是否登录
        if (!this.isLogin) {
          this.$router.push({
            path: "/phoneLogin",
            query: {
              redirect: this.$route.fullPath
            }
          });
        } else {
          this.currentGoodsId = id;
          var detail = this.productDetail;

          var specificationList = detail["specificationList"];
          var lists = this.lists;
          var cartLists = this.cartList;
          var num = lists[index].number;
          //	最少为0
          if (num > this.min) {
            //是否有可选规格
            if (specificationList[0].valueList.length > 1) {
              this.$router.push({
                path: "/cart"
              });
            } else {
              for (var j = 0; j < cartLists.length; j++) {
                if (cartLists[j].goodsId == id) {
                  postCartUpdate({
                    productId: cartLists[j].productId,
                    goodsId: cartLists[j].goodsId,
                    number: num - 1,
                    id: cartLists[j].id
                  }).then(result => {
                    num = num - 1;
                    lists[index].number = num;
                    this.getCartList();
                    this.getCartGoodscount();
                  });
                }
              }
            }
          } else {
            this.$toast({
              message: "亲,实在不能再少了",
              iconClass: "icon-success_black"
            });
          }
        }
      }
    },
    //			节流
    throttle(interval) {
      let now = +new Date();
      if (now - this.last >= interval) {
        this.last = now;
        return true;
      } else {
        return false;
      }
    },
    async addCount(id, index) {
      await this.getProductDetailById(id);
      if (!this.throttle(500)) {
        this.$toast({
          message: "操作过于频繁,请稍后重试",
          iconClass: "icon-success_black"
        });
        return;
      }
      //是否登录
      if (!this.isLogin) {
        this.$router.push({
          path: "/phoneLogin",
          query: {
            redirect: this.$route.fullPath
          }
        });
      } else {
        this.currentGoodsId = id;
        var detail = this.productDetail;
        var stock = this.productItem.number;
        var specificationList = detail["specificationList"];
        console.log(specificationList[0].valueList.length);
        var lists = this.lists;
        var num = lists[index].number;
        //	最多可加入购物车5个

        //					if(num < stock){

        //是否有可选规格
        if (specificationList[0] && specificationList[0].valueList.length > 1) {
          this.goDetails(id);
        } else {
          if (num < this.max) {
            this.addCart().then(
              () => {
                num = num + 1;
                lists[index].number = num;
                this.$toast({
                  message: "加入购物车成功",
                  iconClass: "icon-success_black"
                });
                this.getCartList();
              },
              msg => {
                this.$toast(msg);
              }
            );
          } else {
            this.$toast({
              message: "亲,此商品加入购物车数量已达上限",
              iconClass: "icon-success_black"
            });
          }
        }

        //					}else{
        //						this.$toast({
        //							message: "亲,此商品库存不足",
        //							iconClass: "icon-success_black"
        //						});
        //					}
      }
    },
    //			选择规格
    async goDetails(id) {
      this.$router.push({
        path: `/goodsSpecifications/${id}`
      });
    },
    async getLists(flag) {
      var that = this;
      let res = await getGoodsList({
        page: this.page,
        size: this.size,
        classifyId: this.classifyId
      });
      if (res) {
        this.$emit("isPageLoading");
        if (res.count > 0) {
          if (flag) {
            this.lists = [];
          }
          this.isEmpty = false;
          let rows = res.goodsList;
          // 给每条数据添加 number
          rows.forEach(item => {
            this.$set(item, "number", 0);
          });
          // 加载状态结束
          this.isUpLoading = false;
          this.upFinished = false;

          this.lists = [...this.lists, ...rows];
          this.getCartList();

          // 数据全部加载完成
          if (this.lists.length >= res.count) {
            this.upFinished = true;
          }

          // if(rows == null || rows.length === 0) {
          // 	// 加载结束
          // 	this.upFinished = true;
          // 	return;
          // }
          // if(rows.length < this.size) {
          // 	// 最后一页不足5条的情况
          // 	this.upFinished = true;
          // }
          // if(this.page === 1) {
          // 	this.lists = rows;
          // } else {
          // 	for(let i of rows) {
          // 		this.lists.push(i)
          // 	}
          // }
        } else {
          this.lists = [];
          this.isEmpty = true;
        }
      } else {
        this.error = true;
      }
    },
    onLoad() {
      this.page++;
      this.getLists();

      // this.isUpLoading = false;
      // if(this.lists.length > 0) {
      // setTimeout(() => {
      // 	this.page++;
      // 	this.getLists();
      // 	//						this.isUpLoading = false;
      // }, 500);
      // }
    },

    // 初始化
    init() {
      this.page = 1;
      this.lists = [];
    },

    onRefresh() {
      // this.init()
      this.isDownLoading = false;
      this.isUpLoading = false;
      this.upFinished = false;
      this.page = 1;
      this.getLists(true);
      // setTimeout(() => {
      // 	this.isDownLoading = false;
      // 	this.getLists(); // 加载数据
      // }, 300)
    },
    changeNav(id) {
      console.log(id);

      this.classifyId = id;
      this.isDownLoading = false;
      this.isUpLoading = false;
      this.upFinished = false;
      this.page = 1;
      this.getLists(1); // 加载数据
      document.body.scrollTop = 2;
      document.documentElement.scrollTop = 2;
    },
    // touchstart() {
    //   this.startX = event.changedTouches[0].pageX;
    //   this.startY = event.changedTouches[0].pageY;
    // },
    // touchmove() {
    //   var moveEndX = event.changedTouches[0].pageX;
    //   var moveEndY = event.changedTouches[0].pageY;
    //   var X = moveEndX - this.startX;
    //   var Y = moveEndY - this.startY;
    //   var that = this;
    //   if (Math.abs(X) > Math.abs(Y) && X > 0) {
    //     //					console.log('left 2 right'
    //   } else if (Math.abs(X) > Math.abs(Y) && X < 0) {
    //     //					console.log('right 2 left')
    //   } else if (Math.abs(Y) > Math.abs(X) && Y > 0) {
    //     //					console.log('top 2 bottom');
    //     that.$emit("isShowTabs");
    //   } else if (Math.abs(Y) > Math.abs(X) && Y < 0) {
    //     //					console.log('bottom 2 top');
    //     that.$emit("isHideTabs");
    //   } else {
    //     //					console.log('just touch')
    //   }
    // },
    toUrl(id) {
      this.$router.push({
        path: `/product/${id}`
      });
    }
  },

  filters: {
    filterPrice: function(num) {
      return Number(num).toFixed(2);
    }
  }
};
</script>
<style lang="less" scoped="scoped">
.divcont {
  background: url("./pop_bg.png");
  background-size: 100% 100%;
  padding: 50px 30px;
}
.newStyle {
  margin-top: 44px !important;
}
.backTop {
  position: fixed;
  background: rgba(1, 1, 1, 0.2);
  color: #fff;
  right: 10px;
  bottom: 15%;
  width: 40px;
  height: 40px;
  background-image: url('./1.png');
  background-size: cover;
  border-radius: 50%;
}
.goodsList {
  padding: 10px;
  /*width: 355px;*/
  height: 100vh;
  font-family: PingFangSC-Medium;
  /*overflow-y: scroll;*/
  background: #f2f2f2;
  box-sizing: border-box;
  .van-pull-refresh {
    -webkit-overflow-scrolling: touch !important;
  }
  .goods-list {
    margin-bottom: 10px;
    padding-bottom: 10px;
    width: 100%;
    background: #ffffff;
    border-radius: 6px;
    box-sizing: border-box;
    .goodsPic {
      width: 100%;
      height: 206px;
      border-top-left-radius: 6px;
      border-top-right-radius: 6px;
    }
    .goodsName {
      margin: 6px 0;
      padding-left: 12px;
      font-size: 19px;
      color: #333333;
      box-sizing: border-box;
    }
    .otherInfo {
      margin: 0 12px;
      display: flex;
      .priceBox {
        flex: 1;
        color: #ff4a10;
        .dollarSign {
          font-size: 15px;
        }
        .price {
          font-size: 24px;
        }
      }
      .numBox {
        flex: 1;
        text-align: right;
        .titleBox {
          display: inline-block;
          font-family: PingFangSC-Regular;
          font-size: 11px;
          color: #333333;
          text-align: center;
          .icon {
            height: 20px;
            line-height: 18px;
            font-family: PingFangSC-Regular;
            font-size: 20px;
            color: #333333;
          }
        }
        .number {
          margin-left: 4px;
          display: inline-block;
          font-family: PingFangSC-Regular;
          font-size: 26px;
          color: #333333;
          vertical-align: top;
        }
        .reduceBox {
          margin: 0 8px;
          display: inline-block;
          width: 32px;
          height: 32px;
          line-height: 32px;
          background: rgba(247, 207, 32, 0.3);
          border: 1px solid #f7cf20;
          border-radius: 6px;
          text-align: center;
          vertical-align: top;
          box-sizing: border-box;
        }
        .addBox {
          display: inline-block;
          width: 32px;
          height: 32px;
          line-height: 32px;
          background: #f7cf20;
          border-radius: 6px;
          text-align: center;
          vertical-align: top;
        }
      }
    }
  }
  .emptyBox {
    margin-bottom: 150px;
  }
}
</style>