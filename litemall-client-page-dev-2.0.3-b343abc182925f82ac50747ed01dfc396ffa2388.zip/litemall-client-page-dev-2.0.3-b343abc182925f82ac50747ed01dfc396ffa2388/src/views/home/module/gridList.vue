<template>
    <div class="grid-list">
        <grid :no-border="true" :show-lr-borders="false" :show-vertical-dividers="false" :cols="3">
            <grid-item :label="item.name" v-for="(item,index) in gridList" :key="index" @click.native="$router.push({path:'/product',query:{categoryId:item.id}})">
                <img slot="icon" v-lazy="item.iconUrl">
            </grid-item>
        </grid>
    </div>
</template>

<script>
import { Grid, GridItem } from "@src/components/base/grid";
import { mapState, mapActions, mapGetters } from "vuex";
export default {
    components: {
        Grid,
        GridItem
    },
    computed: {
        ...mapState({ gridList: state => state.home.gridList }),
    }
}
</script>

<style lang="less" scoped>
.grid-list {
  background-color: #fff;
  padding: 10px 0;
  min-height: 75px;
  a {
    color: #222 !important;
  }
}
</style>
