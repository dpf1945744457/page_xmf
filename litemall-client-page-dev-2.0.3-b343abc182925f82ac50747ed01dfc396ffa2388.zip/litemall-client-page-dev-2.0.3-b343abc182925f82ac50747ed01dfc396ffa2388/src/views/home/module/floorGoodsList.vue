<template>
    <div class="goods-list">
        <div class="picUrl">
            <img :src="gridList[index].picUrl" alt="" @click="$router.push({path:'/product',query:{categoryId:item.id}})">
        </div>
        <div class="content-box clearfix">
            <a href="javascript:void(0);" class="content-title com-bottom-1px" @click="$router.push({path:'/product',query:{categoryId:item.id}})">
                <div class="l">
                    <img :src="gridList[index].iconUrl" alt="">
                    <span>{{item.name}}</span>
                </div>
                <span class="">查看更多</span>
                <icon name="linkright" scale="2"></icon>
            </a>
            <GoodsItem class="goods-item" v-for="(item,index) in item.goodsList.slice(0,2)" :key="index" :item="item" @click.native="$router.push({path:`/product/${item.id}`})">
                <span slot="actionIcon" class="good-btn">去抢购</span>
            </GoodsItem>
        </div>
    </div>
</template>

<script>
import GoodsItem from '@src/components/base/goodsItem/index.vue'
import Nodata from "@src/components/base/no-data"
import Title from './title.vue'
import { mapState, mapActions, mapGetters } from "vuex";
export default {
    props: ["item", "index"],
    components: { GoodsItem, Nodata, Title },
    computed: {
        ...mapState({ gridList: state => state.home.gridList }),
    },
}
</script>

<style lang="less" scoped>
.goods-list {
  min-height: 150px;
  background: #fff;
  padding-bottom: 10px;

  .picUrl {
    img {
      width: 100%;
    }
    // img[lazy="loading"] {
    //   height: 115px;
    //   width: 100%;
    // }
    // img[lazy="error"] {
    //   transform: translateX(-50%);
    //   margin-left: 50%;
    //   width: 100px;
    //   padding: 10px 0 35px;
    // }
    // img[lazy="loaded"] {
    //   min-height: 115px;
    //   width: 100%;
    // }
  }

  .content-box {
    width: 95%;
    margin: -25px auto 0;
    background: #fff;
    position: relative;
    border-radius: 3px;

    .content-title {
      height: 40px;
      display: flex;
      align-items: center;
      padding: 0 10px;
      .l {
        flex: 1;
        span {
          vertical-align: middle;
        }
      }
      img {
        width: 25px;
      }
      .more {
        float: right;
      }
    }

    .goods-item {
      padding: 10px;
      .good-btn {
        display: block;
        width: 52px;
        height: 18px;
        line-height: 18px;
        background: rgba(255, 102, 0, 1);
        color: rgba(255, 255, 255, 1);
        font-size: 12px;
        text-align: right;
        margin-right: 5px;
        padding-right: 4px;
        border-radius: 9px 0 0 9px;
      }
    }
  }
}
</style>
