<template>
    <div class="home-footer">
        <CommonFooterLinks :links="linkList"></CommonFooterLinks>
        <!--<CommonFooterCopyright></CommonFooterCopyright>-->
        <WxQrcode ref="WxQrcode"></WxQrcode>
    </div>
</template>

<script>
import CommonFooterLinks from '@src/components/base/common-footer/footer-links.vue';
import CommonFooterCopyright from '@src/components/base/common-footer/footer-copyright.vue';
import WxQrcode from '@src/components/public/wx-qrcode';
import { mapState, mapActions, mapGetters } from 'vuex';
import Bus from '@src/apis/Bus.js';
export default {
    components: { CommonFooterLinks, CommonFooterCopyright, WxQrcode },
    computed: {
        ...mapGetters(['isLogin'])
    },
    props: ['scroll'],
    mounted() {
    	
    },
    data() {
        return {
            linkList: [
                {
                    name: '个人中心',
                    cb: () => {
                        this.$router.push('/phoneLogin');
                    }
                },
                {
                    name: '关注我们',
                    cb: () => {
                        this.$refs.WxQrcode.open();
                    }
                },
                // {
                //   name: "申请入驻",
                //   cb: () => { this.$router.push("/apply") }
                // },
                {
                    name: '返回顶部',
                    cb: () => {
                        this.$emit('toTop');
                    }
                }
            ]
        };
    }
};
</script>

<style lang="less" scoped>
.home-footer {
	/*position: absolute;
	bottom: 0;
	left: 0;*/
    background: #fff;
    padding: 20px 0;
}
</style>
