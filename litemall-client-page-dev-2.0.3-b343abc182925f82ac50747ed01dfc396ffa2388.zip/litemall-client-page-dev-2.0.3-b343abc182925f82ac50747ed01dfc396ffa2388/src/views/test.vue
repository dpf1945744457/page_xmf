<template>
    <div class="test" @click="open">
        <div class="li" v-for="item in 30">item{{ item }}</div>
        <div class="pop" v-if="isTrue"></div>
        <div class="popBox" v-if="isTrue">
            <ul>
                <li @click.stop="checkArea()" v-for="item in 30">{{ item }}</li>
            </ul>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            isTrue: false,
            scrollTop: undefined, // 距离顶端的值
            className: 'modalOpen'
        };
    },
    methods: {
        open() {
            this.scrollTop = document.scrollingElement.scrollTop;
            document.body.classList.add(this.className);
            document.body.style.top = `-${this.scrollTop}px`;
            this.isTrue = true;
        },
        checkArea() {
        	
            this.isTrue = false;
            document.body.classList.remove(this.className);
            document.scrollingElement.scrollTop = this.scrollTop;
        }
    }
};
</script>

<style lang="less" scoped>
.test {
    width: 100%;
    .li {
        line-height: 60px;
    }
    .pop {
        position: fixed;
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.3);
    }
    .popBox {
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        top: 0;
        z-index: 9999;
        ul {
            height: 100%;
            width: 100%;
            overflow: auto;
            -webkit-overflow-scrolling: touch;
            li {
                line-height: 2rem;
                text-align: left;
                padding: 0 1.2rem;
                border-bottom: 1px solid #eeee;
            }
        }
    }
}
</style>
