<template>
    <div class="header">
        <!-- header头部 -->
        <LoginHeader></LoginHeader>
        <Uinput label="手机号" type="tel" v-model="mobile" placeholder="请输入手机号" :topLine="true" maxLength="11"></Uinput>
        <Uinput label="验证码" type="tel" v-model="code" placeholder="请输入验证码" :topLine="true" maxLength="6" width="50%">
            <TimerBtn ref="TimerBtn" :text="'发送验证码'" :time="60" :cb="sendCode"></TimerBtn>
        </Uinput>
        <Xbutton class="btn" type="dd" @click.native="login">登录</Xbutton>
    </div>
</template>

<script>
import HeaderLayout from "@src/layouts/headerLayout.vue"
import LoginHeader from "./module/login-header.vue"
import Xbutton from "@src/components/base/x-button"
import Uinput from "@src/components/base/u-input"
import TimerBtn from "@src/components/base/timer-btn"
import { isWeixin } from '@src/utils/wx.js'
import { getLoginCode ,wxBindingPh} from '@src/apis/user.js'
import regExp from '@src/utils/regExp.js'
import { mapState, mapActions, mapGetters } from "vuex";
import { setStorage, getStorage, removeStorage } from "@src/utils/storage.js"
import { getToken, setToken, removeToken } from '@src/utils/auth.js'
import channel from '@src/utils/channel.js'
export default {
    components: { HeaderLayout, LoginHeader, Xbutton, Uinput, TimerBtn },
    data() {
        return {
            redirectUrl: this.$route.query['redirect'] || getStorage("redirectUrl"),
            mobile: "",
            code: ""
        }
    },
    mounted() {
        // 如果没有储存标识 和 有重定向url的话 设置isBack为真就行
        if (this.redirectUrl) setStorage("redirectUrl", this.redirectUrl);
    },
    beforeRouteEnter(to, from, next) {
        if (isWeixin() && !getToken() && process.env.NODE_ENV === 'production') {

            let redirectUrl0 = encodeURIComponent(`${window.location.href.split("#")[0]}#/bind`);
            // let redirectUrl1 = encodeURIComponent(`${window.location.href.split("#")[0]}#${from.fullPath}`);
            let redirectUrl2 = encodeURIComponent(`${location.origin}/wx/oauth/loginWxWeb?redirectURL=${redirectUrl0}`);
            let redirectUrl3 = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxa56f673775b525bb&redirect_uri=${redirectUrl2}&response_type=code&scope=snsapi_userinfo&state=10001#wechat_redirect`;
//          let redirectUrl3 = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxa418d63f5b2ab75c&redirect_uri=${redirectUrl2}&response_type=code&scope=snsapi_userinfo&state=10001#wechat_redirect`;
            
            window.location.replace(redirectUrl3);

        } else {
            next();
        }
    },
    methods: {
        ...mapActions(["userLoginByMobile"]),
        async sendCode() {

//          if (!regExp.mobile.reg.test(this.mobile)) {
//              this.$toast(regExp.mobile.errMsg);
//              return false;
//          }
            let data = await getLoginCode({ phone: this.mobile });
            this.$refs.TimerBtn.disabled = true;
            this.$refs.TimerBtn.timer();
            this.$toast({
                message: "发送验证码成功",
                iconClass: "icon-success_black"
            });
        },
        async login() {

//          if (!regExp.mobile.reg.test(this.mobile)) {
//              this.$toast(regExp.mobile.errMsg);
//              return false;
//          }
            if (!this.code) {
                this.$toast("请输入验证码");
                return false;
            }

            let isSuccess = await this.userLoginByMobile({ phone: this.mobile, code: this.code, agentNo: channel.get() })
            if (isSuccess) {
              if (this.redirectUrl) {
                // this.$router.replace(this.redirectUrl);

                this.$router.go(-1);
                removeStorage("redirectUrl");
              } else {
                this.$router.replace("/user");
              }
            }
        }
    }

}
</script>

<style lang="less" scoped>
  .btn {
    width: 95%;
    margin: 30px auto;
    background: #ffdf00;
    color: #000;
  }
  .header /deep/ .timer-btn{
    font: 14px arial, sans-serif;
  }
</style>
