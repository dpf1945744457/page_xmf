<template>
    <div class="login-top">
        <Xheader class="header" :left-options="{showBack:isBack}">
            {{$route.meta.title}}
            <!--<icon slot="overwrite-left" class="icon" name="home-login" scale="2" @click.native="$router.push('/')"></icon>-->
        </Xheader>
        <div class="login-img m-b-10">
            <img src="../../../assets/img/user/xiaomifeng@3x.png">
        </div>
    </div>
</template>

<script>
import Xheader from "@src/components/base/x-header"
export default {
    components: { Xheader },
    props:{
    	isBack:Boolean,
    }
}
</script>

<style lang="less" scoped>
.login-top {
  //   background: url(../../assets/img/user/m_login_bgimg_0.png) no-repeat;
  //   background-size: cover;
  //background: #e6413d;
  background: #ffdf00;

  .header {
    background: rgba(0, 0, 0, 0);
  }
}
.login-img {
  line-height: 100px;
  text-align: center;
  background: #fff;

  img {
    height: 60px;
  }
}
</style>
