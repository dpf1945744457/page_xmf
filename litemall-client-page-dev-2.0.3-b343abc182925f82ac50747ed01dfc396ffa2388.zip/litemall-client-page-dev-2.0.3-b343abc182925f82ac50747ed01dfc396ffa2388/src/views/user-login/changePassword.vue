<template>
	<div class="header">
		<!-- header头部 -->
		<LoginHeader :isBack='true'></LoginHeader>
		<LoginInput label="旧密码" type="password" v-model="oldPassword" placeholder="请输入旧密码"  :topLine="true" maxLength="6"></LoginInput>
		<LoginInput label="新密码" type="password" v-model="passwords" placeholder="请输入新密码"  :topLine="true" maxLength="6"></LoginInput>
		<LoginInput label="确认密码" type="password" v-model="againPassword" placeholder="请再次输入新密码" :topLine="true" maxLength="6"></LoginInput>
		<Xbutton class="btn" type="dd" @click.native="register">确认修改</Xbutton>
	</div>
	
	
</template>

<script>
	import LoginHeader from "./module/login-header.vue"
	import LoginInput from "./module/login-input.vue"
	import Xbutton from "@src/components/base/x-button"
	import { isWeixin } from '@src/utils/wx.js'
	import { setStorage, getStorage, removeStorage } from "@src/utils/storage.js"
	import { modifyPassword } from '@src/apis/user.js'
	import md5 from 'js-md5';
	import store from '@src/vuex'
	import { getToken, setToken, removeToken } from '@src/utils/auth.js'
	import regExp from '@src/utils/regExp.js'
	
	
	
	
	export default {
		components: {
			LoginHeader,
			Xbutton,
			LoginInput
		},
		
		data() {
			return {
				redirectUrl: this.$route.query['redirect'] || getStorage("redirectUrl"),
				passwords: '',
				againPassword: '',
				oldPassword: '',
				mobile: "",
			}
		},
		mounted() {
			// 如果没有储存标识 和 有重定向url的话 设置isBack为真就行
			if(this.redirectUrl) setStorage("redirectUrl", this.redirectUrl);
		},
		beforeRouteEnter(to, from, next) {
			if(isWeixin() && !getToken() && process.env.NODE_ENV === 'production') {

				let redirectUrl0 = encodeURIComponent(`${window.location.href.split("#")[0]}#/bind`);
				// let redirectUrl1 = encodeURIComponent(`${window.location.href.split("#")[0]}#${from.fullPath}`);
				let redirectUrl2 = encodeURIComponent(`${location.origin}/wx/oauth/loginWxWeb?redirectURL=${redirectUrl0}`);
				let redirectUrl3 = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxa56f673775b525bb&redirect_uri=${redirectUrl2}&response_type=code&scope=snsapi_userinfo&state=10001#wechat_redirect`;
//				let redirectUrl3 = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxa418d63f5b2ab75c&redirect_uri=${redirectUrl2}&response_type=code&scope=snsapi_userinfo&state=10001#wechat_redirect`;
				
				window.location.replace(redirectUrl3);

			} else {
				next();
			}
		},
		methods: {
			register() {
				if(!this.oldPassword) {
					this.$toast("请输入旧密码");
					return false;
				}
				if(!this.passwords) {
					this.$toast("请输入新密码");
					return false;
				}
				if(!regExp.num.reg.test(this.passwords)) {
					this.$toast("密码只能为数字");
					return false;
				}
				if(this.passwords.length < 6) {
					this.$toast("密码为6位数字");
					return false;
				}
				if(this.passwords.length > 6) {
					this.$toast("密码为6位数字");
					return false;
				}
				if(this.againPassword != this.passwords) {
					this.$toast("请确认密码一致");
					return false;
				}
				modifyPassword({
					oldPassword: this.oldPassword,
					newPassword: this.passwords
				}).then((res)=>{
					if(res.errno === 0){
						this.$toast(res.errmsg);
						setTimeout(()=>{
							this.$router.replace("/phoneLogin");
						}, 2000);
					}else{
						this.$toast(res.errmsg);
					}
				})
			},
		}
		
		
	}
	
</script>

<style lang="less" scoped>
	.btn {
		width: 95%;
		margin: 30px auto 20px ;
		background: #ffdf00;
		color: #000;
	}
	
	.form-right{
		float: right !important;
	}
	
	.img_btn {
		width: 3rem;
	}
	
	.switch{
		text-align: right;
	}
	
	.footer{
		padding: 0 1rem;
		display: flex;
		a{
			flex: 1;
		}
	}
	
	.header /deep/ .timer-btn {
		font: 14px arial, sans-serif;
	}
</style>