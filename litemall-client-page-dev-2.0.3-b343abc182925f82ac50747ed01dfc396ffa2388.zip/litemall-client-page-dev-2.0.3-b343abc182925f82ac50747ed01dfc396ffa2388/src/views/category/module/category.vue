<template>
    <div class="category-box">
        <div class="category-left">
            <ul>
                <!-- ;$emit('change', false, 0) -->
                <li class="com-bottom-1px"  @click="pageClickSel(0, false)">
                    <span :class="{ cur: currentCategorySel == 0? true: false }">为你推荐</span>
                </li>
                
                <li class="com-bottom-1px"  @click="pageClickSel(index+1, item)" v-for="(item, index) in categoryList" :key="index+1">
                    <span :class="{ cur: currentCategorySel == index+1? true: false }">{{ item.name }}</span>
                </li>
            </ul>
        </div>

        <div class="category-right">
            <div class="category-right-content">
                <!-- <img style="height:90px;width: 100%;display: block;" v-if="currentCategory.picUrl" :src="currentCategory.picUrl" alt="" /> -->
                <!-- 类目总类 -->
                <!-- <Ucell class="com-bottom-1px" v-if="currentCategory.name" :title="currentCategory.name" :borderLine="false" :isLink="false"> -->
                    <!-- <span slot="desc">进入</span> -->
                <!-- </Ucell> -->
                <div class="category-two" v-if="currentCategorySel==0" style="padding-top: 20px;">
                    <Ucell class="category-name" :title="`常用分类`" :borderLine="false" :isLink="false"></Ucell>
                    <grid class="category-items" :no-border="true" :cols="2">
                        <grid-item
                            :label="item.name"
                            v-for="(item, index) in currentSubCategoryss"
                            :key="index"
                            @click.native="$router.push({ path: '/product', query: { classifyId: item.id } })"
                        >
                            <img slot="icon" v-lazy="item.icon" alt="" />
                        </grid-item>
                    </grid>
                    
                </div>
                <div class="category-two" v-if="currentCategorySel==0" style="border-top:1px solid #f9f9f9;margin-top: 20px;padding-top: 20px;">
                    <Ucell class="category-name" :title="`热门分类`" :borderLine="false" :isLink="false"></Ucell>
                    <grid class="category-items" :no-border="true" :cols="2">
                        <grid-item
                            :label="item.name"
                            v-for="(item, index) in currentCategory"
                            :key="index"
                            @click.native="$router.push({ path: '/product', query: { classifyId: item.id } })"
                        >
                            <img slot="icon" v-lazy="item.icon" alt="" />
                        </grid-item>
                    </grid>
                </div>


                



                <div class="category-two" v-if="currentCategorySel!=0">
                    <!-- <Ucell class="category-name" :title="`女鞋`" :borderLine="false" :isLink="false"></Ucell> -->
                    <grid class="category-items" :no-border="true" :cols="2">
                        <grid-item
                            :label="item.name"
                            v-for="(item, index) in currentSubCategory"
                            :key="index"
                            @click.native="$router.push({ path: '/product/'+item.id })"
                        >
                            <img slot="icon" v-lazy="item.picUrl" alt="" />
                        </grid-item>
                    </grid>
                </div>
            </div>
            <!-- <div v-if="currCategoryLeftIndex > one.length">加载中...</div> -->
        </div>
    </div>
</template>

<script>
import { Grid, GridItem } from '@src/components/base/grid';
import Ucell from '@src/components/base/u-cell';
import { getCategoryData, getCurrentCategoryData } from '@src/apis/product.js';
export default {
    components: { Grid, GridItem, Ucell },
    props: ['categoryId', 'categoryList', 'currentCategory', 'currentSubCategory', 'currentSubCategoryss'],
    data() {
        return {
            currentCategorySel: 0, // 左侧点击
            //坐标数组  
            oLioffsetTopArray: []
        };
    },
    
    mounted() {
        this.initoLiOffsetTopArray();
    },

    methods: {
        // 遍历所有左侧菜单位置信息
        initoLiOffsetTopArray() {
            let categoryBox = document.querySelector('.category-box');
            let oLis = document.querySelectorAll('.category-left li');
            for (let i = 0; i < oLis.length; i++) {
                let oLi = oLis[i];
                let offsetTop = oLi.offsetTop - categoryBox.offsetTop;
                this.oLioffsetTopArray.push(offsetTop);
            }
        },
        upDataScoll() {
            //改变左侧滚动条位置
            this.$nextTick(() => {
                let categoryLeft = document.querySelector('.category-left');
                var next = parseInt(index - 3) <= 0 ? 0 : this.oLioffsetTopArray[parseInt(index - 3)];
                categoryLeft.scrollTop = next;
            });

            //右侧内容区域滚动条置0
            this.$nextTick(() => {
                let categoryRight = document.querySelector('.category-right');
                categoryRight.scrollTop = 0;
            });
        },
        pageClickSel(num, item){
            this.currentCategorySel = num
            this.$emit('change', item, num)
        },
    }
};
</script>

<style lang="less" scoped>
.category-box {
    display: flex;
    overflow: hidden;
    font-size: 14px;
    /deep/ .weui-grid__icon{
        width: 80px!important;
        height: 80px!important;
    }
    /deep/ .x-cell .title{
        font-size: 15px;
        color: #666;
    }
    /deep/ .com-bottom-1px::after{
        height: 0;
            border-bottom: 0px solid #e3e5e9;
    }
    .category-left,
    .category-right {
        overflow-x: hidden;
        overflow-y: auto;
        
        -webkit-overflow-scrolling: touch;
    }

    .category-left {
        width: 30%;
        ul {
            width: 100%;
            overflow: hidden;
            li {
                width: 100%;
                height: 60px;
                line-height: 60px;
                background-color: #fff;
                font-size: 13px;
                text-align: center;
                color: #232326;
            }

            .cur {
                // background: #f2f2f2;
                color: #FFF;
                position: relative;
                /* padding: 4px 12px; */
                border-radius: 25px;
                background: #FF4A10;
                display: inline-block;
                width: 80%;
                height: 25px;
                line-height: 25px;
            }
        }
    }

    .category-right {
        width: 70%;
        padding-bottom: 20px;
        padding-right: 3%;
        border-left: 6px solid #f9f9f9;
        .category-right-content {
            padding-left: 5px;
            box-sizing: border-box;
            // display: none;
        }

        .category-name {
            padding: 5px 3%;
            // background: transparent !important;
            .title {
                font-size: 12px !important;
            }
        }

        .category-items {
            background: #fff;
                display: flex;
    flex-wrap: wrap;
    justify-content: flex-start;
        }
    }
}
</style>
