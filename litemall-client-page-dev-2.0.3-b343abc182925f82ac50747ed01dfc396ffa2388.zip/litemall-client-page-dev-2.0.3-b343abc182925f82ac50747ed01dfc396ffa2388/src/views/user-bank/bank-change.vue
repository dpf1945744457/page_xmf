<template>
	<div class="bank_change">
        <Xheader class="header" :left-options="{ showBack: isBack }">{{ $route.meta.title }}</Xheader>
		<div class="content">
            <div class="input"><Uinput label="姓名" width="100" type="text" v-model="name" placeholder="请输入姓名" maxLength="19"></Uinput></div>
            <div class="input" v-if="isCard"><Uinput label="卡号" width="100" type="tel" v-model="card" placeholder="请输入银行卡号" maxLength="19"></Uinput></div>
			<van-cell-group>
				<van-field class='pass' center clearable v-model="code" type="tel" placeholder="请输入验证码" maxlength='6'>
					<van-button slot="button" size="small" type="primary" @click='getPhoneCode' class='codes' :loading='load' :disabled='disab' >{{count}}</van-button>
				</van-field>
			</van-cell-group>
			<van-button class='btn' type="primary" size="large" @click='toPassWord' >下一步</van-button>
		</div>
	</div>
</template>

<script>
    import Xheader from '@src/components/base/x-header';
    import Uinput from '@src/components/base/u-input';
    import { Cell, CellGroup,Field,Button  } from 'vant';
    import { postBankList,sendForgetPwdSms,checkForgetPwdSms } from '@src/apis/bank.js';
	export default {

		name: 'bank_code',
        components:{Cell,CellGroup,Field,Button,Xheader,Uinput},
		data() {
			return {
                name: '',
                card: '',
                isBack: Boolean,
				code: '',
				load: false,
				disab: false,
                count: '获取验证码',

                isUser: '',
                list: [],
			}
		},
		computed:{
			phone(){
				return this.$route.query.mobile
			},
            isCard(){
                if(!this.isUser && !this.list.length){
                    return false
                }
                return true
            }
		},

		mounted() {
            this.getData();
		},
		methods: {
            async getData() {
                let res = await postBankList();
                this.list = res.Token
                this.isUser = res.isUser
            },
			async getPhoneCode(){
                if(!this.check()) return
                let res = await sendForgetPwdSms({
                    idtCardName: this.name,
                    cardNum: this.card,
                });
                if(res.errno){
                    this.$toast(res.errmsg)
                }else{
                    this.sendcode()
                }
			},
            check(){
                if(this.name == ''){
                    this.$toast('请输入姓名')
                    return false
                }
                if(this.isCard && this.card == ''){
                    this.$toast('请输入银行卡号')
                    return false
                }
                return true
            },
			sendcode(){
				this.disab = true
				this.load = false
				let count = 60
				this.count = '60s'
				let self = this
				this.timer = setInterval(() => {
					this.load = false
					if(count > 0 && count <= 60) {
						count--;
						self.count = count + 's'
					} else {
						self.load = false
						self.disab = false
						clearInterval(self.timer);
						self.timer = null;
						self.count = '获取验证码'
					}
				}, 1000)
			},
			async toPassWord(){
                if(!this.check()) return
                if(this.code == ''){
                    this.$toast('请输入验证码')
                    return
                }
                let res = await checkForgetPwdSms({
                    idtCardName: this.name,
                    cardNum: this.card,
                    smsCode: this.code,
                });
                
                if(res.errno){
                    this.$toast(res.errmsg)
                }else{
                    this.$router.push({ path:'/bankForget', query: {reToken:res.reToken} });
                }
			}
		},
		watch:{
		}
	}
</script>

<style scoped lang="less">
	.bank_change {
        height: 100%;
        background: #fff;
		header,p{
			height: 20px;
			font-size: 16px;
			color: #333333;
			text-align: center;
			line-height: 20px;
		}
        .input {
            width: 95%;
            margin: 0 auto;
            line-height: 56px;
            border-bottom: 1px solid #e6e6e6;
            /deep/ .form-group dl dt {
                height: unset;
                line-height: unset;
            }
            /deep/ .form-group dl dd {
                height: unset;
                line-height: unset;
            }
        }
        p{
            margin-top: 10px;
        }
        header{
        	margin-top: 30px;
            color: #999;
        }
		.pass {
			border-bottom: 1px solid #E6E6E6;
			width: 100% !important;
		}
		.codes {
			background: #fff;
			border: none;
			color: #d2423a;
		}
		.content{
			margin-top: 50px;
			padding: 0 15px;
		}
		.btn {
			background-color: #ffdf00;
			border: none;
			height: 40px;
			line-height: 40px;
			width: 90%;
			margin-left: 5%;
			margin-top: 40px;
            color: #000;
		}
		/deep/ .van-button--disabled{
			opacity: 0.7;
			font-size: 14px;
		}
	}
</style>
