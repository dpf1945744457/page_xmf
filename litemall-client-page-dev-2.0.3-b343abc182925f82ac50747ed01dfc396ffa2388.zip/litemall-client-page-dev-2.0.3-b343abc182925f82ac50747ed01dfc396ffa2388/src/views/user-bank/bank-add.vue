<template>
    <div class="bank_add">
        <Xheader class="header" :left-options="{ showBack: isBack }">{{ $route.meta.title }}</Xheader>
        <div class='input'><Uinput label="卡号" type="tel" v-model="mobile" placeholder="请输入银行卡号" maxLength="19"></Uinput></div>
        <Xbutton :class="{change: !isFalse}" class='btn' :disabled='!isFalse'  type="dd" @click.native="nextStep">下一步</Xbutton>
    </div>
</template>

<script>
import Xheader from '@src/components/base/x-header';
import Uinput from '@src/components/base/u-input';
import Xbutton from '@src/components/base/x-button';
import { postCheckCard } from '@src/apis/bank.js';
import regExp from '@src/utils/regExp.js'
export default {
    components: { Xheader, Uinput, Xbutton },
    data() {
        return {
            isBack: Boolean,
            mobile:'',
            isFalse: false,
        };
    },
    mounted(){
    },
    methods: {
        async nextStep(){
            let res = await postCheckCard({cardNum:this.mobile});
            if(!res.errno){
                this.$router.push({path:'/bankInfo',query:{card:this.mobile,type:res.cardType}})
            }else{
                this.$toast(res.errmsg)
            }
        },
    },
    watch:{
        mobile(){
            this.mobile = this.mobile.replace(/\s/g,'').replace(/\D/g,'').replace(/(\d{4})(?=\d)/g,"$1 ");
            
            if(this.mobile.length < 9){
                this.isFalse = false
            }else{
                this.isFalse = true
            }
        }
    }
};
</script>

<style lang="less" scoped>
.bank_add {
    background: #fff;
    height: 100%;
    .btn {
        width: 95%;
        margin: 30px auto;
        background: #ffdf00;
        color: #000;
    }
    .input{
        width: 90%;
        margin: 0 auto;
        margin-top: 30px;
        border-bottom: 1px solid #E6E6E6;
    }
    .change{
        opacity: 0.5;
    }
    .header{
        // background: #ffdf00;
    }
}
</style>
