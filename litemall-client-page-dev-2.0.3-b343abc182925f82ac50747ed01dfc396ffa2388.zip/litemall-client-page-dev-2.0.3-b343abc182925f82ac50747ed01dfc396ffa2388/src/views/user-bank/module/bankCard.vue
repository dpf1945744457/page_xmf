<template>
    <div class="bank_card">
        <!-- <van-swipe-cell   -->
            <div class="card_list" v-for="(item, index) in dataArr" :key="index" @click.stop.prevent="getCardDetails(index,item.cardBgImage,item.cardType,item.cardId)">
                <div class="img_box"><img :src="item.cardBgImage" alt="" /></div>
                <!--<div class="card_name">
                    <p>{{ item.cardType }}</p>
                    <p>{{ item.bankName }}</p>
                </div>-->
                <!--<div class="card_num">{{ item.cardId }}</div>
                <div class="show_num" @click="watchCard(index, item.isKeep)"><icon class="tool-icon" slot="icon" name="eyes" scale="3"></icon></div>-->
            
            	<p class="cardType">{{ item.cardType }}</p>
				<div class="cardInfo">
					<div class="card_num">{{ item.cardId }}</div>
                	<div class="icon" @click.stop.prevent="watchCard(index, item.isKeep)" :class="item.isKeep ? 'open' : 'close'"></div>
            
				</div>
            </div>
            <!-- <template slot="right">
                <van-button square type="danger" text="解绑" />
            </template> -->
        <!-- </van-swipe-cell> -->
    </div>
</template>

<script>
import { postBankList } from '@src/apis/bank.js';
import { SwipeCell } from 'vant';

export default {
    components: {
        SwipeCell
    },
    data() {
        return {
            dataArr: [],
            keepArr: [],
            isKeep: false,
            isUser: ''
        };
    },
    mounted() {
        this.getData();
    },
    methods: {
        async getData() {
            let res = await postBankList();
            this.list = res.Token;
            this.isUser = res.isUser;
            this.$store.commit('SET_BANK', this.isUser);
            let arr = this.handleNum(this.list);
            this.keepArr = JSON.parse(JSON.stringify(arr));
            this.dataArr = this.handleDataNum(arr);
        },
        handleNum(arr) {
            arr.map(item => {
                item.cardId = item.cardId
                    .replace(/\s/g, '')
                    .replace(/\D/g, '')
                    .replace(/(\d{4})(?=\d)/g, '$1 ');
                item.cardMsg = 'https://crossborder.sinopayonline.com/CrossBorderPay/bank/' + item.cardMsg   
                item.isKeep = false;
            });
            return arr;
        },
        handleDataNum(arr) {
            arr.map(item => {
                item.cardId = '**** **** **** ' + item.cardId.substring(item.cardId.length - 4);
            });
            return arr;
        },
        toPath() {
            if (!this.isUser) {
                this.$router.push('/bankModifyCode');
            } else {
                this.$router.push('/addCard');
            }
        },
        /**
         * @param {number}i  当前下标
         * @param {boolean}check 是否显示*号
         */
        watchCard(i, check) {
            let item = this.dataArr[i];
            if (!check) {
                item.cardId = this.keepArr[i].cardId;
                item.isKeep = true;
            } else {
                item.cardId = '**** **** **** ' + item.cardId.substring(item.cardId.length - 4);
                item.isKeep = false;
            }
        },
        getCardDetails(i,cardImage,cardType,cardNum){
        	let cardInfo = {
        		cardImage:cardImage,
        		cardType:cardType,
        		cardNum:this.keepArr[i].cardId
        	}
        	localStorage.setItem("cardInfo",JSON.stringify(cardInfo))
        	this.$router.push('/unbindCard');
        }
    }
};
</script>

<style lang="less" scoped>
.bank_card {
    .card_list {
        /*padding: 0 15px;
        height: 50px;
        display: flex;
        margin-top: 20px;
        background: #fff;*/
       	position: relative;
        margin: 20px 16px 0 16px;
	    height: 112px;
	    background-image: linear-gradient(135deg, #F8456A 0%, #F88466 100%);
	    border-radius: 6px;
        .img_box {
        	position: absolute;
        	top: 0;
        	left: 0;
            /*flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;*/
            img {
                width: 100%;
            }
        }
        /*.card_name {
            margin-top: 6px;
            flex: 3;
            padding-left: 10px;
        }
        .card_num {
            line-height: 50px;
            text-align: right;
            padding-right: 10px;
            flex: 5;
        }
        .show_num {
            display: flex;
            justify-content: center;
            align-items: center;
            flex: 1;
        }*/
       .cardType{
			padding: 32px 0 22px 48px;
			box-sizing: border-box;
			opacity: 0.8;
			font-family: PingFangSC-Regular;
			font-size: 12px;
			color: #FFFFFF;
		}
		.cardInfo{
			display: flex;
			margin: 0 24px 0 48px;
			.card_num{
				z-index: 1;
				flex: 3;
				font-family: PingFang-SC-Medium;
				font-size: 18px;
				color: #FFFFFF;
			}
			.icon{
				z-index: 1;
				flex: 1;
			}
			.icon.close{
				background: url(../../../assets/img/user/eye_close.png) no-repeat right center;
				background-size: 19px 8px;
			}
			.icon.open{
				background: url(../../../assets/img/user/eye_open.png) no-repeat right center;
				background-size: 24px 15px;
			}
		}
        
    }
}
</style>
