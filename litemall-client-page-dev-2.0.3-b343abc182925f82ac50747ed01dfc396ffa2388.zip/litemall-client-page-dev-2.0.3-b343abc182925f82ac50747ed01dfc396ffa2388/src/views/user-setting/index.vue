<template>
    <div class="user-setting">
        <Xheader :title="$route.meta.title">
            <span slot="right" style="padding:5px 10px;" @click="save">保存</span>
        </Xheader>

        <Ucell title="头像" :isLink="true" :borderLine="true">
            <div slot="desc" class="avatar-img m-r-10">
                <img ref="resultObj" :src="info.avatarUrl || info.headImg || require('@src/assets/img/user/default_user_header.png')" alt="">
                <!-- <input type="file" ref="inputFile" accept="image/png,image/jpg,image/jpeg" @change="onChange($event)"> -->
                <input type="file" ref="inputFile" accept="*" @change="onChange($event)">
            </div>
        </Ucell>

        <Ucell title="昵称" :isLink="true" :borderLine="true" @click.native="$refs.nickName.focus()">
            <input slot="desc" ref="nickName" class="nick-name-ipt" type="text" autofocus="autofocus" maxlength="11" placeholder="请输入昵称" v-model="info.nickName">
        </Ucell>

        <Ucell title="性别" :isLink="true" :borderLine="true" @click.native="showActionsheet = true">
            <span slot="desc" class="nick-name-ipt">{{menus[info.gender] || "未设置"}}</span>
        </Ucell>

        <Ucell title="生日" :isLink="true" :borderLine="true" @click.native="$refs.DateTime.show()">
            <span slot="desc" class="nick-name-ipt">{{info.birthDay || "未设置"}}</span>
        </Ucell>
        
		<Ucell title="修改密码" :isLink="true" @click.native="toChange">
            <span slot="desc" class="nick-name-ipt"></span>
        </Ucell>
        
        
        
        <DateTime ref="DateTime" type="date" :showTodayButton="false" :value="info.birthDay" color='#f6662e' @confirm="dateTimeSelect">
            <i slot="prevMonth" class="date-arraw">-</i>
            <i slot="nextMonth" class="date-arraw">+</i>
        </DateTime>

        <Actionsheet theme="android" v-model="showActionsheet" :menus="menus" @on-click-menu="clickMenu">
            <p slot="header">性别选择</p>
        </Actionsheet>
    </div>
</template>

<script>
import HeaderLayout from "@src/layouts/headerLayout.vue"
import Xheader from "@src/components/base/x-header"
import Ucell from '@src/components/base/u-cell'
import Actionsheet from '@src/components/base/actionsheet'
import regExp from '@src/utils/regExp.js'
import format from '@src/utils/format.js'
import { mapState, mapActions, mapGetters } from "vuex";
import DateTime from 'vue-date-time-m';
import imgClipper from '@src/plugins/img-clipper/index.js'
import '@src/plugins/img-clipper/index.css'
import Vue from 'vue'
Vue.use(imgClipper);
export default {
    components: { HeaderLayout, Xheader, Ucell, Actionsheet, DateTime },
    computed: {
        ...mapState({
            userInfo: state => state.user.userInfo
        }),
    },
    data() {
        return {
            info: {},
            showActionsheet: false,
            menus: { "1": '男', "2": '女' },
            showDate: false,
        }
    },
    mounted() {
        this.info = { ...this.userInfo }
    },
    methods: {
        ...mapActions(["userInfoUpdata"]),
        onChange(event) {
            this.initClip(event, {
                // resultObj: this.$refs.resultObj,
                aspectRatio: 1,
                callback: (url) => {
                    this.info.headImg = url;
                }
            })
        },
        clickMenu(menuKey, menuValue) {
            this.info.gender = menuKey;
        },
        dateTimeSelect(val) {
        	
            this.info.birthDay = format(new Date(val), "YYYY-MM-DD");
        },
        async save() {
            if (!this.info.nickName) {
                this.$toast("请输入昵称");
                return;
            }
//          if (!regExp.normal.reg.test(this.info.nickName)) {
//              this.$toast("昵称不得出现特殊字符");
//              return;
//          }
            await this.userInfoUpdata(this.info);
            this.$router.back();
        },
        toChange(){
        	this.$router.push('/user/changePassword')
        }
    }

}
</script>

<style lang="less" scoped>
.user-setting {
    font-size: 14px;
  .avatar-img {
    // position: relative;
    margin-left: 15px;
    height: 58px;
    width: 58px;
    box-sizing: border-box;
    border-radius: 100%;
    overflow: hidden;
    border: 2px solid rgba(255, 255, 255, 0.4);
  }
  .avatar-img img,
  .avatar-img input {
    display: block;
    height: 54px;
    width: 54px;
  }
  .avatar-img input {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    opacity: 0;
    z-index: 9;
  }
  .nick-name-ipt {
    font-size: 14px;
    text-align: right;
    color: #757575;
    padding: 5px 10px;
    box-sizing: border-box;
  }
  .date-arraw {
    padding: 10px;
    font-size: 26px;
    box-sizing: border-box;
  }
}
</style>
