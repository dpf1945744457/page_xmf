<template>
        <div class="product-list clearfix">
            <GoodsItem class="goods-item" v-for="(item, index) in list" :key="index" :item="item">
                <icon slot="actionIcon" name="cart" scale="3" @click.native="$emit('clickCartBtn', item)"></icon>
            </GoodsItem>
        </div>
</template>
<script>
import GoodsItem from '@src/components/base/goodsItem/index.vue';
import axios from 'axios';
import base from '@src/apis/base.js';
export default {
    components: { GoodsItem },
    props: ['list'],
    data() {
        return {
            counter: 2, //默认已经显示出10条数据 count等于一是让从11条开始加载
            categoryId: ''
        };
    },

    methods: {
        getList() {
            axios.get(base.oaIp + '/wx/goods/list?categoryId=' + this.categoryId + '&page=1&size=10').then(response => {
                this.list.length = 0;
                for (let i = 0; i < response.goodsList.length; i++) {
                    this.list.push(response.goodsList[i]);
                }
            });
        },
    }
};
</script>
<style lang="less" scoped>
.product-list {
}
</style>
