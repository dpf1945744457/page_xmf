<!--  -->
<template>
    <HeaderLayout>
        <Xheader class="header-fix" :title="$route.meta.title"></Xheader>

        <Nodata :havebut="false" v-if="noDataVisible" :imgurl="require('@src/assets/img/icon/no_address.png')" content='还没有添加收货地址'></Nodata>

        <div v-if="defaultVisible" class="address-page">
            <addressList v-if="defaultVisible" @selectAddress="selectAddress" @editAddress="editAddress " :list=list></addressList>
        </div>

        <div class="footerbut-box top-20">
            <button class="red " @click="addAddress">新 建</button>
        </div>
    </HeaderLayout>
</template>

<script>
import HeaderLayout from "@src/layouts/headerLayout.vue"
import Xheader from "@src/components/base/x-header"
import Nodata from "@src/components/base/no-data"
import addressList from './module/list.vue'
import { getAddressList, getAddressData } from '@src/apis/address.js'
import { cityCode } from '@src/utils/cityCode.js'
export default {
    layout: "tabbar",
    components: { HeaderLayout, Xheader, Nodata, addressList },
    data() {
        return {
            cityData: [],
            noDataVisible: false,
            defaultVisible: false,
            list: [{
                phoneNum: "17600802340",
                userName: "张三",
                province: "北京市",
                city: "市辖区",
                area: "通州区",
                address: "北京市市辖区通州区 玉兰湾10号楼一单元2502"
            }
            ]
        }
    },
    async created() {
        this.cityData = await getAddressData()
        this.getAddressListHandle();
    },

    methods: {
        getAddressListHandle() {
            getAddressList().then(data => {
                if (data) {
                    let cityData = this.cityData;
                    for (var i = 0; i < data.length; i++) {
                        data[i].province = cityCode(cityData, data[i].provinceId);
                        data[i].area = cityCode(cityData, data[i].areaId);
                        data[i].city = cityCode(cityData, data[i].cityId);
                    }
                    this.$set(this.$data, 'list', data)
                    if (data && data.length > 0) {
                        this.defaultVisible = true;
                        this.noDataVisible = false;
                    } else {
                        this.defaultVisible = false;
                        this.noDataVisible = true;
                    }
                } else {
                    this.defaultVisible = false;
                    this.noDataVisible = true;
                    this.$toast(res.errmsg);
                }
            })
        },

        editAddress(id) {
            this.toUrl('EDIT', id)
        },
        addAddress() {
            this.toUrl('ADD')
        },
        toUrl(type, id) {
            let route = this.$route;
            if (type == 'ADD') {
                this.$router.push({
                    path: '/address/input',
                    query: {
                        type: type,
                    }
                })
            } else {
                this.$router.push(
                    {
                        path: '/address/input',
                        query: {
                            type: type,
                            id: id
                        }
                    })
            }
        },
        // 选择地址
        selectAddress(id) {
            if (this.$route.query.canSelect == 'TRUE') {
                this.$router.push({
                    path: this.$route.query.backPath,
                    query: { ...this.$route.query, addressId: id }
                })
            } else {
                this.toUrl('EDIT', id)
            }

        }
    }
}
</script>
<style lang='less' scoped>
</style>
