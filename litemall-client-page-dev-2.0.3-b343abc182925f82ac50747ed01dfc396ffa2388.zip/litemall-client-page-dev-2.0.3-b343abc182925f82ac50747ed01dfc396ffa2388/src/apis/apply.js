import base from '@src/apis/base.js'
import http from '@src/apis/http.js'

// 申请入驻
export const apply = (params) => { return http.post(base.oaIp, "/admin/merchant/apply", params, false) }
