import base from '@src/apis/base.js'
import http from '@src/apis/http.js'

// 获取待评价订单
export const danglod = (params) => {
    return http.post(base.oaIp, "/wx/apps/upgrade", params)
}

// 订单评价
