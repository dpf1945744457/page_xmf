import base from '@src/apis/base.js'
import http from '@src/apis/http.js'
// 用户登录
export const userLogin = (params) => { return http.post(base.oaIp, "/wx/auth/login", params, true) }
// 使用手机号登录
//export const userLoginByMobile = (params) => { return http.post(base.oaIp, "/wx/auth/loginByPhone", params, true) }
export const userLoginByMobile = (params) => { return http.post(base.oaIp, "/wx/auth/login", params, true) }
// 用户注册
export const userRegister = (params) => { return http.post(base.oaIp, "/wx/auth/register", params, true) }
// 使用手机号注册
//export const userRegisterByMobile = (params) => { return http.post(base.oaIp, "/wx/auth/register", params, true) }
export const userRegisterByMobile = (params) => { return http.post(base.oaIp, "/wx/auth/register", params, true) }
// 修改密码
export const modifyPassword = (params) => { return http.post(base.oaIp, "/wx/auth/modifyPassword", params, true) }
// 忘记密码 修改
export const forgetPassword = (params) => { return http.post(base.oaIp, "/wx/auth/forgetPassword", params, true) }


















// 用户找回密码
export const userReset = (params) => { return http.post(base.oaIp, "/wx/auth/reset", params, true, true) }

// 获取验证码
export const getRegCode = (params) => { return http.post(base.oaIp, "/wx/auth/regCaptcha", params, true, true) }

// 用户退出
export const userExit = (params) => { return http.post(base.oaIp, "/wx/auth/drop_out", params, true) }

// 获取手机号登录验证码
export const getLoginCode = (params) => { return http.post(base.oaIp, "/wx/auth/regCaptcha", params, true) }
// 手机验证码校验
export const authPhoneCode = (params) => { return http.post(base.oaIp, "/wx/auth/authPhoneCode", params, true) }

// 获取忘记密码验证码
export const getForgetCode = (params) => { return http.post(base.oaIp, "/wx/auth/fpCaptcha", params, true) }

//忘记密码手机验证码校验
export const forgetCode = (params) => { return http.post(base.oaIp, "/wx/auth/fpCheckCode", params, true) }

// 获取绑定手机号验证码
export const getBindMobileCode = (params) => { return http.post(base.oaIp, "/wx/auth/bindPhoneCaptcha", params, true) }

// 绑定手机号
export const bindMobile = (params) => { return http.post(base.oaIp, "/wx/auth/wxBindPhone", params, true) }


// 我的收藏 参数：type:0是商品，1是专题
export const getUserCollectList = (params) => { return http.get(base.oaIp, "/wx/collect/list", params) }

// 我的足迹
export const getUserBrowseHistory = (params) => { return http.get(base.oaIp, "/wx/footprint/list", params, true) }

// 足迹删除全部
export const userBrowseClearAll = (params) => { return http.post(base.oaIp, "/wx/footprint/clear", params, true) }

// 足迹删除
export const userBrowseDelete = (params) => { return http.post(base.oaIp, "/wx/footprint/delete", params, true) }

// 个人中心信息
export const getUserCenterData = (params) => { return http.get(base.oaIp, "/wx/home/personal", params, true) }

// 获取用户信息
export const getmallUserInfo = (params) => { return http.get(base.oaIp, "/wx/oauth/mallUserInfo", params, true) }

// 修改用户信息
export const userInfoUpdata = (params) => { return http.post(base.oaIp, "/wx/oauth/modifyUserInfo", params, true) }

//微信登录需要绑定手机号
export const wxBindingPhCheck = (params) => { return http.post(base.oaIp, "/wx/auth/checkBindPhone", params, true) }

//是否绑定手机接口
export const weixinBindPhone = (params) => { return http.post(base.oaIp, "/wx/auth/weixinBindPhoneBefore", params, true) }

//微信登录
export const weixinLogin = (params) => { return http.post(base.oaIp, "/wx/auth/weixinBindPhoneSetup", params, true) }

export const weixinLoginByFlush = (params) => { return http.post(base.oaIp, "/wx/auth/weixinBindPhoneFlush", params, true) }

export const weixinLoginByRouter = (params) => { return http.post(base.oaIp, "/wx/auth/weixinBindPhoneRoute", params, true) }


//获取图片验证码 GET
export const getCode = (params) => { return http.get(base.oaIp, "/wx/auth/getCode", params, false) }

//获取区号
export const getPhoneAreaCode = (params) => { return http.post(base.oaIp, "/wx/auth/phoneAreaCode", params, true) }
