<template>
    <div id="main">
        <!-- <Loading :showLoading="showLoading"></!--> 
        <keep-alive><router-view v-if="$route.meta.keepAlive"></router-view></keep-alive>
        <router-view v-if="!$route.meta.keepAlive"></router-view>
    </div>
</template>

<script>
// import Loading from "@src/components/base/loading"
import { mapState, mapActions, mapGetters } from 'vuex';
export default {
    name: 'App',
    // components: { Loading },
    // computed: { ...mapGetters(["showLoading"]) },
    mounted() {
        const script = document.createElement('script');
        script.src = 'https://s22.cnzz.com/z_stat.php?id=1274614625&web_id=1274614625';
        script.language = 'JavaScript';
        document.body.appendChild(script);

        this.getCartGoodscount();
         var _hmt = _hmt || [];
    (function () {
      var hm = document.createElement("script");
      hm.src = "https://hm.baidu.com/hm.js?268c96e24e2579561d39668d94fd3491";
      var s = document.getElementsByTagName("script")[0];
      s.parentNode.insertBefore(hm, s);
    })();

        // window.addEventListener('popstate', function () {
        //     alert(window.location.href);
        // });
    },
    watch: {
        $route() {
            if (window._czc) {
                let location = window.location;
                let contentUrl = location.pathname + location.hash;
                let refererUrl = '/';
                window._czc.push(['_trackPageview', contentUrl, refererUrl]);
            }
        }
    },
    methods: {
        ...mapActions(['getCartGoodscount'])
    }
};
</script>

<style lang="less">
.van-dialog__confirm,
.van-dialog__confirm:active {
    color: #f23030;
}
.van-radio__icon--checked .van-icon {
    color: #fff;
    border-color: #f23030;
    background-color: #f23030;
}
button,
input {
    font: 14px arial, sans-serif;
}
textarea {
    font: 14px arial, sans-serif !important;
}
html,body{
    width: 100% !important;
    height: 100% !important;
}
#main{
    height: 100%;
}
</style>
