
const types = {
    SET_DATA: "SET_DATA",//设置home数据
    SET_SEARCH: 'SET_SEARCH',
    DEL_SEARCH:'DEL_SEARCH'
}

export default {
    state: {
        // 首页分类
        gridList: [],
        // 首页banner
        banner: [],
        //品牌制造商直供
        brandList: [],
        classifyList: [],
        classifyGroupList: [],
        categoryList: [],

        //搜索历史
        searchList: JSON.parse(localStorage.getItem("searchList")) || [],
        
        // 获取当前入口是否为app
        getCurrentSourceIsApp:localStorage.getItem('currentSourceIsApp') || ''
    },
    getters: {

    },
    mutations: {
        [types.SET_DATA](state, data) {
        	
            state.banner = data.bannerList.map((item) => {
                return { url: item.link, img: item.url, title: item.name }
            });
            state.gridList = data.channel;
            state.brandList = data.brandList;
            state.categoryList = data.categoryList;
            state.classifyList = data.classifyList;
            state.classifyGroupList = data.classifyGroupList;
        },
        [types.SET_SEARCH](state, data) {
            let temp = false;
            for(let i in state.searchList){
                if(state.searchList[i].name == data.name){
                    temp = true
                    return
                }
            }
            if(temp) return;
            state.searchList.push(data)
            localStorage.setItem("searchList", JSON.stringify(state.searchList));
        },
        [types.DEL_SEARCH](state, data) {
            state.searchList = []
            localStorage.removeItem("searchList");
        },

        // 更新当前来源入口
        changeCurrentSourceIsApp(state,value) {
            localStorage.setItem('currentSourceIsApp',value)
            state.getCurrentSourceIsApp = value
        }

        
    },

    actions: {
        // 获取首页数据
        async setHomeData({ commit }, data) {
            commit(types.SET_DATA, data || {});
        },
    },
}
