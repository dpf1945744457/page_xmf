<template>
    <div id="default-layout">
        <slot></slot>
    </div>
</template>

<style>
</style>

