<template>
	<div id="page" class="tabbar-layout">
		<LoadingPage v-if="showPageLoading"></LoadingPage>
		<slot v-else></slot>
		<Tabbar>
			<TabbarItem :selected="$route.name == 'index'" link="/" :tabName="'home'">
                <icon slot="icon" name="icon_shouye" scale="3"></icon>
                <icon slot="icon-active" name="icon_shouye" scale="3" class="active-fill-color"></icon>
                <span slot="label">首页</span>
            </TabbarItem>
			<!--<TabbarItem :selected="$route.name == 'category'" link="/category">
                <icon slot="icon" name="tab-category" scale="3"></icon>
                <icon slot="icon-active" name="tab-category" scale="3" class="active-fill-color"></icon>
                <span slot="label">分类</span>
            </TabbarItem>-->
			<TabbarItem :selected="$route.name == 'cart'" link="/cart" :tabName="'cart'" :badge="goodscount">
                <icon slot="icon" name="icon_gouwuche" scale="3"></icon>
                <icon slot="icon-active" name="icon_gouwuche" scale="3" class="active-fill-color"></icon>
                <span slot="label">购物车</span>
            </TabbarItem>
            <TabbarItem :tabName="'product'">
            	<icon slot="icon" name="icon_product" scale="3"></icon>
                <icon slot="icon-active" name="icon_product" scale="3" class="active-fill-color"></icon>
                 <span slot="label">小蜜蜂产品</span>
                 <span slot="mune" style="color:#fff!important;font-size: 14px;" @click="go" >小蜜蜂餐饮 </span>

            </TabbarItem>
			<TabbarItem :tabName="'user'" :selected="$route.name == 'user'" link="/user">
                <icon slot="icon" name="tab-user" scale="3"></icon>
                <icon slot="icon-active" name="tab-user" scale="3" class="active-fill-color"></icon>
                <span slot="label">个人中心</span>
            </TabbarItem>
			<!--<TabbarItem link="http://www.gbafpa.com" :tabName="'wanqu'">
            	<icon slot="icon" name="icon_dawanqu" scale="3"></icon>
                <icon slot="icon-active" name="icon_dawanqu" scale="3" class="active-fill-color"></icon>
                <span slot="label">大湾区</span>
            </TabbarItem>
            <TabbarItem :tabName="'food'" link="https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx9103eac3ba840373&redirect_uri=https://dt.xmfstore.com/dingzuo/wechat/userHome&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect">
            	<icon slot="icon" name="icon_food" scale="3"></icon>
                <icon slot="icon-active" name="icon_food" scale="3" class="active-fill-color"></icon>
				<span slot="label">餐饮</span>
			</TabbarItem>
			<TabbarItem :tabName="'charge'">
            	<icon slot="icon" name="icon_dawanqu" scale="3"></icon>
                <icon slot="icon-active" name="icon_dawanqu" scale="3" class="active-fill-color"></icon>
                <span slot="label">充电宝</span>
            </TabbarItem>-->
		</Tabbar>
         
	</div>
</template>

<script>
	import { Tabbar, TabbarItem } from '@src/components/base/tabbar';
	import LoadingPage from '@src/components/base/loadingPage';
	import { mapState, mapActions, mapGetters } from 'vuex';
	export default {
		components: {
			Tabbar,
			TabbarItem,
			LoadingPage
		},
		data() {
			return {
				activesParam: localStorage.getItem('activesParam')||0,
				
			}
		},
		props: {
			showPageLoading: {
				type: Boolean,
				default: false
			}
		},
		methods: {
			clickSelMeun(num, flag) {
				if(flag){
					if(num == 2){
						window.location.href = "http://www.gbafpa.com";
					}else if(num == 3){
				        if (this.isWeixin()){
				            window.location.href = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx9103eac3ba840373&redirect_uri=https://dt.xmfstore.com/dingzuo/wechat/userHome&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect"
							
				        }
					}
				} else if(num != 3){
					this.activesParam = Object.assign(this.activesParam, num);
					localStorage.setItem('activesParam', num)
					if(num == 0){
						this.$router.push({ path: '/'});
					}else if(num == 1){
						this.$router.push({ path: '/cart'});
					} 
					else {
//						this.$router.push({ path: '/category'});
					}
				}
				
			},
			goDawanqu(){
				window.location.href = "http://www.gbafpa.com";
			},
			go(){
            //  this.$router.push({ path: '/iframes'});
			 window.location.href = "https://dc.xmfstore.com/dingzuo-h5/#/home";
		},
			//判断浏览器
			isWeixin(){
				var ua = navigator.userAgent.toLowerCase();
　　				var isWeixin = ua.indexOf('micromessenger') != -1;
		        if (isWeixin){
		        	return true;
		        }
			},
			goFood(){
				var ua = navigator.userAgent.toLowerCase();
　　				var isWeixin = ua.indexOf('micromessenger') != -1;
		        if (isWeixin){
		        	window.location.href = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx9103eac3ba840373&redirect_uri=https://dt.xmfstore.com/dingzuo/wechat/userHome&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect"
							
		        }
			}
		},
		computed: {
			...mapState({
				goodscount: state => state.productDetail.goodscount
			})
		}
	};
</script>

<style lang="less" scoped>
	.tabbar-layout {
        width: 100%;
		padding-bottom: 50px;
		// overflow: hidden;
		.itmMian {
			display:-webkit-box;
			display:-webkit-flex;
			display:-ms-flexbox;
			display: flex;
			height: 50px;
			justify-content: center;
			-webkit-box-align: center;
			align-items: center;
			.item {
				display:-webkit-box;
				display:-webkit-flex;
				display:-ms-flexbox;
				display: flex;
				justify-content: center;
				-webkit-box-align: center;
				align-items: center;
				flex-direction: column;
				width: 25vw;
				height: 50px;
				img {
					width: 24px;
					height: 24px;
					margin-bottom: 2px;
				}
				span {
					padding-top: 30px;
					display: inline-block;
					width: 100%;
					font-size: 10px;
					color: #999999;
					text-align: center;
				}
				&.actives {
					color: red;
					span {
						font-size: 10px;
						color: red;
					}
				}
			}
			.home{
				background: url(../svg/icon_shouye@2x.png) no-repeat center 8px;
				background-size: 24px;
			}
			.home.actives{
				background: url(../svg/icon_shouye_red@2x.png) no-repeat center 8px;
				background-size: 24px;
			}
			.wanqu{
				background: url(../svg/icon_icon_dawanqu@2x.png) no-repeat  center 8px;
				background-size: 24px;
			}
			.wanqu.actives{
				background: url(../svg/icon_icon_dawanqu_red@2x.png) no-repeat center 8px;
				background-size: 24px;
			}
			.cart{
				background: url(../svg/icon_gouwuche@2x.png) no-repeat center 8px;
				background-size: 24px;
			}
			.cart.actives{
				background: url(../svg/icon_gouwuche_red@2x.png) no-repeat center 8px;
				background-size: 24px;
			}
			.food{
				background: url(../svg/icon_food@2x.png) no-repeat center 8px;
				background-size: 24px;
			}
			.food.actives{
				background: url(../svg/icon_food_red@2x.png) no-repeat center 8px;
				background-size: 24px;
			}
			/*.product{
				background: url(../svg/icon_xmf@2x.png) no-repeat center 8px;
				background-size: 24px;
			}
			.product.actives{
				background: url(../svg/icon_xmf_fill@2x.png) no-repeat center 8px;
				background-size: 24px;
			}*/
		}
		.weui-tabbar {
			display:-webkit-box;
			display:-webkit-flex;
			display:-ms-flexbox;
			display: flex;
			-webkit-box-align: middle;
			-ms-flex-align: middle;
			align-items: middle;
			// overflow-y: hidden;
			// overflow-x: scroll;
			-webkit-overflow-scrolling: touch;
			border-top: 1px solid #C0BFC4;
			.weui-tabbar__item {
				flex: 1;
				float: left;
				/*-webkit-box-flex: 0 0 22%;
				-moz-box-flex: 0 0 22%;
				-ms-flex: 0 0 22%;
				flex: 0 0 22%;*/
				text-align: center;
				-ms-flex-negative: 0;
				flex-shrink: 0;
				.active-fill-color {
					fill: #f23030;
				}
			}
			.weui-bar__item_on {
				.weui-tabbar__label {
					span {
						color: #333333;
					}
				}
			}
		}
		.weui-tabbar:before {
			content: none;
		}
		.weui-tabbar::-webkit-scrollbar {
			display: none;
		}
	}
</style>